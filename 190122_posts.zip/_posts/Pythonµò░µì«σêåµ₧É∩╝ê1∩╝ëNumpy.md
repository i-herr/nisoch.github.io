---
title: Python数据分析（1）Numpy
date: 2018-11-23 11:45:48
tags: [Python]
---


Numpy是python科学计算的基础包，它提供以下功能：

* 快速高效的多维数组对象ndarray 
* 用于对数组执行元素级计算以及直接对数组执行数学运算的函数
* 用于读写硬盘上基于数组的数据集的工具
* 线性代数运算、傅里叶变换，以及随机数生成
* 用于将C、C++、Fortran代码集成到python的工具

[『ipynb文档』](https://gitee.com/iherr/ipynb/blob/master/dataanalysis/numpy.ipynb)

## 一、基础


```python
import numpy as np
```


```python
# python list方法生成数据
list(range(0,10,2))
#[0, 2, 4, 6, 8]
```


```python
# 二维数据访问
var =[[1,2,3],[4,5,6],[7,8,9]]
var[0][0]
#1
```


```python
# 根据数组创建np对象
a=np.array(var)
a
# array([[1, 2, 3],
#        [4, 5, 6],
#        [7, 8, 9]])
```


```python
# np访问
a[0][0],a[0,0]
#(1, 1)
```


```python
# np数组切片
a[:2,:2]
# array([[1, 2],
#        [4, 5]])
```


```python
a1=np.arange(15).reshape(3,5)
a1
# array([[ 0,  1,  2,  3,  4],
#        [ 5,  6,  7,  8,  9],
#        [10, 11, 12, 13, 14]])
```


```python
# 数组的dimentsions，对应matrix的rows和columns
a1.shape
#(3, 5)
```


```python
# 数组的维度dimensions数量，numpy也叫axes，线性代数中矩阵的秩
a1.ndim
#2
```


```python
# 元素的type
a1.dtype
#dtype('int64')
```


```python
# 元素的type名
a1.dtype.name
#'int64'
```


```python
# 每个元素的字节数
a1.itemsize
#8
```


```python
# 元素总数
a1.size
#15
```


```python
type(a1)
#numpy.ndarray
```


```python
b1=np.arange(6)
b1
#array([0, 1, 2, 3, 4, 5])
```


```python
print(b1)
#[0 1 2 3 4 5]
```

## 二、数组创建


```python
# array创建，参数为数组
a2=np.array([6,7,8])
a2
#array([6, 7, 8])
```


```python
type(a2)
#numpy.ndarray
```


```python
a2.dtype
#dtype('int64')
```


```python
b2=np.array([(1.5,2,3),(4,5,6)])
b2
# array([[1.5, 2. , 3. ],
#       [4. , 5. , 6. ]])
```


```python
# 元素中有float
b2.dtype
#dtype('float64')
```


```python
b2.size
#6
```


```python
b2.itemsize
#8
```


```python
# 创建复数，包括实数和虚数
c2=np.array([[1,2],[3,4]],dtype=complex)
c2
# array([[1.+0.j, 2.+0.j],
#        [3.+0.j, 4.+0.j]])
```


```python
# 特定方法，参数为shape，一维：2，二维：(3,4)，三维：(2,3,4)
d2=np.zeros((3,4),dtype=np.complex)
d2
# array([[0.+0.j, 0.+0.j, 0.+0.j, 0.+0.j],
#        [0.+0.j, 0.+0.j, 0.+0.j, 0.+0.j],
#        [0.+0.j, 0.+0.j, 0.+0.j, 0.+0.j]])
```


```python
d2.itemsize
#16
```


```python
e2=np.ones((2,3,4),dtype=np.int32)
e2
# array([[[1, 1, 1, 1],
#         [1, 1, 1, 1],
#         [1, 1, 1, 1]],

#        [[1, 1, 1, 1],
#         [1, 1, 1, 1],
#         [1, 1, 1, 1]]], dtype=int32)
```


```python
f2=np.full((2,3),3.14)
f2
# array([[3.14, 3.14, 3.14],
#        [3.14, 3.14, 3.14]])
```


```python
g2=np.full_like(f2,3.2,dtype=np.float)
g2
#array([[3.2, 3.2, 3.2],
#        [3.2, 3.2, 3.2]])
```


```python
h2=np.empty((2,3))
h2
# array([[3.2, 3.2, 3.2],
#        [3.2, 3.2, 3.2]])
```


```python
# arange函数，设置开始、结束和步长。linspace函数，设置开始、结束和数量
j2=np.arange(10,30,5)
j2
#array([10, 15, 20, 25])
```


```python
k2=np.arange(0,2,0.3)
k2
#array([0. , 0.3, 0.6, 0.9, 1.2, 1.5, 1.8])
```


```python
l2=np.linspace(0,2,9)
l2
#array([0.  , 0.25, 0.5 , 0.75, 1.  , 1.25, 1.5 , 1.75, 2.  ])
```


```python
n2=np.eye(5)
n2
# array([[1., 0., 0., 0., 0.],
#        [0., 1., 0., 0., 0.],
#        [0., 0., 1., 0., 0.],
#        [0., 0., 0., 1., 0.],
#        [0., 0., 0., 0., 1.]])
```

## 三、基本运算


```python
a4=np.array([20,30,40,50])
a4
#array([20, 30, 40, 50])
```


```python
b4=np.arange(4)
b4
#array([0, 1, 2, 3])
```


```python
# 元素相减
c4=a4-b4
c4
#array([20, 29, 38, 47])
```


```python
a4+10
#array([30, 40, 50, 60])
```


```python
b4**2
#array([0, 1, 4, 9])
```


```python
10*np.sin(a4)
#array([ 9.12945251, -9.88031624,  7.4511316 , -2.62374854])
```


```python
np.any(a4>30)
#True
```


```python
np.all(a4>20)
#False
```


```python
a4<35
#array([ True,  True, False, False])
```


```python
c4=np.array([[1,1],[0,1]])
```


```python
d4=np.array([[2,0],[3,4]])
```


```python
# 排序
e4=np.sort(d4)
e4
```


```python
d4.sort(axis=1)
d4
#array([[0, 2],
#        [3, 4]])
```


```python
# 矩阵操作
A = np.array( [[1,1],[0,1]] )
B = np.array( [[2,0],[3,4]] )
```


```python
# 元素乘
A*B
#array([[2, 0],
#        [0, 4]])
```


```python
# 矩阵乘
A@B
# array([[5, 4],
#        [3, 4]])
```


```python
# 矩阵乘
A.dot(B)
# array([[5, 4],
#        [3, 4]])
```


```python
# 一维操作 
e4=np.random.random((2,3))
e4
# array([[0.65666429, 0.06776115, 0.59039502],
#        [0.29474361, 0.70762869, 0.42369208]])
```


```python
sum(e4)
#array([1.2493767 , 0.52770743, 0.85795826])
```


```python
e4.sum()
#2.635042388410591
```


```python
e4.min()
#0.03045008181383413
```


```python
e4.max()
#0.9572964175664475
```


```python
# 轴操作
f4=np.arange(12).reshape(3,4)
f4
# array([[ 0,  1,  2,  3],
#        [ 4,  5,  6,  7],
#        [ 8,  9, 10, 11]])
```


```python
f4.sum(axis=0)
#array([12, 15, 18, 21])
```


```python
np.sum(f4)
#66
```


```python
f4.sum(axis=1)
#array([ 6, 22, 38])
```


```python
f4.cumsum(axis=1)
# array([[ 0,  1,  3,  6],
#        [ 4,  9, 15, 22],
#        [ 8, 17, 27, 38]])
```


```python
#比较sum和np.sum的执行效率
n=np.random.rand(1000)
```


```python
%timeit sum(n)
#13.6 µs ± 251 ns per loop (mean ± std. dev. of 7 runs, 100000 loops each)
```


```python
#np执行效率高
%timeit np.sum(n)
#4.75 µs ± 207 ns per loop (mean ± std. dev. of 7 runs, 100000 loops each)
```

## 四、通用函数


```python
b=np.arange(3)
b
#array([0, 1, 2])
```


```python
np.exp(b)
#array([1.        , 2.71828183, 7.3890561 ])
```


```python
np.sqrt(b)
#array([0.        , 1.        , 1.41421356])
```


```python
c=np.array([2,-1,4])
```


```python
np.add(b,c)
#array([2, 0, 6])
```


```python
b+c
#array([2, 0, 6])
```

## 五、索引、切片和迭代（Indexing, Slicing and Iterating）

### 一维数组


```python
a=np.arange(10)**3
a
#array([  0,   1,   8,  27,  64, 125, 216, 343, 512, 729])
```


```python
a[2]
#8
```


```python
a[2:5]
#array([ 8, 27, 64])
```


```python
# 等同于a[0:6:2] = -1000;从0到第6个元素，步长为2
a[:6:2]
#array([ 0,  8, 64])
```


```python
# 元素倒序
a[::-1]
#array([729, 512, 343, 216, 125,  64,  27,   8,   1,   0])
```


```python
for i in a:
    print(i**(1/3.))
```

### 多维数组


```python
def f(x,y):
    return 10*x+y
```


```python
b=np.fromfunction(f,(5,4),dtype=int)
b
# array([[ 0,  1,  2,  3],
#        [10, 11, 12, 13],
#        [20, 21, 22, 23],
#        [30, 31, 32, 33],
#        [40, 41, 42, 43]])
```


```python
b[2,3]
#23
```


```python
b[0:5,1]
#array([ 1, 11, 21, 31, 41])
```


```python
b[:,1]
#array([ 1, 11, 21, 31, 41])
```


```python
b[0:2,:]
#array([[ 0,  1,  2,  3],
#        [10, 11, 12, 13]])
```


```python
b[0:2,0:2]
# array([[ 0,  1],
#        [10, 11]])
```


```python
b[0:2][0:2]
# array([[ 0,  1,  2,  3],
#        [10, 11, 12, 13]])
```


```python
#迭代
for row in b:
    print(row)
# [0 1 2 3]
# [10 11 12 13]
# [20 21 22 23]
# [30 31 32 33]
# [40 41 42 43]
```


```python
for ele in b.flat:
    print(ele)
# 0
# 1
# 2
# 3
# 10
# 11
# 12
# 13
# ...
```

## 六、Array shape


```python
a=np.array([[1,2,3,4],[5,6,7,8],[9,10,11,12]])
a
# array([[ 1,  2,  3,  4],
#        [ 5,  6,  7,  8],
#        [ 9, 10, 11, 12]])
```


```python
a.ravel()
#array([ 1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12])
```


```python
# 如果为-1，会自动计算，等同于a.reshape(6,2)
a.reshape(6,-1)
# array([[ 1,  2],
#        [ 3,  4],
#        [ 5,  6],
#        [ 7,  8],
#        [ 9, 10],
#        [11, 12]])
```


```python
# 转置
a.T
# array([[ 1,  5,  9],
#        [ 2,  6, 10],
#        [ 3,  7, 11],
#        [ 4,  8, 12]])
```


```python
# reshape和转置后，a本身没有变化
a
# array([[ 1,  2,  3,  4],
#        [ 5,  6,  7,  8],
#        [ 9, 10, 11, 12]])
```


```python
# reshape返回新的array，resize修改array自身。如需要修改自身，也可直接使用shape属性，等同于a.shape=(6,2)
a.resize(6,2)
a
# array([[ 1,  2],
#        [ 3,  4],
#        [ 5,  6],
#        [ 7,  8],
#        [ 9, 10],
#        [11, 12]])
```

## 七、Array stack together


```python
a=np.array([[1,2],[3,4]])
```


```python
b=np.array([[5,6],[7,8]])
```


```python
np.concatenate((a,b),axis=0)
# array([[1, 2],
#        [3, 4],
#        [5, 6],
#        [7, 8]])
```


```python
np.concatenate((a,b),axis=1)
# array([[1, 2, 5, 6],
#        [3, 4, 7, 8]])
```


```python
np.vstack((a,b))
# array([[1, 2],
#        [3, 4],
#        [5, 6],
#        [7, 8]])
```


```python
np.hstack((a,b))
# array([[1, 2, 5, 6],
#        [3, 4, 7, 8]])
```

## 八、Array splitting


```python
a=np.array([[1,2,3,4,5,6,7,8,9,10,11,12],[21,22,23,24,25,26,27,28,29,30,31,32]])
a
# array([[ 1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12],
#        [21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32]])
```


```python
# 按列3等分
np.hsplit(a,3)
# [array([[ 1,  2,  3,  4],
#         [21, 22, 23, 24]]), array([[ 5,  6,  7,  8],
#         [25, 26, 27, 28]]), array([[ 9, 10, 11, 12],
#         [29, 30, 31, 32]])]
```


```python
# 从第三和第四列分割
np.hsplit(a,(3,4))
# [array([[ 1,  2,  3],
#         [21, 22, 23]]), array([[ 4],
#         [24]]), array([[ 5,  6,  7,  8,  9, 10, 11, 12],
#         [25, 26, 27, 28, 29, 30, 31, 32]])]
```

## 九、Copies and Views

### 1、直接复制，引用指向相同


```python
a=np.arange(12)
```


```python
b=a
```


```python
b is a
#True
```


```python
b.shape= (3,4)
```


```python
a.shape
#(3, 4)
```

### 2、view，变更shape不影响，修改值会影响


```python
c=a.view()
```


```python
c is a 
#False
```


```python
c.base is a 
#True
```


```python
c.shape=(2,6)
```


```python
a.shape
#(3, 4)
```


```python
c[0,4]=1234
```


```python
a
# array([[   0,    1,    2,    3],
#        [1234,    5,    6,    7],
#        [   8,    9,   10,   11]])
```

### 3、copy，变更shape和修改值都不会影响


```python
d=a.copy()
```


```python
d is a 
#False
```


```python
d.base is a
#False
```


```python
d[0,0]=9999
d
# array([[9999,    1,    2,    3],
#        [1234,    5,    6,    7],
#        [   8,    9,   10,   11]])
```


```python
a
# array([[   0,    1,    2,    3],
#        [1234,    5,    6,    7],
#        [   8,    9,   10,   11]])
```

## 十、Indexing with Arrays of Indices


```python
a=np.arange(12)**2
a
#array([  0,   1,   4,   9,  16,  25,  36,  49,  64,  81, 100, 121])
```


```python
i=np.array([1,1,3,5,8])
```


```python
a[i]
#array([ 1,  1,  9, 25, 64])
```


```python
j=np.array([[3,4],[5,6]])
```


```python
a[j]
# array([[ 9, 16],
#        [25, 36]])
```


```python
a=np.arange(12).reshape(3,4)
a
# array([[ 0,  1,  2,  3],
#        [ 4,  5,  6,  7],
#        [ 8,  9, 10, 11]])
```


```python
i=np.array([[0,1],[1,2]])
```


```python
j=np.array([[2,1],[3,3]])
```


```python
a[i,j]
# array([[ 2,  5],
#        [ 7, 11]])
```


```python
a[i,2]
# array([[ 2,  6],
#        [ 6, 10]])
```


```python
a=np.arange(5)
a
#array([0, 1, 2, 3, 4])
```


```python
a[[0,0,2]]=[1,2,3]
a
#array([2, 1, 3, 3, 4])
```

## 十一、Random 随机

### 0、random模块的随机方法


```python
import random
```


```python
#生成[5,10]之间的随机整数
random.randint(5,10)
#7
```


```python
#生成0-1的float数据
random.random()
#0.6050909097237349
```

### 以下为np模块的random随机方法
### 1、numpy.random.rand(d0,d1,…,dn)

* rand函数根据给定维度生成0到1，前闭后开区间的数据，包含0，不包含1
* dn表格每个维度
* 返回值为指定维度的array


```python
np.random.rand(3,3)
# array([[0.66623244, 0.45705496, 0.58081625],
#        [0.13670723, 0.78440093, 0.7079095 ],
#        [0.40285142, 0.70139829, 0.82308891]])
```

### 2、numpy.random.randn(d0,d1,…,dn)

* randn函数返回一个或一组样本，具有标准正态分布(standard normal distribution)。标准正态分布又称为u分布，是以0为均值、以1为标准差的正态分布，记为N（0，1）。
* dn表格每个维度，当没有参数时，返回单个数据
* 返回值为指定维度的array


```python
np.random.randn() 
#0.6423112533434442
```


```python
np.random.randn(3,3) 
# array([[ 0.09658991, -2.83590735, -0.21460649],
#        [-1.77854159, -0.82415655, -0.4636123 ],
#        [ 0.58119767, -0.57786413,  0.0742295 ]])
```

### 3、numpy.random.randint(low, high=None, size=None, dtype=’l’)

* 返回随机整数，范围区间为[low,high），包含low，不包含high
* 参数：low为最小值，high为最大值，size为数组维度大小，dtype为数据类型，默认的数据类型是np.int
* high没有填写时，默认生成随机数的范围是[0，low)


```python
# 返回[0,1)之间的整数，所以只有0
np.random.randint(1,size=5)
#array([0, 0, 0, 0, 0])
```


```python
# 返回1个[1,5)时间的随机整数
np.random.randint(1,5) 
#2
```


```python
# 生成区间为[0,10)的随机整数
np.random.randint(0,10,size=(2,2))
# array([[1, 1],
#        [6, 8]])
```

### 4、浮点数

生成[0,1)之间的浮点数

* numpy.random.random_sample(size=None)
* numpy.random.random(size=None)
* numpy.random.ranf(size=None)
* numpy.random.sample(size=None)


```python
print('--random_sample--')
print(np.random.random_sample(size=(2,2)))
print('--random--')
print(np.random.random(size=(2,2)))
print('--ranf--')
print(np.random.ranf(size=(2,2)))
print('--sample--')
print(np.random.sample(size=(2,2)))
# --random_sample--
# [[0.81408113 0.09255191]
#  [0.37559088 0.77663326]]
# --random--
# [[0.83663939 0.66350458]
#  [0.99431816 0.23499516]]
# --ranf--
# [[0.4313313  0.63957712]
#  [0.25859169 0.74576795]]
# --sample--
# [[0.10410069 0.02092188]
#  [0.07719955 0.87703089]]
```

### 5、numpy.random.choice(a, size=None, replace=True, p=None)

* 从给定的一维数组中生成随机数
* 参数：a为一维数组类似数据或整数；size为数组维度；p为数组中的数据出现的概率
* a为整数时，对应的一维数组为np.arange(a)


```python
np.random.choice(5,3)
#array([3, 1, 1])
```


```python
# 当replace为False时，生成的随机数不能有重复的数值
np.random.choice(5, 3, replace=False)
#array([4, 0, 2])
```


```python
np.random.choice(5,size=(3,2))
# array([[3, 4],
#        [1, 1],
#        [4, 2]])
```


```python
demo_list = ['lenovo', 'sansumg','moto','xiaomi', 'iphone']
np.random.choice(demo_list,size=(3,3))
# array([['moto', 'lenovo', 'moto'],
#        ['lenovo', 'sansumg', 'iphone'],
#        ['moto', 'sansumg', 'xiaomi']], dtype='<U7')
```


```python
#参数p的长度与参数a的长度需要一致；
#参数p为概率，p里的数据之和应为1
demo_list = ['lenovo', 'sansumg','moto','xiaomi', 'iphone']
np.random.choice(demo_list,size=(3,3), p=[0.1,0.6,0.1,0.1,0.1])
# array([['xiaomi', 'sansumg', 'lenovo'],
#        ['sansumg', 'sansumg', 'lenovo'],
#        ['sansumg', 'sansumg', 'lenovo']], dtype='<U7')
```

### 6、numpy.random.seed()

* 使得随机数据可预测。
* 当我们设置相同的seed，每次生成的随机数相同。如果不设置seed，则每次会生成不同的随机数


```python
np.random.seed(0)
np.random.rand(5)
#array([0.5488135 , 0.71518937, 0.60276338, 0.54488318, 0.4236548 ])
```


```python
np.random.seed(1676)
np.random.rand(5)
#array([0.39983389, 0.29426895, 0.89541728, 0.71807369, 0.3531823 ])
```


```python
np.random.seed(1676)
np.random.rand(5)
#array([0.39983389, 0.29426895, 0.89541728, 0.71807369, 0.3531823 ])
```