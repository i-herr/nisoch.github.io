---
title: iOS开发证书技巧
date: 2016-05-15 13:04:06
tags: iOS
---

开发证书，其实挺简单的，但如果某处搞不好，也是很费时间的。且member center里的内容虽说万变不离其宗，但几年下来终归还是有变化的。完整的流程我就不写了，可以自行百度大把文章，这边谈谈证书使用的小技巧。

## 一、证书制作流程图

![](iOS开发证书技巧/flow.png)

对于概念不懂的同学，可以到这脑补下[『iOS Provisioning Profile(Certificate)与Code Signing详解』](http://blog.csdn.net/phunxm/article/details/42685597)


## 二、关于Provisioning Profile供应配置管理
我们在项目配置时，虽然经常将Code Signing的Provisioning Profile配置成"Automatic"，但还是需要去developer.apple.com上下载所有的mobileprovision文件。如果这些文件经常变化，可以这样：

1、首先cd到这些mobileprovision文件的目录"~/Library/MobileDevice/Provisioning Profiles"，然后删除所有的文件。
可使用命令

``` bash
$ rm *.mobileprovision
```

2、这样再看Xcode的时候，就找不到任何provisioning profile了。这个时候不需要一个一个的添加。而是访问XCode的Preferences> Accounts，在Apple IDs里面找到你的帐号，右下角有个View Details，这时，你就可以download下所有网站上配置的文件了。一个按钮搞定。

![](iOS开发证书技巧/certificate.png)