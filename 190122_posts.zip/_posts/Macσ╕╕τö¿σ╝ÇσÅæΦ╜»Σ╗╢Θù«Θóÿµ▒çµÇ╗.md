---
title: Mac常用开发软件问题汇总
date: 2015-11-20 15:21:23
tags: [Mac]
---

## 一、常用软件快捷键

> 系统

* Ctrl + 空格键，自定义为 Spotlight 搜索栏

> Terminal

* Ctrl + A/E，将光标移动到开头和结尾
* Alt + 左右箭头，光标向前/后移动一个单词
* Ctrl + W，删除光标前一个单词
* Ctrl + U，清空当前行
* Command + K，清屏

> Finder

* Shift + Command + D，打开桌面文件夹
* Command + W，关闭窗口
* Command + [，后退
* Command + ]，前进
* 空格键，快速查看
* Alt + Command + 空格键，快速打开inder

> MacDown

* Shift + Command + I，插入图片
* Shift + Command + K，插入链接

> Xcode

* Alt + Command + [ 或 ]，上下移动该行
* Command+［ 或 ]，多行缩进

## 二、sublime text
> 插件  

（1）color highlighter显示颜色  
（2）color picker拾取颜色，快捷键Command+Shift+C  
（3）emmet，但需要pyv8插件。Tab键代码自动补全
（4）javascript completions，js代码补全
（5）ConvertToUTF8，字符集转换为UTF-8，避免汉字乱码，需要安装插件Codecs33  
（6）LESS，用于支持LESS高亮显示  
（7）Less2Css，用于支持LESS编译，需安装less(编译)和less-plugin-clean-css(压缩)

``` bash
$ npm install -g less  
$ npm install -g less-plugin-clean-css
```

（8）SASS，用于SASS高亮显示  
（9）SASS Build，用于支持SASS编译

``` bash
$ sudo gem install -n /usr/local/bin sass
```

如报错Error: Invalid US-ASCII character "\xC2" ，可在scss文件添加

``` bash
  @charset "UTF-8";
```
如需要使用watch自动编译，则需要保证路径上无中文，否则会报错：incompatible character encodings: ASCII-8BIT and UTF-8 Backtrace

``` bash
  sass --watch style.scss:style.css
```

> 中文无法open in browser 

安装插件SideBarEnhancements，绑定快捷键

```bash
{ "keys": ["command+1"], "command": "side_bar_open_in_browser", "args": { "paths": [], "type": "testing", "browser": "safari"}  },
{ "keys": ["command+2"], "command": "side_bar_open_in_browser", "args": { "paths": [], "type": "testing", "browser": "chrome"}  },
{ "keys": ["command+3"], "command": "side_bar_open_in_browser", "args": { "paths": [], "type": "testing", "browser": "firefox"}  },
```

<!--more-->

> emmet，需要pyv8插件无法下载

* 1、可以到网址下载：https://raw.github.com/emmetio/pyv8-binaries/master/pyv8-osx-p3.zip
* 2、打开菜单栏Sublime Text – Preferences – Browser Packages；
* 3、在Installed Packages目录下新建pyV8目录，将下载到的pyv8-osx-p3文件夹拷贝至此；
* 4、重启即可。

> color picker快捷键冲突  
需绑定快捷键

```bash
{ "keys": ["super+shift+c"], "command": "color_pick"},
```

## 三、Charles
> https无法抓包

1、检查mac端安装证书，并且标记为信任证书
![](Mac常用开发软件问题汇总/charles.png)

2、手机端也需要安装相应证书，如果手机可以直接安装cert证书，则使用Install **** on a Mobile Device or Remote Browser，否则使用Save Charles Root Certificate，导出pem证书，发送给手机端安装。
![](Mac常用开发软件问题汇总/charles_ssl.png)

## 四、JetBrain家族-idea、python、android studio等

> 快捷键，使用Mac OS X10.5+模板

* Command + D，复制当前行
* Command + delete，删除当前行
* Shift + enter，当光标在某行中间时，直接换行到下一行
* 两次Shift，搜索文件并打开

## 五、Alfred

* Option + 空格，调出搜索框
* find 文件名
* open 文件名
* bd 搜索内容 #百度搜索，需要配置

## 六 Jupyter Notebook

Shift-Enter	运行本单元，选中下个单元
Ctrl-Enter	运行本单元	 
Alt-Enter	运行本单元，在其下插入新单元
Y	单元转入代码状态	 
M	单元转入 markdown 状态
D,D	删除选中的单元
Enter 进入编辑模式
Esc 退出编辑模式
A 添加一行
TAB 代码提示
L 显示行数

## 五、Robo 3T

https://robomongo.org/download

## 六、应用安全

提示“***”已损坏，打不开。您应该将它移到废纸篓
sudo spctl --master-disable
设置-安全性和隐私-任何来源