---
title: SpringBoot实战（3）SpringMVC
date: 2017-04-07 11:31:42
tags: [SpringBoot,Java,SpringMVC]
---

## 一、Spring MVC原理

![](SpringBoot实战（3）SpringMVC/springmvc.jpeg)
> DispatcherServlet（前端控制器）

DispatcherServlet是整个流程控制的中心，由它调用其它组件处理用户的请求，DispatcherServlet的存在降低了组件之间的耦合性。

> HandlerMapping（处理器映射器）

HandlerMapping负责根据用户请求找到Handler即处理器，springmvc提供了不同的映射器实现不同的映射方式，例如：配置文件方式，实现接口方式，注解方式等，推荐使用注解开发。
> Handler（处理器）

Handler 是继DispatcherServlet前端控制器的后端控制器，在DispatcherServlet的控制下Handler对具体的用户请求进行处理。由于Handler涉及到具体的用户业务请求，所以一般情况需要程序员根据业务需求开发Handler。
> HandlerAdapter（处理器适配器）

通过HandlerAdapter对处理器进行执行，这是适配器模式的应用，通过扩展适配器可以对更多类型的处理器进行执行。
> ViewResolver（视图解析器）

View Resolver负责将处理结果生成View视图，View Resolver首先根据逻辑视图名解析成物理视图名即具体的页面地址，再生成View视图对象，最后对View进行渲染将处理结果通过页面展示给用户。

## 二、Spring Boot的Web开发
Spring Boot提供了springboot-starter-web为Web开发予以支持。提供了嵌入的Tomcat以及Spring MVC的依赖。Web相关的自动配置存储在spring-boot-autoconfigure.jar的org.springframework.boot.autoconfigure.web下。

> 模板引擎  

jsp在内嵌的Servlet的容器中有问题，tomcat和jetty不支持以jar形式运行jsp，undertow不支持jsp，因此Spring Boot提供了大量模板引擎，有Freemarker、Groovy、Thymeleaf、Velocity等。  

> Thymeleaf

Thymeleaf[『官网传送门』](http://www.thymeleaf.org)是一个java类库，是xml/xhtml/html5的模板引擎，作为MVC的Web应用的View层。
<!--more-->

1、默认原则，html模板文件放在src/main/resources/templates下。通过<html xmlns:th="http://www.thymeleaf.org">引入Thymeleaf。后续需要处理的动态内容都需要加上"th:"前缀。

2、通过"@{}"引入静态文件，默认原则，文件放在src/main/resources/static下。

```bash
<link th:href="@{bootstrap/css/bootstrap-theme.min.css}" rel="stylesheet"/>
<script th:src="@{bootstrap/js/bootstrap.min.js}"></script>
```

3、通过"${}"访问model中的属性

```bash
<span th:text="${singlePerson.name}"></span> 
```

4、list数据判断和迭代

```bash
  <div th:if="${not #lists.isEmpty(people)}">
	  <div class="panel panel-primary">
	    <div class="panel-heading">
	        <h3 class="panel-title">列表</h3>
	    </div>
	    <div class="panel-body">
	        <ul class="list-group">
				<li class="list-group-item" th:each="person:${people}">
				    <span th:text="${person.name}"></span>
				   	<span th:text="${person.age}"></span>
				   	<button class="btn" th:onclick="'getName(\'' + ${person.name} + '\');'">获得名字</button>
				</li>
	        </ul>
	    </div>
	 </div>
 </div>
```

5、在JavaScript中访问model，使用 "[[${}]]" 格式。且需要在script标签设置th:inline="javascript"才可实现访问。另外如需要在html中访问model的值，button格式如下：

``` bash
  <button class="btn" th:onclick="'getName(\'' + ${person.name} + '\');'">获得名字</button>
  
  <script th:inline="javascript">
  	var single = [[${singlePerson}]];
  	console.log(single.name+"/"+single.age)
  	
  	function getName(name){
  		console.log(name);
  	}
  </script>

```

## 三、Web相关配置

> Spring Boot提供的自动配置，通过WebMvcConfiguration及WebMvcProperties来设置。

1、自动配置的ViewResolver

（1）ContentNegotiatingViewResolver，特殊，最高级，代理给不同的ViewResolver来处理不同的View    
（2）BeanNameViewResolver，根据控制器返回的字符串来查找Bean名称相同的视图  
（3）InternaleResourceViewResolver，通过设置前后缀和控制器返回视图名的字符串来获得实际页面    

2、自动配置的静态资源

通过自动配置类的addResourceHandlers方法来定义以下静态资源的自动配置。（1）类路径文件（/static、/public、/resources、/META-INF/resources）文件夹下的静态文件直接映射为/* * ，可通过http://localhost:8080/* * 来访问。  
（2）webjar，把webjar的/META-INF/resources/webjars下的静态文件映射为/webjars/* * ，可通过http://localhost:8080/webjars/* * 来访问。

3、自动配置的Formatter和Converter  
在WebMvcAutoConfiguration的方法addFormatters中，配置了Converter、GenericConverter和Formatter接口的实现类的Bean，并自动注册到Spring MVC中。

4、自动配置的HttpMessageConverters
定义了ByteArray、BufferedImage、Resource、Jackson、Gson等HttpMessageConverters。

> 接管Spring Boot的mvc配置

新建配置类，注解Configuration，重写WebMvcConfigurerAdapter的addViewControllers方法，不是覆盖，和自动配置同时生效。

```java
@Configuration
public class NewWebMvcConfig  extends WebMvcConfigurerAdapter {
    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/herr").setViewName("/herr");
    }

}
```

> tomcat替换为jetty或undertow

``` java
	<dependencies>
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-web</artifactId>
			<exclusions>
				<exclusion>
					<groupId>org.springframework.boot</groupId>
					<artifactId>spring-boot-starter-tomcat</artifactId>
				</exclusion>
			</exclusions>
		</dependency>
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-jetty</artifactId>
		</dependency>
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-undertow</artifactId>
		</dependency>
	</dependencies>
```

> SSL配置

使用keytool生成p12文件，并安装到服务器。p12文件放到src/main/resources路径下。

```bash
$ keytool -genkey -alias tomcat -dname "CN=Andy,OU=kfit,O=kfit,L=HaiDian,ST=BeiJing,C=CN"  -storetype PKCS12 -keyalg RSA -keysize 2048  -keystore keystore.p12 -validity 365
```

> properties文件配置

```bash
server.port = 8443
server.ssl.key-store = classpath:keystore.p12
server.ssl.key-store-password= 123456
server.ssl.keyStoreType= PKCS12
server.ssl.keyAlias= tomcat
```

> 设置http8080自动跳转(springboot2版本)

```java
 @Bean
    public TomcatServletWebServerFactory servletContainer() {

        TomcatServletWebServerFactory tomcat = new TomcatServletWebServerFactory() {

            @Override
            protected void postProcessContext(Context context) {

                SecurityConstraint securityConstraint = new SecurityConstraint();
                securityConstraint.setUserConstraint("CONFIDENTIAL");
                SecurityCollection collection = new SecurityCollection();
                collection.addPattern("/*");
                securityConstraint.addCollection(collection);
                context.addConstraint(securityConstraint);
            }
        };
        tomcat.addAdditionalTomcatConnectors(initiateHttpConnector());
        return tomcat;
    }

    private Connector initiateHttpConnector() {
        Connector connector = new Connector("org.apache.coyote.http11.Http11NioProtocol");
        connector.setScheme("http");
        connector.setPort(8080);
        connector.setSecure(false);
        connector.setRedirectPort(8443);
        return connector;
    }
```

> favicon配置

禁用favicon

``` bash
spring.mvc.favicon.enabled=false
```

设置favicon：将favicon.ico放到到静态路径下即可。

> WebSocket

STOMP协议，Simple (or Streaming) Text Orientated Messaging Protocol，简单(流)文本定向消息协议

> 基于Bootstrap和AngularJS的现代Web应用

1、单页面应用，资源是动态加载到页面，不需要服务器控制页面跳转
2、响应式设计，（Responsive web design，RWD）不同设备分辨率自适应。
3、数据导向，区别于页面导向，通过后台REST服务获取JSON，而不是通过服务器渲染动态页面来实现。