---
title: Python爬虫
date: 2017-10-05 11:54:22
tags:
---

## 一、爬虫介绍

> 爬虫库

* urllib/urllib3，python自带，有短板
* requests，用来请求网站获取网页数据。
* Beautiful，用来解析html和xml，提取数据。

> 性能对比

html解析性能对比，如结构简单且避免额外依赖可选择正则，爬取数据量较少可使用BeautifulSoup，当数据量大时Lxml是最好的选择。

爬取方法|性能|使用难度|安装难度
---|---|---|---
正则表达式	|快|困难|简单（内置模块）
BeautifulSoup	|慢|简单|简单
Lxml	|快|简单|相对困难

# 二、requests

> 安装

* pip3 install requests

> 使用

```python
import requests
# 使用get、post、put、delete、options等请求，可增加headers、timeout、proxy等属性
r = requests.get('https://www.douban.com/') 
print(r.status_code) #状态码
print(r.url)  #请求url
print(r.headers) #头部信息
print(r.cookies) #cookie信息
print(r.text)  #文本形式的网页源码
print(r.content) #字节流形式的网页源码
```

# 三、BeautifulSoup

> 安装导入

[『官方文档传送门』](https://www.crummy.com/software/BeautifulSoup/bs4/doc/index.zh.html)

[『本节内容的ipynb代码』](https://gitee.com/iherr/ipynb/blob/master/crawler/beautifulsoup.ipynb)

```bash
$ pip3 install bs4
```


```python
from bs4 import BeautifulSoup
```

> 解析器对比

解析器|使用方法|优势|劣势
---|---|---|---
Python标准库	|BeautifulSoup( markup, "html.parser")	|Python的内置标准库，执行速度适中，文档容错能力强|Python 2.7.3 or 3.2.2)前的版本中文档容错能力差
lxml HTML 解析器	|BeautifulSoup( markup, "lxml")	|速度快，文档容错能力强|需要安装C语言库
lxml XML 解析器	|BeautifulSoup( markup, "xml")|速度快，唯一支持XML的解析器|需要安装C语言库
html5lib	|BeautifulSoup( markup, "html5lib")	|最好的容错性，以浏览器的方式解析文档，生成HTML5格式的文档|速度慢，不依赖外部扩展

> BeautifulSoup对象

Beautiful Soup将复杂HTML文档转换成一个复杂的树形结构,每个节点都是Python对象,所有对象可以归纳为4种: 

* Tag对象，与html原生tag相同。tag有名称（Name），属性(Attributes)。
* NavigableString对象，可以遍历的字符串。
* BeautifulSoup对象，表示一个文档的全部内容
* Comment对象，是一个特殊类型的NavigableString对象，注释及特殊字符串。


下列代码可参考[『ipynb文档传送门』](https://gitee.com/iherr/ipynb/blob/master/crawler/beautifulsoup.ipynb)

```python
# 通过文件创建BeautifulSoup对象，默认使用lxml作为解析器，推荐
soup=BeautifulSoup(open('file/index.html'),'lxml')
soup
```

<!--more-->

```python
html_doc = """
<!DOCTYPE html>
<html><head><title>test</title></head>
<body>
<p class="story">Once upon a time there were three little sisters; and their names were
<a href="http://example.com/elsie" class="sister" id="link1">Elsie</a>,
<a href="http://example.com/lacie" class="sister" id="link2">Lacie</a> and
<a href="http://example.com/tillie" class="sister" id="link3">Tillie</a>;
and they lived at the bottom of a well.</p>
<b class="boldest" id="1">Extremely bold</b>
<h1><!--Hey, buddy. Want to buy a used parser?--></h1>
</body>
</html>
"""
```


```python
# 通过字符串创建BeautifulSoup对象
soup = BeautifulSoup(html_doc)
soup
```


```python
# 查看BeautifulSoup对象的name
soup.name
```

通过BeautifulSoup对象获取Tag对象、NavigableString对象、Comment对象


```python
# 获取Tag对象
soup.title
```


```python
# 可以循环调用，当循环调用时，其实可以把BeautifulSoup对象当做Tag对象
soup.head.title
```


```python
# 查看对象类别
type(soup.title)
```


```python
# 获取NavigableString对象
soup.title.string
```


```python
# 查看对象类别
type(soup.title.string)
```


```python
# 获取Comment对象
comment = soup.h1.string
comment
```


```python
# 查看对象类别
type(comment)
```

> Tag对象操作


```python
tag=soup.b
```


```python
# 获取Tag对象的某个属性
tag['class']
```


```python
# 和上面等价
tag.get('class')
```


```python
# 获取Tag对象的所有属性
tag.attrs
```


```python
# 删除Tag对象的某个属性
del tag['id']
tag
```


```python
# 修改Tag对象的某个属性
tag['id']=2
tag
```


```python
# 查找匹配某个属性的标签
soup.find(id='link1')
```


```python
# class是python关键字，因此以class_代替
soup.findAll(class_='sister')
```


```python
for link in soup.findAll('a'):
    print(link.get('href'))
```

> 遍历文档树

1、子节点


```python
# 一个Tag可能包含多个字符串或其它的Tag,这些都是这个Tag的子节点
body_tag = soup.body
body_tag
```


```python
# Tag的contents属性可以将tag的子节点以列表的方式输出
body_tag.contents
```


```python
# 查看列表长度
len(body_tag.contents)
```


```python
# Tag的children生成器,可以对tag的子节点进行循环
body_tag.children
```


```python
for child in body_tag.children:
    print(child)
```


```python
# .contents 和 .children 属性仅包含tag的直接子节点，descendants会递归所有子孙节点
for child in body_tag.descendants:
    print(child)
```


```python
title_tag=soup.head
title_tag
```


```python
# 如果tag只有一个 NavigableString 类型子节点,那么这个tag可以使用 .string 得到子节点
title_tag.string
```


```python
# 如有多个，可以使用strings得到所有NavigableString子节点
for str in body_tag.strings:
    print(str)
```

2、父节点


```python
title_tag = soup.title
title_tag
```


```python
# 获取tag的父节点
title_tag.parent
```


```python
# 父节点可能是Tag对象(上一行)，可能是BeautifulSoup对象（本行），也有可能是None（下一行）
html_tag = soup.html
type(html_tag.parent)
```


```python
print(soup.parent)
```


```python
# 通过元素的 .parents 属性可以递归得到元素的所有父辈节点
for parent in title_tag.parents:
    if parent is None:
        print(parent)
    else:
        print(parent.name)
```

3、兄弟节点


```python
b_tag=soup.b
b_tag
```


```python
# 有换行符的缘故
b_tag.next_sibling
```


```python
# 下一个的下一个兄弟节点
b_tag.next_sibling.next_sibling
```


```python
# 上一个的上一个兄弟节点
b_tag.previous_sibling.previous_sibling
```


```python
# 通过 .next_siblings 和 .previous_siblings 属性可以对当前节点的兄弟节点迭代输出
for sibling in b_tag.next_siblings:
    print(repr(sibling))
```

4、回退和前进


```python
title_tag
```


```python
# 没有上个兄弟节点，因此为空
title_tag.previousSibling
```


```python
# 上一个解析的对象（本行是Tag对象，下一行是字符串）
title_tag.previous_element
```


```python
# 下一个解析的对象
title_tag.next_element
```


```python
for element in title_tag.previous_elements:
    print(repr(element))
    print('')
```

> 搜索文档树

1、过滤器

find_all需要传入过滤器，过滤器可以被用在tag的name中,节点的属性中,字符串中或他们的混合中


```python
# 1、最简单的过滤器是字符串
# 查找文档中所有的<a>标签
soup.find_all('a')
```


```python
# 2、过滤器是正则表达式
# 查找文档中所有的b开头的标签
import re
for tag in soup.find_all(re.compile("^b")):
    print(tag.name)
```


```python
# 查找文档中所有的包含t的标签
for tag in soup.find_all(re.compile("t")):
    print(tag.name)
```


```python
# 3、过滤器是列表
# 查找文档中所有的<a>和<b>标签
soup.find_all(["a", "b"])
```


```python
# 4、过滤器可以是True，可以匹配任何值,查找到所有的tag,但是不会返回字符串节点
for tag in soup.find_all(True):
    print(tag.name)
```


```python
# 5、过滤器可以是函数，查看包含 class 和 id 属性的Tag
def has_class_and_id(tag):
    return tag.has_attr('class') and tag.has_attr('id')

soup.find_all(has_class_and_id)
```

2、find_all函数格式：

find_all( name , attrs , recursive , text , **kwargs )


```python
# 1、name参数
soup.find_all('b')
```


```python
# 2、kwargs参数
soup.find_all(id='link2')
```


```python
# 也可以使用正则
soup.find_all(href=re.compile("elsie"))
```


```python
# 可以混用，name参数和是多个kwargs参数的组合
soup.find_all('a',id='link1',href=re.compile("elsie"))
```


```python
# 查找有id属性的Tag
soup.find_all(id=True)
```


```python
# 按CSS查询
soup.find_all("a", class_="sister")
```


```python
soup.find_all(class_=re.compile("ist"))
```


```python
def has_six_characters(css_class):
    return css_class is not None and len(css_class) == 6

soup.find_all(class_=has_six_characters)
```


```python
# 3、text参数，可以搜索文档中的字符串内容
soup.find_all(text=["Tillie", "Elsie", "Lacie"])
```


```python
# 4、limit参数，限制返回的个数
soup.find_all("a", limit=2)
```


```python
# 5、recursive参数，默认为非直接子节点。可指定为False查找直接子节点
soup.find_all("a", recursive=False)
```


```python
# p节点下有a直接子节点
soup.p.find_all("a", recursive=False)
```


```python
soup.find_all("a")
```


```python
# 等价于上一行
soup("a")
```

3、find函数格式

find( name , attrs , recursive , text , **kwargs )


```python
# 和find_all的limit=1等同
# soup.find_all('title', limit=1)[0]
soup.find('title')
```

4、

```python
find_next_siblings() 和 find_next_sibling()格式

find_next_siblings( name , attrs , recursive , text , **kwargs )

find_next_sibling( name , attrs , recursive , text , **kwargs )

find_previous_siblings() 和 find_previous_sibling()¶格式

find_previous_siblings( name , attrs , recursive , text , **kwargs )

find_previous_sibling( name , attrs , recursive , text , **kwargs )
```
这4个方法通过 .previous_siblings 和.next_siblings属性对tag的前后解析


```python
first_link = soup.a
first_link
```


```python
first_link.find_next_siblings("a")
```


```python
first_link.find_next_sibling("a")
```

5、

```python
find_all_next() 和 find_next()格式
find_all_next( name , attrs , recursive , text , **kwargs )

find_next( name , attrs , recursive , text , **kwargs )


find_all_previous() 和 find_previous()格式

find_all_previous( name , attrs , recursive , text , **kwargs )

find_previous( name , attrs , recursive , text , **kwargs )

```

这4个方法通过 .previous_elements 和.next_elements 属性对tag进行前后解析


```python
first_link = soup.a
first_link
```


```python
first_link.find_all_previous("title")
```

6、CSS选择器

Beautiful Soup支持大部分的CSS选择器,在 Tag 或 BeautifulSoup 对象的 .select() 方法中传入字符串参数,即可使用CSS选择器的语法找到tag


```python
# 通过title直接查找
soup.select("title")
```


```python
# 通过tag标签逐层查找
soup.select("body a")
```


```python
# 找到某个tag标签下的直接子标签
soup.select("head > title")
```


```python
# 找到兄弟节点标签
soup.select("#link1 ~ .sister")
```


```python
soup.select("#link1 + .sister")
```


```python
# 通过CSS的类名查找
soup.select(".sister")
```


```python
# 通过tag的id查找
soup.select("a#link2")
```


```python
# 通过属性的值来查找
soup.select('a[href^="http://example.com/"]')
```

> 输出


```python
# 格式化输出
# prettify() 方法将Beautiful Soup的文档树格式化后以Unicode编码输出,每个XML/HTML标签都独占一行
print(soup.prettify())
```


```python
# 压缩输出
str(soup)
```

## 四、实战项目

[『实战项目ipynb文档』](https://gitee.com/iherr/ipynb/tree/master/crawler)

[『实战项目代码』](https://gitee.com/iherr/ipynb/tree/master/crawler)


> 链家

使用BeautifulSoup

```python
import requests

from bs4 import BeautifulSoup

def get_soup(url):
    headers={'User-Agent':'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.62 Safari/537.36'}
    response=requests.get(url,headers=headers)
    soup=BeautifulSoup(response.text)
    return soup

#以上步骤封装成的函数，用于获取链家租房列表的所有链接
def get_links(url):
    soup=get_soup(url)
    links_div=soup.findAll('div',class_='content__list--item')
    links=['https://bj.lianjia.com'+div.a.get('href') for div in links_div]
    return links

## 封装房屋详情
def get_house_info(house_url):
    soup=get_soup(house_url)
    price_info=soup.find('p',class_='content__aside--title')
    price=price_info.text
    info=soup.find('p',class_='content__article__table')
    area=info.contents[5].text
    layout=info.contents[3].text
    direction=info.contents[7].text
    infos={
    '价格':price,
    '面积':area,
    '户型':layout,
    '朝向':direction,
    }
    print(infos)
    return infos

if __name__=='__main__':
    url='https://bj.lianjia.com/zufang'
    links=get_links(url)
    for house_url in links:
        get_house_info(house_url)
```

> 酷狗


使用BeautifulSoup

```python
import requests

from bs4 import BeautifulSoup

import time

f=open('file/kugou.txt','a+')

def get_soup(url):
    headers={'User-Agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36'}
    response=requests.get(url,headers=headers)
    soup=BeautifulSoup(response.text)
    return soup

def get_info(info_url):
    info_soup=get_soup(info_url)

    ranks=info_soup.select('span.pc_temp_num')
    titles=info_soup.select('#rankWrap >div > ul > li > a')
    times=info_soup.select('span.pc_temp_time')
    for rank,title,time in zip(ranks,titles,times):
        data={'rank':rank.get_text().strip(),
             'title':title.get_text().strip(),
             'time':time.get_text().strip(),
             }
        print(data)
        f.write(str(data) +'\n')

if __name__=='__main__':
    url='http://www.kugou.com/yy/rank/home/{}-8888.html'
    urls=[url.format(str(i)) for i in range(1,24)]
    for singleurl in urls:
        get_info(singleurl)
```

> 小猪短租

使用BeautifulSoup

```python
import requests

from bs4 import BeautifulSoup

import time

def get_soup(url):
    headers={'User-Agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36'}
    response=requests.get(url,headers=headers)
    soup=BeautifulSoup(response.text)
    return soup

def get_sex(class_name):
    if class_name==['member_boy_ico']:
        return '男'
    else:
        return '女'


def get_info(info_url):
    info_soup=get_soup(info_url)
    titles=info_soup.select('div.pho_info>h4')

    addresses=info_soup.select('span.pr5')
    prices=info_soup.select('#pricePart > div.day_l > span')
    imgs=info_soup.select('div.pho_show_big > div > img#curBigImage')
    names=info_soup.select('a.lorder_name')
    sexs=info_soup.select('div.js_box>div>h6>span')

    for title,address,price,img,name,sex in zip(titles,addresses,prices,imgs,names,sexs):
        data={'title':title.get_text().strip(),
             'address':address.get_text().strip(),
             'price':price.get_text().strip(),
             'img':img.get("src"),
             'sex':get_sex(sex.get("class")),
             }
    print(data)

def get_link(url):
    soup =get_soup(url)
    links=soup.select('#page_list > ul > li >a')
    for link in links:
        href=link.get("href")
        #print(href)
        get_info(href)

if __name__ == '__main__':
    urls=['http://bj.xiaozhu.com/search-duanzufang-p{}-0/'.format(number) for number in range(1,15)]
    for single_url in urls:
        get_link(single_url)
        time.sleep(15)
```

> 糗事百科

使用re正则匹配

```python
import requests
import re
import time

def get_res(url):
    headers={'User-Agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36'}
    response=requests.get(url,headers=headers)
    return response.text


def get_info(info_url):
    info_res = get_res(info_url)

    ids = re.findall('<h2>(.*?)</h2>', info_res, re.S)
    levels = re.findall('<div class="articleGender \D+Icon">(.*?)</div>', info_res, re.S)
    sexs = re.findall('<div class="articleGender (\D+)Icon">.*?</div>', info_res, re.S)
    contents = re.findall('<div class="content">.*?<span>(.*?)</span>.*?</div>', info_res, re.S)
    laughs = re.findall('<span class="stats-vote"><i class="number">(\d+)</i>', info_res, re.S)
    comments = re.findall('<i class="number">(\d+)</i> 评论', info_res, re.S)
    #     print(comments)
    for ida, level, sex, content, laugh, comment in zip(ids, levels, sexs, contents, laughs, comments):
        data = {'ida': ida.strip(),
                'level': level.strip(),
                'sex': sex.strip(),
                'content': content.strip(),
                'laugh': laugh.strip(),
                'comment': comment.strip(),
                }
        print(data)

if __name__=='__main__':
    url='https://www.qiushibaike.com/text/page/{}/'
    urls=[url.format(str(i)) for i in range(0,20)]
    for url_single in urls:
        get_info(url)
        time.sleep(2)
```

> 豆瓣

使用lxml和csv，注意Xpath语法

```python
from lxml import etree
import requests
import csv

def get_res(url):
    headers={'User-Agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36'}
    response=requests.get(url,headers=headers)
    return response.text

def get_info():
    format_url='https://book.douban.com/top250?start={}'
    urls=[format_url.format(str(i)) for i in range(0,250,25)]
    for url in urls:
        selector=etree.HTML(get_res(url))
        infos=selector.xpath('//tr[@class="item"]')
        for info in infos:
            name=info.xpath('td[2]/div[1]/a/@title')[0]
            url_info=info.xpath('td[2]/div[1]/a/@href')[0]

            book_info=info.xpath('td[2]/p[1]/text()')[0]
            price=book_info.split('/')[-1]
            date=book_info.split('/')[-2]
            publisher=book_info.split('/')[-3]
            author=book_info.split('/')[0]
            rate=info.xpath('td[2]/div[2]/span[2]/text()')[0]
            comments=info.xpath('td[2]/p[2]/span/text()')
            comment = comments[0] if len(comments) != 0 else '空'
            writer.writerow ((name,url_info,author,publisher, date,price,
        rate, comment))
            #print(comment)


if __name__=='__main__':
    fp = open('file/doubanbook.csv', 'wt', newline='', encoding='utf_8_sig')

    writer = csv.writer(fp)
    writer.writerow(('name', 'url', 'author', 'publisher', 'date', 'price',
                     'rate', 'comment'))
    get_info()
    fp.close()
```

> 起点

使用lxml和xlwt

```python
from lxml import etree
import requests
import xlwt
import time


def get_res(url):
    headers={'User-Agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36'}
    response=requests.get(url,headers=headers)
    return response.text

def get_info():
    format_url='https://www.qidian.com/all?page={}'
    # 前10页
    urls=[format_url.format(str(i)) for i in range(1,11)]
    for url in urls:
        selector=etree.HTML(get_res(url))
        infos=selector.xpath('//ul[@class="all-img-list cf"]/li')
        for info in infos:
            title=info.xpath('div[2]/h4/a/text()')[0]
            author=info.xpath('div[2]/p[1]/a[1]/text()')[0]
            style_1=info.xpath('div[2]/p[1]/a[2]/text()')[0]
            style_2=info.xpath('div[2]/p[1]/a[3]/text()')[0]
            style=style_1+'-'+style_2
            complete=info.xpath('div[2]/p[1]/span/text()')[0]
            introduce=info.xpath('div[2]/p[2]/text()')[0].strip()
            info_list=[title,author,style,complete,introduce]
            all_info_list.append(info_list)
        time.sleep(1)


if __name__=='__main__':
    all_info_list = []
    get_info()
    book = xlwt.Workbook(encoding='utf-8')
    sheet= book.add_sheet('Sheetl')
    header= ['title','author','style','complete','introduce']
    for h in range(len(header)):
        sheet.write(0, h, header[h])
    i=1
    for list in all_info_list:
        j=0
        for data in list:
            sheet.write(i, j, data)
            j+=1
        i+=1
    book.save('file/qidian.xls')
```


## 五、多进程爬虫

在糗事百科demo基础上，增加多进程爬虫测试。效果如下：

```python

from multiprocessing import Pool

if __name__=='__main__':
    url='https://www.qiushibaike.com/text/page/{}/'
    urls=[url.format(str(i)) for i in range(0,20)]
    start_1=time.time()
    for url_single in urls:
        get_info(url)
    end_1=time.time()
    print('串行爬虫:',end_1-start_1)

    start_2 = time.time()
    pool = Pool(processes=2)
    pool.map(get_info, urls)
    end_2 = time.time()
    print('两个进程:',end_2-start_2)

    start_3 = time.time()
    pool = Pool(processes=4)
    pool.map(get_info, urls)
    end_3 = time.time()
    print('四个进程:',end_3-start_3)
```

运行结果如下，多进程运行时，任务管理器有多个Python进程同时运行：

```bash
串行爬虫: 5.448936939239502
两个进程: 2.779062032699585
四个进程: 1.0085301399230957
```

## 六、selenium

> 介绍

Selenium是一个用于Web应用程序测试的工具，Selenium直接运行在浏览器中，就像真正的用户在操作一样。Selenium也是一个强大的网络数据采集工具，其可以让浏览器自动加载页面，这样，使用了异步加载技术的网页，也可获取其需要的数据，避免进行逆向工程。
phantomjs就建议不要装了。第一费劲，第二selenium新版已不推荐。还是使用chrome好了。

chrome需要下载[『chromedriver』](http://npm.taobao.org/mirrors/chromedriver/) ，需要下载对应的版本。不一定非要放到/usr/bin，放到这个路径需要做权限设置，十分麻烦，可随意放个地方，然后
  
```bash
$ open ~/.bash_profile
#在.bash_profile中添加路径，如果chromedriver的位置在/Users/iherr/chrome/bin/chromedriver
$ export PATH=$PATH:/Users/iherr/chrome/bin:$PATH
# 保存文件后再执行后面
$ source .bash_profile
# 查看版本号，如有显示证明安装成功
$ chromedriver -v
```

> 示例

```python
from selenium import webdriver

def get_info(url):
    include_title =[]
    driver = webdriver.Chrome()
    driver.get(url)
    driver.implicitly_wait(20)
    author = driver.find_element_by_xpath('//span[@class="name"]/a').text
    date = driver.find_element_by_xpath('//span[@class="publish-time"]').text
    word = driver.find_element_by_xpath('//span[@class="wordage"]').text
    view = driver.find_element_by_xpath('//span[@class="views-count"]').text
    comment = driver.find_element_by_xpath('//span[@class="comments-count"]').text
    like = driver.find_element_by_xpath('//span[@class="likes-count"]').text
    included_names = driver.find_elements_by_xpath('//div[@class="include-collection"]/a/div')
    for i in included_names:
        include_title.append(i.text)
    print(author,date,word,view,comment,like,include_title)

url = 'http://www.jianshu.com/p/c9bae3e9e252'
get_info(url)
```

## 七、爬虫框架

* Scrapy [『传送门』](https://scrapy.org) [『文档传送门』](https://docs.scrapy.org/en/latest/)
* Crawley  [『传送门』](http://project.crawley-cloud.com)
* PySpider  [『传送门』](https://github.com/binux/pyspider/releases)

> Scrapy

Scrapy是一个用 Python 写的 Crawler Framework ，简单轻巧，并且非常方便。Scrapy 使用 Twisted 这个异步网络库来处理网络通讯，架构清晰，并且包含了各种中间件接口，可以灵活的完成各种需求。整体架构如下图所示

![](Python爬虫/scrapy.png)

绿线是数据流向，首先从初始 URL 开始，Scheduler 会将其交给 Downloader 进行下载，下载之后会交给 Spider 进行分析，Spider 分析出来的结果有两种：一种是需要进一步抓取的链接，例如之前分析的“下一页”的链接，这些东西会被传回 Scheduler ；另一种是需要保存的数据，它们则被送到 Item Pipeline 那里，那是对数据进行后期处理（详细分析、过滤、存储等）的地方。另外，在数据流动的通道里还可以安装各种中间件，进行必要的处理。

```bash
$ pip3 install scrapy
$ scrapy startproject PROJECTNAME
$ scrapy crawl PROJECTNAME
```

创建好的工程目录结构如下：

* spiders/spider.py，Spider蜘蛛
* items.py，对要爬取数据的模型定义
* pipelines.py，对爬虫数据的处理
* middlewares.py，爬虫中间件
* settings.py，对爬虫的配置，请求header、设置pipelines等

> 实例

以爬取简书推荐作者页面为例：

1、items.py

```python
from scrapy.item import Item,Field

class AuthorItem(Item):
    author_url = Field()
    author_name = Field()
    new_article = Field()
    style = Field()
    focus = Field()
    fans = Field()
    article_num = Field()
    write_num = Field()
    like = Field()
    pass
```

2、setting.py

```python
BOT_NAME = 'author'

SPIDER_MODULES = ['author.spiders']
NEWSPIDER_MODULE = 'author.spiders'

# Obey robots.txt rules
ITEM_PIPELINES = {'author.pipelines.AuthorPipeline':300}
ROBOTSTXT_OBEY = False
DOWNLOAD_DELAY=0.5
USER_AGENT = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36'
```

3、pipelines.py

```python
import pymongo

class AuthorPipeline(object):
    def __init__(self):
        client = pymongo.MongoClient('localhost', 27017)
        test = client['mydb']
        author = test['author']
        self.post = author
    def process_item(self, item, spider):
        info = dict(item)
        self.post.insert(info)
        return item
```

4、authorspider.py

```python
from scrapy.spiders import CrawlSpider
from scrapy.selector import Selector
from scrapy.http import Request
from author.items import AuthorItem

class author(CrawlSpider):
    name = 'author'
    start_urls = ['http://www.jianshu.com/recommendations/users?page=1']

    def parse(self, response):
        base_url = 'http://www.jianshu.com/u/'
        selector = Selector(response)
        infos = selector.xpath('//div[@class="col-xs-8"]')
        for info in infos:
            relative_url=info.xpath('div/a/@href').extract()[0]
            author_url = base_url + relative_url.split('/')[-1]
            author_name = info.xpath('div/a/h4/text()').extract()[0]
            article = info.xpath('div/div[@class="recent-update"]')[0]
            new_article = article.xpath('string(.)').extract()[0].strip('\n').replace(' ','').replace('\n','')
            yield Request(author_url,meta={'author_url':author_url,'author_name':author_name,'new_article':new_article},callback=self.parse_item)

        urls = ['http://www.jianshu.com/recommendations/users?page={}'.format(str(i)) for i in range(2,3)]
        for url in urls:
            yield Request(url,callback=self.parse)

    def parse_item(self,response):
        item = AuthorItem()
        item['author_url'] = response.meta['author_url']
        item['author_name'] = response.meta['author_name']
        item['new_article'] = response.meta['new_article']

        try:
            selector = Selector(response)
            if selector.xpath('//span[@class="author-tag"]'):
                style = '签约作者'
            else:
                style = '普通作者'
            focus = selector.xpath('//div[@class="info"]/ul/li[1]/div/a/p/text()').extract()[0]
            fans = selector.xpath('//div[@class="info"]/ul/li[2]/div/a/p/text()').extract()[0]
            article_num = selector.xpath('//div[@class="info"]/ul/li[3]/div/a/p/text()').extract()[0]
            write_num = selector.xpath('//div[@class="info"]/ul/li[4]/div/p/text()').extract()[0]
            like = selector.xpath('//div[@class="info"]/ul/li[5]/div/p/text()').extract()[0]

            item['style'] = style
            item['focus'] = focus
            item['fans'] = fans
            item['article_num'] = article_num
            item['write_num'] = write_num
            item['like'] = like
            yield item
        except IndexError:
            pass
```

5、main.py

```python
from scrapy import cmdline
cmdline.execute("scrapy crawl author".split())
```

> 相关代码

[『scrapy项目代码』](https://gitee.com/iherr/scrapy)