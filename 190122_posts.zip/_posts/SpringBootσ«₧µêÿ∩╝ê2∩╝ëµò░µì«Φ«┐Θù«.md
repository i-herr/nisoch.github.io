---
title: SpringBoot实战（2）数据访问
date: 2017-04-03 18:25:44
tags: [SpringBoot,Java,MyBatis]
---

## 一、Spring Data

> Spring Data

是Spring用来解决数据访问问题的一揽子解决方案，包含了大量关系型和非关系型数据库的数据访问方案。

常见项目包含：

| 项目名称 | Maven坐标 org.springframework.data |
| -------  |:---: 	|
|	Spring Data Jpa	|	spring-data-jpa	|
|	Spring Data MongoDB |	spring-data-mongodb |
|	Spring Data Redis |	spring-data-redis|
|	Spring Data Solr |	spring-data-solr|
|	Spring Data Hadoop |	spring-data-hadoop|
|	Spring Data REST |	spring-data-rest-webmvc|
|	Spring Data JDBC Ext |	spring-data-oracle|

> JDBC相关

![](SpringBoot实战（2）数据访问/jdbc2.jpg)

![](SpringBoot实战（2）数据访问/jdbc1.jpg)


## 二、Spring Data JPA
> 基本概念

1、Hibernate主导了EJB3.0的JPA（Java Persistence API）规范。

2、继承JpaRepository接口，即可拥有默认数据访问操作方法，如findAll，getOne等。

```java
@Repository
public interface PersonRepository extends JpaRepository<Person, Long>{

}
```

3、在Spring中，需要使用注解@EnableJPARepository来开启JPA支持。

> 定义查询方法

1、常规查询
根据属性名查询，使用findBy、Like、And、IsNull、In、OrderBy等关键字来定义查询方法。

```java 
Person findByNameAndAddress(String name,String address);
```
通过top和first关键字来限制结果数量。

2、JPA的NamedQuery查询

Spring Data JPA支持用JPA的NamedQuery查询防范，即一个名称映射一个查询语句。

3、@Query查询，直接将@Query注解在接口的方法上实现查询。

``` java
@Query("select p from Person p where p.name= :name and p.address= :address")
Person withNameAndAddressQuery(@Param("name")String name, @Param("address")String address);
```

4、排序与分页，提供了Sort类以及Page接口和Pageable接口。

> Spring Boot的支持

1、JDBC的自动配置  
在org.springframework.boot.autoconfigure.jdbc下。

2、对JPA的自动配置  
在org.springframework.boot.autoconfigure.orm.jpa下。其中JpaBaseConfiguration会自动扫描注解有@Entity的实体类。

3、对Spring Data JPA的自动配置  
在org.springframework.boot.autoconfigure.data.jpa下。JpaRepositoriesAutoConfiguration依赖于HibernateJpaAutoConfiguration配置。

<!--more-->

4、Spring Boot下的Spring Data JPA  
如需使用，maven依赖中添加spring-boot-starter-data-jpa，然后只需定义DataSource、实体类和数据访问层，并在需要使用数据访问的地方注入数据访问层的Bean即可。

## 三、Spring data REST

Spring Boot通过SpringBootRepositoryRestMVCConfiguration类自动配置了RepositoryRestConfiguration，因此只需要引入依赖即可。

```bash
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-data-rest</artifactId>
		</dependency>
```

properties配置文件定制rest根路径api。

```bash
	spring.data.rest.base-path= /api
```

使用注解自动实现REST接口，并定制节点路径people。
``` java

@RepositoryRestResource(path = "people")
public interface PersonRepository extends JpaRepository<Person, Long> {
	
	@RestResource(path = "nameStartsWith", rel = "nameStartsWith")
	Person findByNameStartsWith(@Param("name")String name);

}
```


## 四、声明式事务

> 所有的数据访问技术都有事务处理机制

| 数据访问技术 | 实现 |
| -------  |:---: 	|
|	JDBC	|	DataSourceTransactionManager|
|	JPA |	JpaTransactionManager |
|	Hibernate |	Hibernate TransactionManager |
|	JDO |	JdoTransactionManager |
|	分布式事务 |	JtaTransactionManager |

> @Transactional注解

Transactional（来自org.springframework.transaction.annotation包）基于AOP的实现操作，被注解的方法在被调用时开启事务。

Spring提供一个@EnableTransactionManagement注解在配置类来开启声明式事务的支持，Spring容器会自动扫描注解@Transactional的方法和类。

属性包括：  
1、propagation生命周期，默认为REQUIRED。  
2、isolation隔离级别确定了事务的完整性。默认为DEFAULT，使用数据库的默认隔离级别。Mysql是REPEATABLE_READ，Oracle是READ_COMMITTED。  
3、readOnly，只读事务，默认false  
4、timeout，事务过期时间  
5、rollbackFor，noRollbackFor，指定哪些异常（不）可以引起事务回滚

例如当捕获某个异常时进行回滚操作。
@Transactional(rollbackFor={IllegalArgumentException.class})

> Spring Boot的事务支持

1、自动配置的事务管理器

使用JDBC作为数据访问技术时，DataSourceTransactionManagerAutoConfiguration类定义了DataSourceTransactionManager的Bean。

使用JPA作为数据访问技术时，or.jpa.JpaBaseConfiguration类定义了JpaTransactionManager的Bean。

2、自动开启注解事务的支持  
transaction.TransactionAutoConfiguration类，依赖于上面两个类。在Spring Boot中无须显示开启使用@EnableTransactionManagement注解。


## 五、Mybatis
ORM层基本就是两大阵营，JPA（Hibernate可看做是JPA规范的实现，Spring data JPA是spring提供的一套简化JPA开发的框架，底层还是使用了 Hibernate 的 JPA 技术实现）和Mybatis，至于两者优劣，各有之。有人喜欢轻量灵活用Mybatis，而从软件设计角度JPA更加符合规范。

Mybatis项目添加的依赖如下：包含mysql连接和druid连接池。

``` bash
<dependency>
    <groupId>mysql</groupId>
    <artifactId>mysql-connector-java</artifactId>
    <scope>runtime</scope>
</dependency>
<dependency>
	<groupId>org.mybatis.spring.boot</groupId>
	<artifactId>mybatis-spring-boot-starter</artifactId>
	<version>1.3.2</version>
</dependency>
<!-- alibaba的druid数据库连接池 -->
<dependency>
    <groupId>com.alibaba</groupId>
    <artifactId>druid-spring-boot-starter</artifactId>
    <version>1.1.9</version>
</dependency>
```

yml文件配置如下：

```xml
spring:
  datasource:
    name: mysql
    type: com.alibaba.druid.pool.DruidDataSource
    #druid相关配置
    druid:
      #监控统计拦截的filters
      filters: stat
      driver-class-name: com.mysql.jdbc.Driver
      #基本属性
      url: jdbc:mysql://127.0.0.1:3306/auto?useUnicode=true&characterEncoding=UTF-8&allowMultiQueries=true
      username: root
      password: 123
      #配置初始化大小/最小/最大
      initial-size: 1
      min-idle: 1
      max-active: 20
      #获取连接等待超时时间
      max-wait: 60000
      #间隔多久进行一次检测，检测需要关闭的空闲连接
      time-between-eviction-runs-millis: 60000
      #一个连接在池中最小生存的时间
      min-evictable-idle-time-millis: 300000
      validation-query: SELECT 'x'
      test-while-idle: true
      test-on-borrow: false
      test-on-return: false
      pool-prepared-statements: false
      max-pool-prepared-statement-per-connection-size: 20

mybatis:
  mapper-locations: classpath:mapping/*.xml  #对应mapper映射xml文件的所在路径
  type-aliases-package: com.herr.model  #对应实体类的路径
```

相关代码目录如下：

![](SpringBoot实战（2）数据访问/catalog.jpg)
UserMapper.java，UserMapper.xml，user.Java文件可使用Mybatis插件自动生成。

``` bash
<plugin>
    <groupId>org.mybatis.generator</groupId>
    <artifactId>mybatis-generator-maven-plugin</artifactId>
    <version>1.3.2</version>
    <configuration>
        <configurationFile>${basedir}/src/main/resources/generator/generatorConfig.xml</configurationFile>
        <overwrite>true</overwrite>
        <verbose>true</verbose>
    </configuration>
</plugin>
```

使用如下命令生成：

``` bash
mybatis-generator:generate -e
```

## 六、druid相关

[『druid-spring-boot-starter集成传送门』](https://github.com/alibaba/druid/tree/master/druid-spring-boot-starter)：  
可访问http://localhost:8080/druid/sql.html 查看数据库连接池相关情况。

>数据源以及SpringBoot的自动配置原理

找到org.springframework.boot.autoconfigure.jdbc包下的DataSourceConfiguration类，原理大概是如果在classpath下存在org.apache.tomcat.jdbc.pool.DataSource.class类，并且在配置文件中指定spring.datasource.type的值为org.apache.tomcat.jdbc.pool.DataSource，或者不写都会认为可以通过。只有通过才会进入这段配置代码，才能注入DataSourceBean。

SpringBoot默认可以支持；

org.apache.tomcat.jdbc.pool.DataSource、HikariDataSource、BasicDataSource等。通过以下方式可自定义数据源。


```java
 @ConditionalOnMissingBean(DataSource.class)
    @ConditionalOnProperty(name = "spring.datasource.type")
    static class Generic {
        @Bean
        public DataSource dataSource(DataSourceProperties properties) {
            //使用DataSourceBuilder创建数据源，利用反射创建响应type的数据源，并且绑定相关属性
            return properties.initializeDataSourceBuilder().build();
        }
    }
```

> 数据库连接池

![](SpringBoot实战（2）数据访问/connect_pool.jpg)

当我们使用了如上所述的默认数据源之后，那么已默认启用了数据库链接池。 

Spring Boot为我们准备了最佳的数据库连接池方案，只需要在属性文件（例如application.properties）中配置需要的连接池参数即可。

Tomcat7之前，Tomcat本质应用了DBCP连接池技术来实现的JDBC数据源，但在Tomcat7之后，Tomcat提供了新的JDBC连接池方案，作为DBCP的替换或备选方案，解决了许多之前使用DBCP的不利之处，并提高了性能。

在引入spring-boot-starter-jdbc后，内部包含了tomcat-jdbc包，里面有tomcat连接池.然后通过自动配置DataSourceAutoConfigurer创建DataSource对象。

SpringBoot创建默认DataSource时，规则如下：

* 优先寻找创建Tomcat连接池
* 如果没有Tomcat连接池，会查找创建HikariCP
* 如果没有HikariCP连接池，会查找创建dbcp
* 如果没有dbcp连接池，会查找创建dbcp2
* 可以在yml使用spring.datasource.type属性指定连接池类型