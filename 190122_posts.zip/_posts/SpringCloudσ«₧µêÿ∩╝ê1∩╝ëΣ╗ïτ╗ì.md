---
title: SpringCloud实战（1）介绍
date: 2017-07-03 16:12:05
tags:
---

## 一、Spring Cloud

> 特点

* 约定优于配置
* 使用各种环境
* 隐藏组件复杂性，提供声明式、无xml配置方式
* 开箱即用
* 轻量级组件
* 组件丰富，功能齐全。
* 选型中立、丰富。
* 灵活。组成部分解耦。

> 版本

已发布Angel、Brixton、Camden、Dalston、Edgware、Finchley版本（伦敦地铁名称），按照首字母顺序，是主版本。
以Release版本为初始版本，SR（Service Release）代表Bug修复版本。如Dalston SR4，表示Dalston版本的第4次Bug修复版本。

* Dalston、Edgware都是基于Spring Boot 1.5.x构建，不兼容Spring Boot 2.0.x。
* Finchley基于Spring Boot 2.0.x构建，不兼容Spring Boot 1.x。

> 子项目

组件包含spring-cloud-aws、spring-cloud-bus、、spring-cloud-cli、spring-cloud-commons、spring-cloud-contract、spring-cloud-config、spring-cloud-netflix、spring-cloud-security、spring-cloud-cloudfoundry、spring-cloud-consul、spring-cloud-sleuth、spring-cloud-stream、spring-cloud-zookeeper、spring-cloud-task、spring-cloud-vault、spring-cloud-gateway、spring-boot等。

## 各组件问题汇总

## 各组件超时

## 各组件重试

## 各组件属性调优

## 参考资源

* 各项目自身的Github
* SpringCloud对应项目的Github
* SpringCloud的StackOverflow
* SpringCloud的Gitter

