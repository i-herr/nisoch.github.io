---
title: Python数据分析（2）Pandas
date: 2018-11-27 10:45:56
tags:
---


> 简介

* Pandas是Python的一个数据分析包，该工具为解决数据分析任务而创建。
* Pandas纳入大量库和标准数据模型，提供高效的操作数据集所需的工具。
* Pandas提供大量能使我们快速便捷地处理数据的函数和方法。
* Pandas是字典形式，基于NumPy创建，让NumPy为中心的应用变得更加简单。
* 对于金融行业的用户，pandas提供了大量适用于金融数据的高性能时间序列功能和工具。
* Excel 2007及其以后的版本的最大行数是1048576，最大列数是16384，超过这个规模的数据可使用Pandas


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
```

> Series


```python
s = pd.Series([1,3,5,np.nan,6,8])
s
```




    0    1.0
    1    3.0
    2    5.0
    3    NaN
    4    6.0
    5    8.0
    dtype: float64



> DataFrame


```python
dates = pd.date_range('20170101', periods=6)
dates
```




    DatetimeIndex(['2017-01-01', '2017-01-02', '2017-01-03', '2017-01-04',
                   '2017-01-05', '2017-01-06'],
                  dtype='datetime64[ns]', freq='D')




```python
df = pd.DataFrame(np.random.randn(6,4), index=dates, columns=list('ABCD'))
df
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-01-01</th>
      <td>-0.119313</td>
      <td>-0.165029</td>
      <td>-1.065599</td>
      <td>0.224712</td>
    </tr>
    <tr>
      <th>2017-01-02</th>
      <td>-0.423993</td>
      <td>0.705954</td>
      <td>-0.349143</td>
      <td>-0.208349</td>
    </tr>
    <tr>
      <th>2017-01-03</th>
      <td>0.259465</td>
      <td>0.896735</td>
      <td>0.033814</td>
      <td>-1.135184</td>
    </tr>
    <tr>
      <th>2017-01-04</th>
      <td>-1.568006</td>
      <td>0.685092</td>
      <td>-0.931491</td>
      <td>0.323591</td>
    </tr>
    <tr>
      <th>2017-01-05</th>
      <td>0.050029</td>
      <td>1.938641</td>
      <td>-0.193642</td>
      <td>0.199692</td>
    </tr>
    <tr>
      <th>2017-01-06</th>
      <td>-0.041061</td>
      <td>-0.845943</td>
      <td>1.542987</td>
      <td>0.354031</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
df.head(3)
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-01-01</th>
      <td>0.197225</td>
      <td>-0.666883</td>
      <td>0.855806</td>
      <td>0.253851</td>
    </tr>
    <tr>
      <th>2017-01-02</th>
      <td>-0.291572</td>
      <td>0.011976</td>
      <td>-1.502192</td>
      <td>0.051144</td>
    </tr>
    <tr>
      <th>2017-01-03</th>
      <td>-0.670941</td>
      <td>1.815718</td>
      <td>0.503071</td>
      <td>0.361448</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
df.tail(3)
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-01-04</th>
      <td>0.465035</td>
      <td>0.465077</td>
      <td>-0.018313</td>
      <td>1.338603</td>
    </tr>
    <tr>
      <th>2017-01-05</th>
      <td>-0.646332</td>
      <td>1.261231</td>
      <td>0.058086</td>
      <td>-1.643476</td>
    </tr>
    <tr>
      <th>2017-01-06</th>
      <td>0.375105</td>
      <td>0.247912</td>
      <td>0.998861</td>
      <td>-0.114123</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
df2 = pd.DataFrame({ 'A' : 1.,
                     'B' : pd.Timestamp('20130102'),
                     'C' : pd.Series(1,index=list(range(4)),dtype='float32'), 
                     'D' : np.array([3] * 4,dtype='int32'),
                     'E' : pd.Categorical(["test","train","test","train"]),
                     'F' : 'foo' })
df2
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>E</th>
      <th>F</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>2013-01-02</td>
      <td>1.0</td>
      <td>3</td>
      <td>test</td>
      <td>foo</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1.0</td>
      <td>2013-01-02</td>
      <td>1.0</td>
      <td>3</td>
      <td>train</td>
      <td>foo</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.0</td>
      <td>2013-01-02</td>
      <td>1.0</td>
      <td>3</td>
      <td>test</td>
      <td>foo</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1.0</td>
      <td>2013-01-02</td>
      <td>1.0</td>
      <td>3</td>
      <td>train</td>
      <td>foo</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
df2.dtypes
```




    A           float64
    B    datetime64[ns]
    C           float32
    D             int32
    E          category
    F            object
    dtype: object




```python
# 列的序号名字
df2.columns
```




    Index(['A', 'B', 'C', 'D', 'E', 'F'], dtype='object')




```python
# 行的序号
df2.index
```




    Int64Index([0, 1, 2, 3], dtype='int64')




```python
# 把每个值进行打印出来
df2.values
```




    array([[1.0, Timestamp('2013-01-02 00:00:00'), 1.0, 3, 'test', 'foo'],
           [1.0, Timestamp('2013-01-02 00:00:00'), 1.0, 3, 'train', 'foo'],
           [1.0, Timestamp('2013-01-02 00:00:00'), 1.0, 3, 'test', 'foo'],
           [1.0, Timestamp('2013-01-02 00:00:00'), 1.0, 3, 'train', 'foo']],
          dtype=object)




```python
# 数字总结
df2.describe()
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>C</th>
      <th>D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>4.0</td>
      <td>4.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>std</th>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>3.0</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
# 翻转数据
df2.T
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>A</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>B</th>
      <td>2013-01-02 00:00:00</td>
      <td>2013-01-02 00:00:00</td>
      <td>2013-01-02 00:00:00</td>
      <td>2013-01-02 00:00:00</td>
    </tr>
    <tr>
      <th>C</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>D</th>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
    </tr>
    <tr>
      <th>E</th>
      <td>test</td>
      <td>train</td>
      <td>test</td>
      <td>train</td>
    </tr>
    <tr>
      <th>F</th>
      <td>foo</td>
      <td>foo</td>
      <td>foo</td>
      <td>foo</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
# axis等于1按列进行排序 如ABCDEFG 然后ascending倒叙进行显示
df2.sort_index(axis=1, ascending=False)
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>F</th>
      <th>E</th>
      <th>D</th>
      <th>C</th>
      <th>B</th>
      <th>A</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>foo</td>
      <td>test</td>
      <td>3</td>
      <td>1.0</td>
      <td>2013-01-02</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>foo</td>
      <td>train</td>
      <td>3</td>
      <td>1.0</td>
      <td>2013-01-02</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>foo</td>
      <td>test</td>
      <td>3</td>
      <td>1.0</td>
      <td>2013-01-02</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>foo</td>
      <td>train</td>
      <td>3</td>
      <td>1.0</td>
      <td>2013-01-02</td>
      <td>1.0</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
#axis等于0按行进行排序 如0123 然后ascending倒叙进行显示
df2.sort_index(axis=0, ascending=False) 
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>E</th>
      <th>F</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3</th>
      <td>1.0</td>
      <td>2013-01-02</td>
      <td>1.0</td>
      <td>3</td>
      <td>train</td>
      <td>foo</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.0</td>
      <td>2013-01-02</td>
      <td>1.0</td>
      <td>3</td>
      <td>test</td>
      <td>foo</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1.0</td>
      <td>2013-01-02</td>
      <td>1.0</td>
      <td>3</td>
      <td>train</td>
      <td>foo</td>
    </tr>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>2013-01-02</td>
      <td>1.0</td>
      <td>3</td>
      <td>test</td>
      <td>foo</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
#按值进行排序
df2.sort_values(by='E') 
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>E</th>
      <th>F</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>2013-01-02</td>
      <td>1.0</td>
      <td>3</td>
      <td>test</td>
      <td>foo</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.0</td>
      <td>2013-01-02</td>
      <td>1.0</td>
      <td>3</td>
      <td>test</td>
      <td>foo</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1.0</td>
      <td>2013-01-02</td>
      <td>1.0</td>
      <td>3</td>
      <td>train</td>
      <td>foo</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1.0</td>
      <td>2013-01-02</td>
      <td>1.0</td>
      <td>3</td>
      <td>train</td>
      <td>foo</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
df['A']
```




    2017-01-01    0.549772
    2017-01-02    0.969333
    2017-01-03    0.106553
    2017-01-04    0.465035
    2017-01-05   -0.646332
    2017-01-06    0.375105
    Freq: D, Name: A, dtype: float64




```python
#切片选择
df[0:3] 
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-01-01</th>
      <td>0.549772</td>
      <td>-0.677954</td>
      <td>0.616294</td>
      <td>1.032977</td>
    </tr>
    <tr>
      <th>2017-01-02</th>
      <td>0.969333</td>
      <td>-0.067681</td>
      <td>-0.784801</td>
      <td>0.800007</td>
    </tr>
    <tr>
      <th>2017-01-03</th>
      <td>0.106553</td>
      <td>-1.707697</td>
      <td>0.668063</td>
      <td>0.345128</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
df['20170102':'20170104']
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-01-02</th>
      <td>0.969333</td>
      <td>-0.067681</td>
      <td>-0.784801</td>
      <td>0.800007</td>
    </tr>
    <tr>
      <th>2017-01-03</th>
      <td>0.106553</td>
      <td>-1.707697</td>
      <td>0.668063</td>
      <td>0.345128</td>
    </tr>
    <tr>
      <th>2017-01-04</th>
      <td>0.465035</td>
      <td>0.465077</td>
      <td>-0.018313</td>
      <td>1.338603</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
# loc方法为根据行标签label选择
df.loc[dates[0]]
```




    A    0.549772
    B   -0.677954
    C    0.616294
    D    1.032977
    Name: 2017-01-01 00:00:00, dtype: float64




```python
df.loc[dates[0],'A']
```




    0.5497720064165944




```python
df.loc[:,['A','B']]
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-01-01</th>
      <td>0.549772</td>
      <td>-0.677954</td>
    </tr>
    <tr>
      <th>2017-01-02</th>
      <td>0.969333</td>
      <td>-0.067681</td>
    </tr>
    <tr>
      <th>2017-01-03</th>
      <td>0.106553</td>
      <td>-1.707697</td>
    </tr>
    <tr>
      <th>2017-01-04</th>
      <td>0.465035</td>
      <td>0.465077</td>
    </tr>
    <tr>
      <th>2017-01-05</th>
      <td>-0.646332</td>
      <td>1.261231</td>
    </tr>
    <tr>
      <th>2017-01-06</th>
      <td>0.375105</td>
      <td>0.247912</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
df.loc['20170102':'20170104',['A','B']]
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-01-02</th>
      <td>0.969333</td>
      <td>-0.067681</td>
    </tr>
    <tr>
      <th>2017-01-03</th>
      <td>0.106553</td>
      <td>-1.707697</td>
    </tr>
    <tr>
      <th>2017-01-04</th>
      <td>0.465035</td>
      <td>0.465077</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
# iloc方法为根据position选择
df.iloc[3]
```




    A    0.465035
    B    0.465077
    C   -0.018313
    D    1.338603
    Name: 2017-01-04 00:00:00, dtype: float64




```python
df.iloc[3:5,0:2]
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-01-04</th>
      <td>0.465035</td>
      <td>0.465077</td>
    </tr>
    <tr>
      <th>2017-01-05</th>
      <td>-0.646332</td>
      <td>1.261231</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
df.iloc[[1,2,4],[0,2]]
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>C</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-01-02</th>
      <td>0.969333</td>
      <td>-0.784801</td>
    </tr>
    <tr>
      <th>2017-01-03</th>
      <td>0.106553</td>
      <td>0.668063</td>
    </tr>
    <tr>
      <th>2017-01-05</th>
      <td>-0.646332</td>
      <td>0.058086</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
df.iloc[1,1]
```




    -0.06768075680943383




```python
df.iat[1,1]
```




    -0.06768075680943383




```python
# 根据布尔表达式筛选
df[df > 0]
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-01-01</th>
      <td>0.549772</td>
      <td>NaN</td>
      <td>0.616294</td>
      <td>1.032977</td>
    </tr>
    <tr>
      <th>2017-01-02</th>
      <td>0.969333</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.800007</td>
    </tr>
    <tr>
      <th>2017-01-03</th>
      <td>0.106553</td>
      <td>NaN</td>
      <td>0.668063</td>
      <td>0.345128</td>
    </tr>
    <tr>
      <th>2017-01-04</th>
      <td>0.465035</td>
      <td>0.465077</td>
      <td>NaN</td>
      <td>1.338603</td>
    </tr>
    <tr>
      <th>2017-01-05</th>
      <td>NaN</td>
      <td>1.261231</td>
      <td>0.058086</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2017-01-06</th>
      <td>0.375105</td>
      <td>0.247912</td>
      <td>0.998861</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
df[df.A > 0]
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-01-01</th>
      <td>0.549772</td>
      <td>-0.677954</td>
      <td>0.616294</td>
      <td>1.032977</td>
    </tr>
    <tr>
      <th>2017-01-02</th>
      <td>0.969333</td>
      <td>-0.067681</td>
      <td>-0.784801</td>
      <td>0.800007</td>
    </tr>
    <tr>
      <th>2017-01-03</th>
      <td>0.106553</td>
      <td>-1.707697</td>
      <td>0.668063</td>
      <td>0.345128</td>
    </tr>
    <tr>
      <th>2017-01-04</th>
      <td>0.465035</td>
      <td>0.465077</td>
      <td>-0.018313</td>
      <td>1.338603</td>
    </tr>
    <tr>
      <th>2017-01-06</th>
      <td>0.375105</td>
      <td>0.247912</td>
      <td>0.998861</td>
      <td>-0.114123</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
# 使用isin
df2[df2['E'].isin(['train'])]
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>E</th>
      <th>F</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>1.0</td>
      <td>2013-01-02</td>
      <td>1.0</td>
      <td>3</td>
      <td>train</td>
      <td>foo</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1.0</td>
      <td>2013-01-02</td>
      <td>1.0</td>
      <td>3</td>
      <td>train</td>
      <td>foo</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}



> 设置数据


```python
s1 = pd.Series([1,2,3,4,5,6], index=pd.date_range('20170102', periods=6))
s1
```




    2017-01-02    1
    2017-01-03    2
    2017-01-04    3
    2017-01-05    4
    2017-01-06    5
    2017-01-07    6
    Freq: D, dtype: int64




```python
df['F'] = s1
df
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>F</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-01-01</th>
      <td>0.549772</td>
      <td>-0.677954</td>
      <td>0.616294</td>
      <td>1.032977</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2017-01-02</th>
      <td>0.969333</td>
      <td>-0.067681</td>
      <td>-0.784801</td>
      <td>0.800007</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2017-01-03</th>
      <td>0.106553</td>
      <td>-1.707697</td>
      <td>0.668063</td>
      <td>0.345128</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>2017-01-04</th>
      <td>0.465035</td>
      <td>0.465077</td>
      <td>-0.018313</td>
      <td>1.338603</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>2017-01-05</th>
      <td>-0.646332</td>
      <td>1.261231</td>
      <td>0.058086</td>
      <td>-1.643476</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>2017-01-06</th>
      <td>0.375105</td>
      <td>0.247912</td>
      <td>0.998861</td>
      <td>-0.114123</td>
      <td>5.0</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
df.at[dates[0],'A'] = 0
df
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>F</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-01-01</th>
      <td>0.000000</td>
      <td>-0.677954</td>
      <td>0.616294</td>
      <td>1.032977</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2017-01-02</th>
      <td>0.969333</td>
      <td>-0.067681</td>
      <td>-0.784801</td>
      <td>0.800007</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2017-01-03</th>
      <td>0.106553</td>
      <td>-1.707697</td>
      <td>0.668063</td>
      <td>0.345128</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>2017-01-04</th>
      <td>0.465035</td>
      <td>0.465077</td>
      <td>-0.018313</td>
      <td>1.338603</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>2017-01-05</th>
      <td>-0.646332</td>
      <td>1.261231</td>
      <td>0.058086</td>
      <td>-1.643476</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>2017-01-06</th>
      <td>0.375105</td>
      <td>0.247912</td>
      <td>0.998861</td>
      <td>-0.114123</td>
      <td>5.0</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
df.iat[0,1] = 0
df
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>F</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-01-01</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.616294</td>
      <td>1.032977</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2017-01-02</th>
      <td>0.969333</td>
      <td>-0.067681</td>
      <td>-0.784801</td>
      <td>0.800007</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2017-01-03</th>
      <td>0.106553</td>
      <td>-1.707697</td>
      <td>0.668063</td>
      <td>0.345128</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>2017-01-04</th>
      <td>0.465035</td>
      <td>0.465077</td>
      <td>-0.018313</td>
      <td>1.338603</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>2017-01-05</th>
      <td>-0.646332</td>
      <td>1.261231</td>
      <td>0.058086</td>
      <td>-1.643476</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>2017-01-06</th>
      <td>0.375105</td>
      <td>0.247912</td>
      <td>0.998861</td>
      <td>-0.114123</td>
      <td>5.0</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
# 使用numpy数组
df.loc[:,'D'] = np.array([5] * len(df))
df
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>F</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-01-01</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.616294</td>
      <td>5</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2017-01-02</th>
      <td>0.969333</td>
      <td>-0.067681</td>
      <td>-0.784801</td>
      <td>5</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2017-01-03</th>
      <td>0.106553</td>
      <td>-1.707697</td>
      <td>0.668063</td>
      <td>5</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>2017-01-04</th>
      <td>0.465035</td>
      <td>0.465077</td>
      <td>-0.018313</td>
      <td>5</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>2017-01-05</th>
      <td>-0.646332</td>
      <td>1.261231</td>
      <td>0.058086</td>
      <td>5</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>2017-01-06</th>
      <td>0.375105</td>
      <td>0.247912</td>
      <td>0.998861</td>
      <td>5</td>
      <td>5.0</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
# where语句
df[df > 0] = -df
df
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>F</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-01-01</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>-0.616294</td>
      <td>-5</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2017-01-02</th>
      <td>-0.969333</td>
      <td>-0.067681</td>
      <td>-0.784801</td>
      <td>-5</td>
      <td>-1.0</td>
    </tr>
    <tr>
      <th>2017-01-03</th>
      <td>-0.106553</td>
      <td>-1.707697</td>
      <td>-0.668063</td>
      <td>-5</td>
      <td>-2.0</td>
    </tr>
    <tr>
      <th>2017-01-04</th>
      <td>-0.465035</td>
      <td>-0.465077</td>
      <td>-0.018313</td>
      <td>-5</td>
      <td>-3.0</td>
    </tr>
    <tr>
      <th>2017-01-05</th>
      <td>-0.646332</td>
      <td>-1.261231</td>
      <td>-0.058086</td>
      <td>-5</td>
      <td>-4.0</td>
    </tr>
    <tr>
      <th>2017-01-06</th>
      <td>-0.375105</td>
      <td>-0.247912</td>
      <td>-0.998861</td>
      <td>-5</td>
      <td>-5.0</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}



> 处理丢失数据


```python
df1 = df.reindex(index=dates[0:4], columns=list(df.columns) + ['E'])
df1.loc[dates[0]:dates[1],'E'] = 1
df1
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>F</th>
      <th>E</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-01-01</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>-0.616294</td>
      <td>-5</td>
      <td>NaN</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2017-01-02</th>
      <td>-0.969333</td>
      <td>-0.067681</td>
      <td>-0.784801</td>
      <td>-5</td>
      <td>-1.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2017-01-03</th>
      <td>-0.106553</td>
      <td>-1.707697</td>
      <td>-0.668063</td>
      <td>-5</td>
      <td>-2.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2017-01-04</th>
      <td>-0.465035</td>
      <td>-0.465077</td>
      <td>-0.018313</td>
      <td>-5</td>
      <td>-3.0</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
df1.dropna(how='any')
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>F</th>
      <th>E</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-01-02</th>
      <td>-0.969333</td>
      <td>-0.067681</td>
      <td>-0.784801</td>
      <td>-5</td>
      <td>-1.0</td>
      <td>1.0</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
df1.fillna(value=5)
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>F</th>
      <th>E</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-01-01</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>-0.616294</td>
      <td>-5</td>
      <td>5.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2017-01-02</th>
      <td>-0.969333</td>
      <td>-0.067681</td>
      <td>-0.784801</td>
      <td>-5</td>
      <td>-1.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2017-01-03</th>
      <td>-0.106553</td>
      <td>-1.707697</td>
      <td>-0.668063</td>
      <td>-5</td>
      <td>-2.0</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>2017-01-04</th>
      <td>-0.465035</td>
      <td>-0.465077</td>
      <td>-0.018313</td>
      <td>-5</td>
      <td>-3.0</td>
      <td>5.0</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
pd.isna(df1)
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>F</th>
      <th>E</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-01-01</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2017-01-02</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2017-01-03</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
    </tr>
    <tr>
      <th>2017-01-04</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>True</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}



> 运算


```python
# 统计
df = pd.DataFrame(np.random.randint(10,size=(6,4)), index=dates, columns=list('ABCD'))
df
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-01-01</th>
      <td>0</td>
      <td>2</td>
      <td>2</td>
      <td>6</td>
    </tr>
    <tr>
      <th>2017-01-02</th>
      <td>5</td>
      <td>4</td>
      <td>9</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2017-01-03</th>
      <td>2</td>
      <td>4</td>
      <td>4</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2017-01-04</th>
      <td>8</td>
      <td>4</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2017-01-05</th>
      <td>5</td>
      <td>1</td>
      <td>5</td>
      <td>9</td>
    </tr>
    <tr>
      <th>2017-01-06</th>
      <td>8</td>
      <td>5</td>
      <td>6</td>
      <td>6</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
df.mean()
```




    A    4.666667
    B    3.333333
    C    4.333333
    D    5.500000
    dtype: float64




```python
df.mean(1)
```




    2017-01-01    2.50
    2017-01-02    5.75
    2017-01-03    3.75
    2017-01-04    3.50
    2017-01-05    5.00
    2017-01-06    6.25
    Freq: D, dtype: float64




```python
s = pd.Series([1,3,5,np.nan,6,8], index=dates)
s
```




    2017-01-01    1.0
    2017-01-02    3.0
    2017-01-03    5.0
    2017-01-04    NaN
    2017-01-05    6.0
    2017-01-06    8.0
    Freq: D, dtype: float64




```python
s=s.shift(2)
s
```




    2017-01-01    NaN
    2017-01-02    NaN
    2017-01-03    1.0
    2017-01-04    3.0
    2017-01-05    5.0
    2017-01-06    NaN
    Freq: D, dtype: float64




```python
df.sub(s, axis='index')
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-01-01</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2017-01-02</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2017-01-03</th>
      <td>1.0</td>
      <td>3.0</td>
      <td>3.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>2017-01-04</th>
      <td>5.0</td>
      <td>1.0</td>
      <td>-3.0</td>
      <td>-1.0</td>
    </tr>
    <tr>
      <th>2017-01-05</th>
      <td>0.0</td>
      <td>-4.0</td>
      <td>0.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>2017-01-06</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
# apply函数
df.apply(np.cumsum)
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2017-01-01</th>
      <td>0</td>
      <td>2</td>
      <td>2</td>
      <td>6</td>
    </tr>
    <tr>
      <th>2017-01-02</th>
      <td>5</td>
      <td>6</td>
      <td>11</td>
      <td>11</td>
    </tr>
    <tr>
      <th>2017-01-03</th>
      <td>7</td>
      <td>10</td>
      <td>15</td>
      <td>16</td>
    </tr>
    <tr>
      <th>2017-01-04</th>
      <td>15</td>
      <td>14</td>
      <td>15</td>
      <td>18</td>
    </tr>
    <tr>
      <th>2017-01-05</th>
      <td>20</td>
      <td>15</td>
      <td>20</td>
      <td>27</td>
    </tr>
    <tr>
      <th>2017-01-06</th>
      <td>28</td>
      <td>20</td>
      <td>26</td>
      <td>33</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
df.apply(lambda x: x.max() - x.min())
```




    A    8
    B    4
    C    9
    D    7
    dtype: int64




```python
#计数
s = pd.Series(np.random.randint(0, 7, size=10))
s
```




    0    3
    1    0
    2    3
    3    0
    4    0
    5    0
    6    2
    7    6
    8    2
    9    6
    dtype: int64




```python
s.value_counts()
```




    0    4
    6    2
    3    2
    2    2
    dtype: int64




```python
#字符串方法
s = pd.Series(['A', 'B', 'C', 'Aaba', 'Baca', np.nan, 'CABA', 'dog', 'cat'])
s
```




    0       A
    1       B
    2       C
    3    Aaba
    4    Baca
    5     NaN
    6    CABA
    7     dog
    8     cat
    dtype: object




```python
s.str.lower()
```




    0       a
    1       b
    2       c
    3    aaba
    4    baca
    5     NaN
    6    caba
    7     dog
    8     cat
    dtype: object



> 合并

分为concat拼接、merge连接、append附加


```python
#concat
df = pd.DataFrame(np.random.randn(10, 4))
df
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-0.085320</td>
      <td>1.206620</td>
      <td>1.618956</td>
      <td>-0.020682</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-0.026634</td>
      <td>-1.078752</td>
      <td>-0.996088</td>
      <td>-0.252160</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.245989</td>
      <td>0.846779</td>
      <td>1.552243</td>
      <td>-1.210550</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.043176</td>
      <td>1.536280</td>
      <td>-0.664456</td>
      <td>1.274851</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-0.248457</td>
      <td>0.061227</td>
      <td>0.055422</td>
      <td>-0.191773</td>
    </tr>
    <tr>
      <th>5</th>
      <td>-1.047112</td>
      <td>0.389239</td>
      <td>1.542080</td>
      <td>-0.545886</td>
    </tr>
    <tr>
      <th>6</th>
      <td>-0.669885</td>
      <td>-0.376372</td>
      <td>1.258315</td>
      <td>0.035060</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.529041</td>
      <td>1.427947</td>
      <td>0.151411</td>
      <td>-1.840725</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0.435908</td>
      <td>-0.023168</td>
      <td>0.172505</td>
      <td>1.062092</td>
    </tr>
    <tr>
      <th>9</th>
      <td>-0.171858</td>
      <td>-0.599918</td>
      <td>1.004990</td>
      <td>0.233463</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
pieces = [df[:3], df[3:7], df[7:]]
```


```python
pieces[0]
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-0.085320</td>
      <td>1.206620</td>
      <td>1.618956</td>
      <td>-0.020682</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-0.026634</td>
      <td>-1.078752</td>
      <td>-0.996088</td>
      <td>-0.252160</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.245989</td>
      <td>0.846779</td>
      <td>1.552243</td>
      <td>-1.210550</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
pieces[1]
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3</th>
      <td>0.043176</td>
      <td>1.536280</td>
      <td>-0.664456</td>
      <td>1.274851</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-0.248457</td>
      <td>0.061227</td>
      <td>0.055422</td>
      <td>-0.191773</td>
    </tr>
    <tr>
      <th>5</th>
      <td>-1.047112</td>
      <td>0.389239</td>
      <td>1.542080</td>
      <td>-0.545886</td>
    </tr>
    <tr>
      <th>6</th>
      <td>-0.669885</td>
      <td>-0.376372</td>
      <td>1.258315</td>
      <td>0.035060</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
pieces[2]
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>7</th>
      <td>0.529041</td>
      <td>1.427947</td>
      <td>0.151411</td>
      <td>-1.840725</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0.435908</td>
      <td>-0.023168</td>
      <td>0.172505</td>
      <td>1.062092</td>
    </tr>
    <tr>
      <th>9</th>
      <td>-0.171858</td>
      <td>-0.599918</td>
      <td>1.004990</td>
      <td>0.233463</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
pd.concat(pieces)
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>0</th>
      <th>1</th>
      <th>2</th>
      <th>3</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-0.085320</td>
      <td>1.206620</td>
      <td>1.618956</td>
      <td>-0.020682</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-0.026634</td>
      <td>-1.078752</td>
      <td>-0.996088</td>
      <td>-0.252160</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.245989</td>
      <td>0.846779</td>
      <td>1.552243</td>
      <td>-1.210550</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.043176</td>
      <td>1.536280</td>
      <td>-0.664456</td>
      <td>1.274851</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-0.248457</td>
      <td>0.061227</td>
      <td>0.055422</td>
      <td>-0.191773</td>
    </tr>
    <tr>
      <th>5</th>
      <td>-1.047112</td>
      <td>0.389239</td>
      <td>1.542080</td>
      <td>-0.545886</td>
    </tr>
    <tr>
      <th>6</th>
      <td>-0.669885</td>
      <td>-0.376372</td>
      <td>1.258315</td>
      <td>0.035060</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.529041</td>
      <td>1.427947</td>
      <td>0.151411</td>
      <td>-1.840725</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0.435908</td>
      <td>-0.023168</td>
      <td>0.172505</td>
      <td>1.062092</td>
    </tr>
    <tr>
      <th>9</th>
      <td>-0.171858</td>
      <td>-0.599918</td>
      <td>1.004990</td>
      <td>0.233463</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
#merge
left = pd.DataFrame({'key': ['foo', 'foo'], 'lval': [1, 2]})
right = pd.DataFrame({'key': ['foo', 'foo'], 'rval': [4, 5]})
```


```python
left
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>key</th>
      <th>lval</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>foo</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>foo</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
right
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>key</th>
      <th>rval</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>foo</td>
      <td>4</td>
    </tr>
    <tr>
      <th>1</th>
      <td>foo</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
pd.merge(left, right, on='key')
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>key</th>
      <th>lval</th>
      <th>rval</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>foo</td>
      <td>1</td>
      <td>4</td>
    </tr>
    <tr>
      <th>1</th>
      <td>foo</td>
      <td>1</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>foo</td>
      <td>2</td>
      <td>4</td>
    </tr>
    <tr>
      <th>3</th>
      <td>foo</td>
      <td>2</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
#append
df = pd.DataFrame(np.random.randn(8, 4), columns=['A','B','C','D'])
df
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-0.279258</td>
      <td>-0.352347</td>
      <td>-1.866664</td>
      <td>-0.756606</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.007247</td>
      <td>-1.684264</td>
      <td>-0.671554</td>
      <td>1.103426</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.716867</td>
      <td>-1.119185</td>
      <td>-0.062760</td>
      <td>-0.424570</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.346070</td>
      <td>-0.160277</td>
      <td>0.480741</td>
      <td>-3.739629</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-1.947606</td>
      <td>-0.931807</td>
      <td>1.361200</td>
      <td>-0.944480</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1.063839</td>
      <td>0.042823</td>
      <td>-0.485761</td>
      <td>0.014667</td>
    </tr>
    <tr>
      <th>6</th>
      <td>-0.171306</td>
      <td>-1.320569</td>
      <td>0.861081</td>
      <td>-0.821154</td>
    </tr>
    <tr>
      <th>7</th>
      <td>-0.008423</td>
      <td>-1.027952</td>
      <td>0.233170</td>
      <td>0.620665</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
s = df.iloc[3]
df.append(s, ignore_index=True)
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-0.279258</td>
      <td>-0.352347</td>
      <td>-1.866664</td>
      <td>-0.756606</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.007247</td>
      <td>-1.684264</td>
      <td>-0.671554</td>
      <td>1.103426</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.716867</td>
      <td>-1.119185</td>
      <td>-0.062760</td>
      <td>-0.424570</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.346070</td>
      <td>-0.160277</td>
      <td>0.480741</td>
      <td>-3.739629</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-1.947606</td>
      <td>-0.931807</td>
      <td>1.361200</td>
      <td>-0.944480</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1.063839</td>
      <td>0.042823</td>
      <td>-0.485761</td>
      <td>0.014667</td>
    </tr>
    <tr>
      <th>6</th>
      <td>-0.171306</td>
      <td>-1.320569</td>
      <td>0.861081</td>
      <td>-0.821154</td>
    </tr>
    <tr>
      <th>7</th>
      <td>-0.008423</td>
      <td>-1.027952</td>
      <td>0.233170</td>
      <td>0.620665</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0.346070</td>
      <td>-0.160277</td>
      <td>0.480741</td>
      <td>-3.739629</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}



> 分组


```python
df = pd.DataFrame({'A' : ['foo', 'bar', 'foo', 'bar','foo', 'bar', 'foo', 'foo'],
                   'B' : ['one', 'one', 'two', 'three','two', 'two', 'one', 'three'],
                   'C' : np.random.randn(8),
                   'D' : np.random.randn(8)})
df
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>foo</td>
      <td>one</td>
      <td>-0.375015</td>
      <td>-0.371934</td>
    </tr>
    <tr>
      <th>1</th>
      <td>bar</td>
      <td>one</td>
      <td>-0.837523</td>
      <td>0.733000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>foo</td>
      <td>two</td>
      <td>-0.248089</td>
      <td>-1.269897</td>
    </tr>
    <tr>
      <th>3</th>
      <td>bar</td>
      <td>three</td>
      <td>0.320737</td>
      <td>0.305018</td>
    </tr>
    <tr>
      <th>4</th>
      <td>foo</td>
      <td>two</td>
      <td>-2.005969</td>
      <td>-1.319570</td>
    </tr>
    <tr>
      <th>5</th>
      <td>bar</td>
      <td>two</td>
      <td>-1.011349</td>
      <td>-0.159672</td>
    </tr>
    <tr>
      <th>6</th>
      <td>foo</td>
      <td>one</td>
      <td>2.018282</td>
      <td>1.061732</td>
    </tr>
    <tr>
      <th>7</th>
      <td>foo</td>
      <td>three</td>
      <td>-0.642915</td>
      <td>-0.626796</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
df.groupby('A').sum()
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>C</th>
      <th>D</th>
    </tr>
    <tr>
      <th>A</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>bar</th>
      <td>-1.528135</td>
      <td>0.878347</td>
    </tr>
    <tr>
      <th>foo</th>
      <td>-1.253705</td>
      <td>-2.526466</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
df.groupby(['A','B']).sum()
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th>C</th>
      <th>D</th>
    </tr>
    <tr>
      <th>A</th>
      <th>B</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="3" valign="top">bar</th>
      <th>one</th>
      <td>-0.837523</td>
      <td>0.733000</td>
    </tr>
    <tr>
      <th>three</th>
      <td>0.320737</td>
      <td>0.305018</td>
    </tr>
    <tr>
      <th>two</th>
      <td>-1.011349</td>
      <td>-0.159672</td>
    </tr>
    <tr>
      <th rowspan="3" valign="top">foo</th>
      <th>one</th>
      <td>1.643267</td>
      <td>0.689798</td>
    </tr>
    <tr>
      <th>three</th>
      <td>-0.642915</td>
      <td>-0.626796</td>
    </tr>
    <tr>
      <th>two</th>
      <td>-2.254058</td>
      <td>-2.589467</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}



> pivot table


```python
df = pd.DataFrame({'A' : ['one', 'one', 'two', 'three'] * 3,
                   'B' : ['A', 'B', 'C'] * 4,
                   'C' : ['foo', 'foo', 'foo', 'bar', 'bar', 'bar'] * 2,
                   'D' : np.random.randn(12),
                   'E' : np.random.randn(12)})
df
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>E</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>one</td>
      <td>A</td>
      <td>foo</td>
      <td>0.390424</td>
      <td>-0.611496</td>
    </tr>
    <tr>
      <th>1</th>
      <td>one</td>
      <td>B</td>
      <td>foo</td>
      <td>0.261406</td>
      <td>-1.746241</td>
    </tr>
    <tr>
      <th>2</th>
      <td>two</td>
      <td>C</td>
      <td>foo</td>
      <td>1.013178</td>
      <td>-1.047726</td>
    </tr>
    <tr>
      <th>3</th>
      <td>three</td>
      <td>A</td>
      <td>bar</td>
      <td>0.874502</td>
      <td>-0.251756</td>
    </tr>
    <tr>
      <th>4</th>
      <td>one</td>
      <td>B</td>
      <td>bar</td>
      <td>0.990922</td>
      <td>0.956082</td>
    </tr>
    <tr>
      <th>5</th>
      <td>one</td>
      <td>C</td>
      <td>bar</td>
      <td>0.041987</td>
      <td>1.418088</td>
    </tr>
    <tr>
      <th>6</th>
      <td>two</td>
      <td>A</td>
      <td>foo</td>
      <td>0.487429</td>
      <td>0.315077</td>
    </tr>
    <tr>
      <th>7</th>
      <td>three</td>
      <td>B</td>
      <td>foo</td>
      <td>0.072805</td>
      <td>-0.097474</td>
    </tr>
    <tr>
      <th>8</th>
      <td>one</td>
      <td>C</td>
      <td>foo</td>
      <td>-0.666952</td>
      <td>1.655099</td>
    </tr>
    <tr>
      <th>9</th>
      <td>one</td>
      <td>A</td>
      <td>bar</td>
      <td>1.647375</td>
      <td>-1.670791</td>
    </tr>
    <tr>
      <th>10</th>
      <td>two</td>
      <td>B</td>
      <td>bar</td>
      <td>-0.907300</td>
      <td>-1.481746</td>
    </tr>
    <tr>
      <th>11</th>
      <td>three</td>
      <td>C</td>
      <td>bar</td>
      <td>0.214953</td>
      <td>-0.420732</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
pd.pivot_table(df, values='D', index=['A', 'B'], columns=['C'])
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>C</th>
      <th>bar</th>
      <th>foo</th>
    </tr>
    <tr>
      <th>A</th>
      <th>B</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="3" valign="top">one</th>
      <th>A</th>
      <td>1.647375</td>
      <td>0.390424</td>
    </tr>
    <tr>
      <th>B</th>
      <td>0.990922</td>
      <td>0.261406</td>
    </tr>
    <tr>
      <th>C</th>
      <td>0.041987</td>
      <td>-0.666952</td>
    </tr>
    <tr>
      <th rowspan="3" valign="top">three</th>
      <th>A</th>
      <td>0.874502</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>B</th>
      <td>NaN</td>
      <td>0.072805</td>
    </tr>
    <tr>
      <th>C</th>
      <td>0.214953</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th rowspan="3" valign="top">two</th>
      <th>A</th>
      <td>NaN</td>
      <td>0.487429</td>
    </tr>
    <tr>
      <th>B</th>
      <td>-0.907300</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>C</th>
      <td>NaN</td>
      <td>1.013178</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}



> plotting


```python
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

ts = pd.Series(np.random.randn(1000), index=pd.date_range('1/1/2000', periods=1000))
ts = ts.cumsum()

plt.figure()
ts.plot()
plt.legend(loc='best')
plt.show()
```


![png](output_80_0.png)


> 导出和导入，支持csv、hdf5和excel


```python
df.to_csv('file/foo.csv')
pd.read_csv('file/foo.csv')
```




{% raw %}
<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Unnamed: 0</th>
      <th>A</th>
      <th>B</th>
      <th>C</th>
      <th>D</th>
      <th>E</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>one</td>
      <td>A</td>
      <td>foo</td>
      <td>0.390424</td>
      <td>-0.611496</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>one</td>
      <td>B</td>
      <td>foo</td>
      <td>0.261406</td>
      <td>-1.746241</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>two</td>
      <td>C</td>
      <td>foo</td>
      <td>1.013178</td>
      <td>-1.047726</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>three</td>
      <td>A</td>
      <td>bar</td>
      <td>0.874502</td>
      <td>-0.251756</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>one</td>
      <td>B</td>
      <td>bar</td>
      <td>0.990922</td>
      <td>0.956082</td>
    </tr>
    <tr>
      <th>5</th>
      <td>5</td>
      <td>one</td>
      <td>C</td>
      <td>bar</td>
      <td>0.041987</td>
      <td>1.418088</td>
    </tr>
    <tr>
      <th>6</th>
      <td>6</td>
      <td>two</td>
      <td>A</td>
      <td>foo</td>
      <td>0.487429</td>
      <td>0.315077</td>
    </tr>
    <tr>
      <th>7</th>
      <td>7</td>
      <td>three</td>
      <td>B</td>
      <td>foo</td>
      <td>0.072805</td>
      <td>-0.097474</td>
    </tr>
    <tr>
      <th>8</th>
      <td>8</td>
      <td>one</td>
      <td>C</td>
      <td>foo</td>
      <td>-0.666952</td>
      <td>1.655099</td>
    </tr>
    <tr>
      <th>9</th>
      <td>9</td>
      <td>one</td>
      <td>A</td>
      <td>bar</td>
      <td>1.647375</td>
      <td>-1.670791</td>
    </tr>
    <tr>
      <th>10</th>
      <td>10</td>
      <td>two</td>
      <td>B</td>
      <td>bar</td>
      <td>-0.907300</td>
      <td>-1.481746</td>
    </tr>
    <tr>
      <th>11</th>
      <td>11</td>
      <td>three</td>
      <td>C</td>
      <td>bar</td>
      <td>0.214953</td>
      <td>-0.420732</td>
    </tr>
  </tbody>
</table>
</div>
{% endraw %}




```python
#excel导入导出，导出需要安装openpyxl库，导入需要安装xlrd库
df.to_excel('file/foo.xlsx', sheet_name='Sheet1')
pd.read_excel('file/foo.xlsx', 'Sheet1', index_col=None, na_values=['NA'])
```

> 读取MySQL


```python
import pandas as pd
import MySQLdb
mysql_cn= MySQLdb.connect(host='localhost', port=3306,user='root', passwd='123', db='testdb')
df = pd.read_sql('select * from test;', con=mysql_cn)    
mysql_cn.close()
```

