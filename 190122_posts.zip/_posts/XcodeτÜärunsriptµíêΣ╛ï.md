---
title: Xcode的runsript案例
date: 2016-05-20 11:53:34
tags: iOS
---

## 一、runscript介绍
在我理解，runscript是在app编译时，通知Xcode额外做的事情，可以通过script编写脚本来实现。

## 二、runscript案例1-appledoc
appledoc是我们较为常用的文档生成工具，[『github地址传送门』](https://github.com/tomaz/appledoc)

安装方法请执行：

``` bash
$ git clone git://github.com/tomaz/appledoc.git
$ cd appledoc
$ sudo sh install-appledoc.sh
```
安装完成后，我们想着每次在编译ios app时，都能自动生成文档。


在项目中新建一个target，选择如下图所示的类别。这样会在项目中多出一个target。

![](Xcode的runsript案例/addtarget.jpg)

对该target的Build Phases上添加run script phrase。

![](Xcode的runsript案例/addrunscript.jpg)

为了自动生成文档，需要使用appledoc的生成命令，可供粘贴。如果对命令不熟练，也可以使用appledoc --help进行查看。

![](Xcode的runsript案例/addscript.jpg)

script脚本如下，供copy。需要注意的是outputPath，为文档的输出路径。ignore，可以选择不生成某些路径下的文档。最后的参数，"{PROJECT_DIR}/runscript)"，需要根据自己需要生成的项目做调整。

<!--more-->

``` objc
#appledoc Xcode script
# Start constants
company="herr";
companyID="com.herr";
companyURL="http://iherr.cn";
target="iphoneos";
#target="macosx";
outputPath="${PROJECT_DIR}"/Doc;
# End constants

/usr/local/bin/appledoc \
--project-name "${PROJECT_NAME}" \
--project-company "${company}" \
--company-id "${companyID}" \
--docset-atom-filename "${company}.atom" \
--docset-feed-url "${companyURL}/${company}/%DOCSETATOMFILENAME" \
--docset-package-url "${companyURL}/${company}/%DOCSETPACKAGEFILENAME" \
--docset-fallback-url "${companyURL}/${company}" \
--output "${outputPath}" \
--ignore "${PROJECT_DIR}"/runscript/Libs \
--publish-docset \
--docset-platform-family "${target}" \
--logformat xcode \
--keep-intermediate-files \
--no-repeat-first-par \
--no-warn-invalid-crossref \
--exit-threshold 2 \
"${PROJECT_DIR}"/runscript
```

完成后，编译运行，可以在xcode上看到编译结果。里面有run script的执行情况，当然可以在script中使用printf来打印，也同样会在这里显示。

![](Xcode的runsript案例/buildlog.png)

这样，我们可以在项目目录的doc文件夹里找到生成的文档，或者到xcode的window的Documentations and API Reference里查看。

另外，文档的生成需要平时对项目的注释进行规范书写，这里不再赘述。

## 三、runscript案例2-对icon添加版本号等信息
一直以来，做测试时都要区分版本号、git的提交序列、服务器测试还是正式环境等问题，想着在编译时，自动将这些信息贴在app的icon上就好了。直到在github上碰到了这个项目[『github地址传送门』](https://github.com/krzysztofzablocki/IconOverlaying)。

作者编写了个脚本，获取项目的版本号、git的提交序列等信息，然后使用**imagemagick**和**ghostscript**将这些信息绘制在了app的icon里。
如果本地机器没有安装，则需要使用brew命令一键安装。

``` bash
$ brew install imagemagick
$ brew install ghostscript
```

当使用debug模式进行编译时，则会出现如下的logo。当然，如果是release模式打包，则不会出现，具体可以参考runscrip脚本 [『iconVersioning.sh』](iconVersioning.sh)

![](Xcode的runsript案例/screenshot.png)

在此基础上，我们还可以将应用服务器测试还是正式环境等其他参数都加到icon上，方便对产品进行标示。

