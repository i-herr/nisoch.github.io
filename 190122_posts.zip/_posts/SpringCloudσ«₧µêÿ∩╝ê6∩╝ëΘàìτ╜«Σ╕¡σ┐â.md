---
title: SpringCloud实战（6）配置中心
date: 2018-07-16 10:16:00
tags: [SpringCloud,Java]
---

## 一、统一管理微服务配置

微服务的配置管理，一般有以下需求

* 集中管理配置
* 不同环境，不同配置。
* 运行期间可动态调整。如动态调整数据源连接池大小或熔断阈值。
* 配置修改后可自动更新。

Spring Cloud Config为Spring Cloud子项目，提供一套分布式的配置管理方案，[『官方文档传送门』](http://cloud.spring.io/spring-cloud-config/single/spring-cloud-config.html)

分为服务端Config Server和客户端Config Client，其中Server端连接git或svn，并对外提供配置信息服务。Client端从Server端获取配置信息。当配置变更时，只需要借助git的push操作来触发更新操作。

## 二、Config Server

> git配置文件

首先需要在git上放置一些yml或properties文件，命名规则为：
{application}-{profile}.***。

* **application** 用于Client端连接时配置的spring.application.name，用于过滤配置文件。
* **profile** 用于Client端连接时配置的spring.cloud.config.profile，用于区分生产测试等不同环境。
* **label** 一般都是master，代表分支。

我们配置了3个yml文件如下(也可使用properties文件)：

1、herr.yml

```
server.port: 8082
#远程配置，默认8082

profile: herr-default
```

2、herr-dev.yml

```
#server.port=8082
#不设置server.port，则以herr.yml的8082为default

profile: herr-dev
```

3、herr-pro.yml

```
server.port: 8086

profile: herr-pro
```

> Server端搭建

<!--more-->

1、pom.xml依赖

``` java
<dependency>
	<groupId>org.springframework.cloud</groupId>
	<artifactId>spring-cloud-config-server</artifactId>
</dependency>

<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-security</artifactId>
</dependency>
```

2、application入口类添加注解@EnableConfigServer

3、application.yml配置

``` xml
server:
  port: 8100
spring:
  application:
    name: config
  http:
    encoding:
      charset: UTF-8
      enabled: true
      force: true
  cloud:
    config:
      label: master #为默认分支
      server:
        git:
          #用于连接本地gitlab，需要密码
          #uri: http://127.0.0.1:10080/root/config.git
          #username: root
          #password: 12345678

          #用于连接码云
          uri: https://gitee.com/iherr/spring-cloud-trip-config.git
          searchPaths: config-git-static #如配置文件不在根目录，则需要设置文件夹路径
          clone-on-start: true #Server启动时就clone指定Git仓库，可快速识别错误的配置源
	security:
	user:
	password: 1a1a2b2b3c3c4d4d
	#如需要密码，需要pom添加security依赖，否则不起作用
```

> 运行并测试

使用浏览器访问，查看数据是否正常，如有找不到的属性，会默认去{application}.***上找。

访问规则如下:

``` bash
配置文件命名规则如下，这些路径可到启动日志中查看，会自动mapped映射一堆url路径：
 * /{application}/{profile}[/{label}]
 * /{application}-{profile}.yml
 * /{label}/{application}-{profile}.yml
 * /{application}-{profile}.properties
 * /{label}/{application}-{profile}.properties

按照以上规则，以下url都可以访问，如启用了密码，会弹出页面需要输入密码，默认用户名为user:

http://localhost:8100/herr/dev/master
http://localhost:8100/herr-dev.yml
http://localhost:8100/master/herr-dev.yml
http://localhost:8100/herr-pro.properties
http://localhost:8100/master/herr-dev.properties
```

## 三、Config Client

> Client端搭建

1、pom.xml依赖

```bash
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-config</artifactId>
</dependency>
```

2、接口实现：profile接口，从配置文件中获取profile并显示

```
@RestController
public class HelloController {

    @Value("${profile}")
    private String profile;

    @GetMapping("/profile")
    public String getProfile(){
        return this.profile;
    }
}
```

3、提供默认application.yml文件

```
server:
  port: 8080

profile: default

#如果不需要bootstrap.yml，可将spring.cloud.config.uri在EditConfiguration中override parameter中设置，打开注释设置其余参数
#spring:
#  cloud:
#    config:
#      profile: dev #如不设置，则走default
#      label: master
#  application:
#    name: herr
```

![](SpringCloud实战（6）配置中心/idea_param.png)

4、提供初始化文件bootstrap.yml（名称不能改，默认），必须要这个文件，不然运行初始化时找不到server地址，会使用默认8888端口来获取server。

如省略掉该环节，会发现启动Client模块出现错误，报错信息为：Fetching config from server at: http://localhost:8888 等。SpringCloud里面有个“启动上下文”，主要是用于加载远端的配置，也就是加载Server里面的配置，默认加载顺序为：加载bootstrap.yml里面的配置 --> 链接Server，加载远程配置 --> 加载application.yml里面的配置；

```
spring:
  cloud:
    config:
      #uri: http://127.0.0.1:8100
      uri: http://user:1a1a2b2b3c3c4d4d@127.0.0.1:8100
      #区分是否输入密码，密码为server端配置
      profile: pro #如不设置，则走default
      label: master
      #name: herr 
  application:
    name: herr
#取 herr-dev.yml 这个文件的 application 名字，即为 herr 名称#application.name和spring.cloud.config.name字段相同
```

如确实不想要bootstrap.yml文件，可将spring.cloud.config.uri在EditConfiguration中override parameter中设置，或者通过代码在入口main函数中代码设置。

```java
    public static void main(String[] args) {
        if (StringUtils.isBlank(System.getProperty("spring.cloud.config.uri"))) {
            System.setProperty("spring.cloud.config.uri", "http://user:1a1a2b2b3c3c4d4d@127.0.0.1:8100");
        }
        System.out.println(System.getProperty("spring.cloud.config.uri"));
        SpringApplication.run(ConfigClientApplication.class, args);
    }
```

5、运行并测试

由于配置的application.name为herr，profile为pro，因此会自动先去找herr-pro.yml[.properties]文件，查到server.port为8086，profile为herr-pro，因此访问的地址为：http://localhost:8086/profile 返回的文字为herr-pro。可修改这两个参数做其他验证。

> 额外说明

哪怕第4步项目application.yml有server.port为8082，profile为 test1。在Server服务启动的时候，bootstrap拿到远端配置注入到profile的属性中的话，那么就不会再次覆盖这个属性了，所以只会选择远端配置的内容。

## 四、其他特性

> 对称加密解密

加解密功能依赖Java Cryptography Extension（JCE）。

Config Server提供加密与解密的端点，对称加密使用bootstrap.yml配置文件中的encrypt.key属性来设置对称秘钥，注意每次加密产生的值都不一样，但是都可以反向解密。

```bash
$ curl localhost:8080/encrypt -d mysecret
720ed69f1afc0995af88f09d0e2502aaee861322e963a3e643db3a1b2079385a

$ curl localhost:8080/decrypt -d 720ed69f1afc0995af88f09d0e2502aaee861322e963a3e643db3a1b2079385a
mysecret
```

yml文件可这样填写，使用{cipher}开头并有单引号。但是properties文件不能有单引号。

```bash
spring:
  datasource:
    username: dbuser
    password: '{cipher} 720ed69f1afc0995af88f09d0e2502aaee861322e963a3e643db3a1b2079385a'
```

SpringCloud同样支持非对称加密。使用keytool生产jks文件，复制到项目classpath下。并在bootstrap.yml中添加如下内容。

```yml
encrypt:
  key-store:
    location: classpath:/server.jks
    password: pwd
    alias: test
    secret: key
```

> 手动刷新配置

1、spring-boot-starter-actuator包含了/refresh端点，用于配置的刷新。

2、在Controller中添加@RefreshScope，用于配置更改时做特殊处理。

> 自动刷新配置

Spring Cloud Bus使用轻量级的消息代理，连接分布式系统的节点，广播配置的更新。当某个微服务节点的/bus/refresh端点被请求时，会向消息总线发送一个配置更新事件，其他实例获取该事件后更新配置。

Spring Cloud Bus可使用Client端来集成。

1、pom依赖

```bash
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-bus-amqp</artifactId>
</dependency>
```

2、yml配置

```yml
spring:
  rabbitmq:
    host: localhost
    port:5672
    username: user
    password: pwd
```

3、测试

访问/bus/refresh端点可刷新。

4、架构优化：同样可以使用Server端来集成，将Config Server加入消息总线，这样可以避免Client端被破坏。

> 高可用性

* Git仓库高可用
* RabbitMQ高可用
* Config Server高可用，可使用Eureka。如未注册到Eureka，需添加负载均衡器。

## 五、相关代码

[『代码传送门』](https://gitee.com/iherr/spring-cloud-trip-config)