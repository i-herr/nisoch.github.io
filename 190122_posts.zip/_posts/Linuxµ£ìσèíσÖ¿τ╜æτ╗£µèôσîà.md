---
title: Linux服务器网络抓包
date: 2016-09-27 16:43:54
tags: [Linux]
---

## 一、Linux网络监控工具
监控Linux网络带宽的工具有一大把，下面是按功能划分的命令名称。

* 监控总体带宽使用――nload、bmon、slurm、bwm-ng、cbm、speedometer和netload
* 监控总体带宽使用（批量式输出）――vnstat、ifstat、dstat和collectl
* 每个套接字连接的带宽使用――iftop、iptraf、tcptrack、pktstat、netwatch和trafshow
* 每个进程的带宽使用――nethogs


## 二、tcpdump
最近需要对服务器的网络进行抓包统计，便用到了tcpdump。[『官网传送门』](http://www.tcpdump.org)，可去查看最新版本以及相关用法。


用简单的话来定义tcpdump，就是：dump the traffic on a network，根据使用者的定义对网络上的数据包进行截获的包分析工具。 tcpdump可以将网络中传送的数据包的“头”完全截获下来提供分析。它支持针对网络层、协议、主机、网络或端口的过滤，并提供and、or、not等逻辑语句来帮助你去掉无用的信息。

> tcpdump安装  

依赖：  

``` bash 
$ yum install flex  
$ yum install bison  
$ yum install gcc 
``` 

安装：

``` 
$ wget http://www.tcpdump.org/release/libpcap-1.8.1.tar.gz    
$ wget http://www.tcpdump.org/release/tcpdump-4.9.2.tar.gz    
$ tar -zxvf libpcap-1.8.1.tar.gz    
$ cd libpcap-1.8.1    
$ ./configure    
$ make install    
    
$ cd ..    
$ tar -zxvf tcpdump-4.9.2.tar.gz    
$ cd tcpdump-4.9.2    
$ ./configure    
$ sudo make install  
``` 

首先需要查看设备上有哪些设备可以抓取，通过tcpdump -D会列出可以抓取的网络设备名以及编号

<!--more-->

```txt
1.eth0 [Up, Running]
2.eth1 [Up, Running]
3.any (Pseudo-device that captures on all interfaces) [Up, Running]
4.lo [Up, Running, Loopback]
5.usbmon0 (All USB buses)
6.nflog (Linux netfilter log (NFLOG) interface)
7.nfqueue (Linux netfilter queue (NFQUEUE) interface)
8.usbmon1 (USB bus number 1)
```

如需要可视化页面来分析，可以安装大名鼎鼎的[wireshark](https://www.wireshark.org)。最新版本是支持windows和mac了的。

可以通过tcpdump导出cap文件，供wireshark直接打开。

``` bash
$ tcpdump tcp -i 2 -t -s 0 -c 2000 -w x.cap

$ tcpdump -XvvennSs 0 -i 7 tcp[20:2]=0x4745 or tcp[20:2]=0x4854 -w x.cap
```

相关参数的含义请参考官网文档。

![](Linux服务器网络抓包/wireshark.jpg)