---
title: CocoaPods使用
date: 2016-05-02 11:22:03
tags: [iOS,CocoaPods]
---

## 一、关于ruby、gem和brew（如已安装可跳过）
ruby，一种脚本语言，和python类似。Mac OS X上自带。<br>
gem，是个用ruby写的应用程序，用来安装软件包的程序。<br>
brew，又叫Homebrew，是Mac OSX上的软件包管理工具，能使用命令在Mac中方便的安装软件或者卸载软件。

> 安装和卸载brew

install brew

``` bash
$ ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
```
remove brew（有时出问题需要卸载后再安装）

``` bash
$ ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/uninstall)"
```

> 额外装下node

跑题了。可以顺带装下node。	

``` bash
$ brew install node
```
> 升级mac自带ruby（使用RVM,需要brew支持）

1、系统自带ruby一般较老，可以使用RVM进行升级。

``` bash
$ curl -L get.rvm.io | bash -s stable
```

2、载入 RVM 环境

``` bash
$ source ~/.rvm/scripts/rvm
```

3、检查一下是否安装正确

``` bash
$ rvm -v
```

4、列出已知的ruby版本

``` bash
$ rvm list known
```

5、安装目前最新的2.3版本

``` bash
$ rvm install 2.3
```
6、查看ruby和gem版本

``` bash
$ ruby -v
ruby 2.3.0p0 (2015-12-25 revision 53290) [x86_64-darwin15]
$ gem -v
2.5.1
```
7、如果需要单独更新gem

``` bash
$ sudo gem update --system
```
8、gem源更新，目前官方默认的地址被墙，使用淘宝镜像替换。https://ruby.taobao.org/

``` bash
$ gem sources -a https://gems.ruby-china.org/  
$ gem sources -r https://rubygems.org/
$ gem sources -l
*** CURRENT SOURCES ***
https://gems.ruby-china.org/
	
```
好啦。环境准备结束。

## 二、CocoaPods安装

[『官网传送门』](https://www.cocoapods.org)是比较权威的参考。

<!--more-->

用gem安装下就好。
``` bash
$ sudo gem install cocoapods
```
看下pod是否安装成功。
``` bash
$ pod --version
1.0.1
```
安装成功后，是需要同步pod repo的。因此可使用以下命令同步（此步骤推荐先跳过，建议后续更换pod repo源）。

``` bash
$ pod setup
```

## 三、CocoaPods使用
1、为新建工程或在现有工程添加CocoaPods，cd到工程目录

``` bash
$ cd 'your project home dir'
$ pod init
```

2、会自动生成Podfile文件，当然你也可以使用vim命令自己建。

``` bash
$ vim Podfile
```	

3、编辑Podfile，写入您需要的第三方库以及版本。小提示：（终端vim文件 按 i 可编辑 ，esc 退出编辑，:wq 可保存退出）。当然，您也完全可以通过Xcode和其他文本编辑器来进行。例如，给项目名为Test的添加AFNetworking和FMDB。

``` bash		
platform :ios, '6.0'

target 'Test' do
pod 'AFNetworking', '~> 3.0'
pod 'FMDB'
end
```	
4、安装导入第三方库

``` bash	
$ pod install
```	
当然也可以指定安装某第三方库

``` bash	
$ pod install AFNetworking
```		
	
5、当需要进行第三方库版本更新时，使用

``` bash
$ pod update
```	

当然可可以指定安装某第三方库
	
``` bash	
$ pod update AFNetworking
```	
6、当需要查找某个第三方库信息时，例如查找AFNetworking，使用

``` bash
$ pod search AFNetworking
# 注意，1.0版本pod进入查询后如需要退出，可输入 q + 回车。
```	
7、有时操作时想print安装信息，可在所有命令后加--verbose。例如

``` bash		
$ pod install --verbose
```	
8、在CocoaPods1.0以前，所有命令会默认自动执行pod repo update的，每次执行太恐怖了，可在所有命令后加--no-repo-update。会加快执行效率。例如

``` bash
$ pod install --no-repo-update --verbose
```	

但是在1.0版本以后，默认是不执行的。因此可以忽略掉。
		
## 四、CocoaPods的git仓库更新

> git仓库更新

cocoapods有一个git仓库专门保存了github上一些有名的开源组件的podspec文件。cocoapods会把它clone到你本地的~/.cocoapods/repo/master路径下。当你pod search一个内容时，就在这个本地目录下进行搜索。

由于三方库版本更新，我们使用pod无法install、search到最新版本的内容，就需要进行git仓库的更新。我们可以使用如下命令进行更新：

``` bash
$ pod repo update --verbose
```		
我们可以cd到pod repo目录里，用du -sh *命令来查看文件大小，每隔几分钟查看一次，看看是否有大小变化。笔者目前该目录大概700多M。

当使用上述命令时，会更新的非常慢，通过命令查询，发现托管到github上，有时也会被墙。

``` bash
$ pod repo

master
- Type: git (master)
- URL:  https://github.com/CocoaPods/Specs.git
- Path: /Users/herr/.cocoapods/repos/master

1 repo
```	

> 国内镜像

如果大家不想被这个烦死的话，还是找找国内的镜像吧。

gitcafe（目前迁移到coding.net）和oschina都是国内的服务器，可以用它们CocoaPods索引库的镜像。目前发现oschina的http://git.oschina.net/akuandev/Specs.git更新较慢，于是还是使用coding.net上的吧，发现更好的随时替换，我对现在5MiB的速度还是很满意的。（后续可能失效）

``` bash
$ pod repo remove master
$ pod repo add master https://git.coding.net/hging/Specs.git
$ git clone https://git.coding.net/hging/Specs.git ~/.cocoapods/repos/master
$ pod repo update
```	

如镜像无人维护了，可采用如下解决方案：

* 访问 https://github.com/CocoaPods/Specs，然后将Specs项目fork到自己的github账户上
* 下载GitHub Desktop, 然后clone Specs项目。
* 将clone的Specs项目的文件夹改名为master，然后拖到/Users/用户名/.cocoapods/repos目录下。
* 运行pod setup

解释：pod setup的本质就是将https://github.com/CocoaPods/Specs上的Specs项目clone到/Users/用户名/.cocoapods/repos目录下。若此目录下已有Specs项目，则会将项目更新到最新的状态。由于Specs很大，容易导致pod setup失败。这时就需要我们手动安装Specs。若直接从github上下载zip文件，由于缺少git文件，会导致cocoa pods不使用。若用git clone，由于文件过大，容易导致失败。但是使用GitHub Desktop软件，则会提高clone的成功率，并且会给出clone的进度。

> 如果使用pod search无法搜索到类库

删除~/Library/Caches/CocoaPods目录下的search_index.json文件

pod setup成功后会生成~/Library/Caches/CocoaPods/search_index.json文件。
终端输入rm ~/Library/Caches/CocoaPods/search_index.json
删除成功后再执行pod search

![](CocoaPods使用/terminal.png)

再使用pod repo查看下，检查源的URL是否变更。

如果哪天发现更新后还不是最新的，可以登录我们刚刚配置的源地址
[『https://coding.net/u/hging/p/Specs/git』](https://coding.net/u/hging/p/Specs/git)查看更新时间，如果较为久远，再去更换源。

## 五、高级进阶-CocoaPods私有库管理
私有库管理，主要用于自己的代码，也想像pod管理第三方库一样进行管理。官方的文档如下，后续有时间再演示一遍整个流程。
[『http://guides.cocoapods.org/syntax/podspec.html』](http://guides.cocoapods.org/syntax/podspec.html)