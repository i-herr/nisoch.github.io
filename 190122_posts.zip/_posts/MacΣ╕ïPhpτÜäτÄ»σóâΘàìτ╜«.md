---
title: Mac下Php的环境配置
date: 2016-08-17 11:46:05
tags: [Php,Mac]
---

## 一、Php环境安装

1、Mac推荐使用XAMPP，Window可使用wampserver。直接傻瓜式下载安装即可。目前最新版本7.0.2，正常运行，开启mysql和apache，写个phpinfo，检测下环境即可。
以下以Mac为例，10.12 Sierra自带的php版本为5.6，XAMPP安装的php是7.0，可共存。

2、PhpStorm安装：略，如有问题，可校验下sha256。

```
$ shasum -a 256 PhpStorm-2017.2.4.dmg
```

## 二、本地安装Redis

> 安装Redis

1、可使用brew直接安装

``` bash
$ brew install redis
```

2、修改配置文件：

``` bash
$ cat /usr/local/etc/redis.conf 
```

3、本地启动redis

``` bash
$ /usr/local/bin/redis-server /usr/local/etc/redis.conf 
```

<!--more-->

4、可以在命令行进行简单的连接和查询

``` bash
$ redis-cli			//连接redis
$ auth redis_test //密码校验
$ keys *				//查看所有keys值
```

> 安装php的redis拓展

1、下载编译安装

```
$ git clone https://github.com/phpredis/phpredis.git
$ tar zxvf 压缩包名称
$ cd phpredis目录
$ /Applications/XAMPP/xamppfiles/bin/phpize //动态安装
$ sudo MACOSX_DEPLOYMENT_TARGET=10.7 CFLAGS="-arch i386 -arch x86_64 -g -Os -pipe -no-cpp-precomp" CCFLAGS="-arch i386 -arch x86_64 -g -Os -pipe" CXXFLAGS="-arch i386 -arch x86_64 -g -Os -pipe" LDFLAGS="-arch i386 -arch x86_64 -bind_at_load" ./configure --enable-redis --with-php-config=/Applications/XAMPP/xamppfiles/bin/php-config
$ sudo make && sudo make install
```

2、配置
在php.ini文件中增加：extension=redis.so，然后重启XAMPP的Apache服务就好了

## 三、xdebug安装

附上[『Github传送门』](https://github.com/xdebug/xdebug)

附上[『官网传送门』](https://xdebug.org)

可先将phpinfo的html粘贴到如下地址：
https://xdebug.org/wizard.php

会生成以下信息：

``` bash
Summary

Xdebug installed: no
Server API: Apache 2.0 Handler
Windows: no
Zend Server: no
PHP Version: 7.0.2
Zend API nr: 320151012
PHP API nr: 20151012
Debug Build: no
Thread Safe Build: no
Configuration File Path: /Applications/XAMPP/xamppfiles/etc
Configuration File: /Applications/XAMPP/xamppfiles/etc/php.ini
Extensions directory: /Applications/XAMPP/xamppfiles/lib/php/extensions/no-debug-non-zts-20151012
Instructions

```
安装的操作步骤如下：

1、Download xdebug-2.5.4.tgz

2、RUN

```
tar -xvzf xdebug-2.5.4.tgz
cd xdebug-2.5.4
/Applications/XAMPP/xamppfiles/bin/phpize 
```

As part of its output it should show:

Configuring for:
...
Zend Module Api No:      20151012
Zend Extension Api No:   320151012
If it does not, you are using the wrong phpize. Please follow this FAQ entry and skip the next step.

3、RUN

```
./configure --enable-xdebug --with-php-config=/Applications/XAMPP/xamppfiles/bin/php-config-7.0.2

make
cp modules/xdebug.so /Applications/XAMPP/xamppfiles/lib/php/extensions/no-debug-non-zts-20151012
```
4、Edit /Applications/XAMPP/xamppfiles/etc/php.ini and add the line

```
zend_extension = /Applications/XAMPP/xamppfiles/lib/php/extensions/no-debug-non-zts-20151012/xdebug.so
```

5、Restart the webserver，到phpinfo查看是否有xdebug相关信息。如下图：

![](Mac下Php的环境配置/phpinfo_xdebug2.png)
![](Mac下Php的环境配置/phpinfo_xdebug.png)

6、如果没有xdebug相关信息，则检查下上述步骤，并且可以查看/Application/XAMPP/logs/error_log里的日志。如果出现类似：

```
Xdebug requires Zend Engine API version 220131226.
The Zend Engine API version 320151012 which is installed, is newer.
Contact Derick Rethans at http://xdebug.org/docs/faq#api for a later version of Xdebug.
```
说明安装是编译xdebug的php版本参数有问题，请重复上述步骤，在参数中使用绝对路径

注1：不推荐在多个php版本情况下直接./configure，可使用

```
./configure --enable-xdebug --with-php-config=/Applications/XAMPP/xamppfiles/bin/php-config-7.0.2
```
注2：不推荐在多个php版本情况下直接phpsize，可使用

```
/Applications/XAMPP/xamppfiles/bin/phpize
```

## 四、PhpStorm中的xdebug配置
1、设置里的debug端口号，默认为9000，如需要修改，需要修改php.ini里的参数。

```txt
[xdebug]
zend_extension = /Applications/XAMPP/xamppfiles/lib/php/extensions/no-debug-non-zts-20151012/xdebug.so
xdebug.remote_enable = On
xdebug.remote_handler = "dbgp"
xdebug.remote_host = "localhost"
xdebug.remote_port = 9000
xdebug.idekey = PHPSTROM
```

![](Mac下Php的环境配置/phpstorm_debug.png)
2、dbgp的proxy设置
![](Mac下Php的环境配置/phpstorm_proxy.png)
3、servers添加，由于xampp默认端口为80
![](Mac下Php的环境配置/phpstorm_servers.png)
4、congigurations添加PHP Web Application，server选择步骤3的名称。根据配置选择路径和浏览器。
![](Mac下Php的环境配置/phpstorm_configurations.png)
5、注意下面2个图标的区别，需要变绿，代表可进行编译断点调试。
![](Mac下Php的环境配置/phpstorm_tools.png)
![](Mac下Php的环境配置/phpstorm_tools_none.png)


6、浏览器的xdebug插件拓展  
chrome下推荐使用Xdebug Helper插件。  
Firefox下推荐The easiest Xdebug插件。以chrome为例，
![](Mac下Php的环境配置/chrome_xdebug.png)

下载地址：可通过chrome拓展安装，需要梯子。提供一个离线安装的，可直接下载[『chrome.crx.zip』](xdebug helper for chrome.crx.zip)，并且添加到扩展程序里。

Done,Enjoy it！
