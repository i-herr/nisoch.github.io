---
title: SpringBoot实战（1）入门
date: 2017-04-01 16:41:04
tags: [SpringBoot,Java]
---

## 一、Spring框架
> 框架设计原则

1. 使用POJO（Plain Old Java Object，普通Java对象）取代EJB（Enterprise Java bean，企业级Java Bean），进行轻量级和最小侵入式开发。
2. 通过IoC（Inversion of Control，控制反转）的DI（Dependency Injection，依赖注入），和基于接口编程实现松耦合。
3. 通过AOP（Aspect Oriented Programming，面向切面编程），和默认习惯进行声明式编程。
4. 通过AOP和模板（template）减少模块化代码，用于事务管理、权限控制、日志记录、性能统计等。

![](SpringBoot实战（1）入门/spring_frame.png)

## 二、IoC相关
> 依赖注入

所谓依赖注入指的是容器负责创建对象和维护对象间的依赖关系，而不是通过对象本身负责自己的创建和解决自己的依赖。

依赖注入是向类里面的属性设置值。主要为了解耦，体现了一种“组合”的理念。如果需要某个类具备某项功能的时候，如继承一个具有此功能的父类，子类将和父类耦合，组合另外一个类则使耦合度大大降低。

关系：依赖注入不能单独存在，需要在IoC基础上完成操作。控制反转是通过依赖注入实现的。

Spring IoC容器（ApplicationContext）负责创建Bean，并通过容器将功能类Bean注入到你需要的Bean中，Spring提供xml、注解、Java/groovy配置来配置元数据，实现Bean的创建和注入。IoC通过dom4j解析xml配置文件，利用工厂设计模式和反射来实现。

> Spring的Bean实例化

1、默认使用类的无参构造创建。

``` bash
<beans>    
    <bean id="userDao" class="com.herr.xml.UserDao"/>    
</beans> 
```

<!--more-->

2、使用静态工厂创建，创建静态方法，返回类对象

``` bash
<beans>    
    <bean id="userDao" class="com.herr.xml.StaticBeanFactory" factory-method="getUserDao"/>    
</beans> 

//StaticBeanFactory类中使用static方法返回UserDao对象

public class StaticBeanFactory{
	public static UserDao getUserDao(){
		return new UserDao();
	}
}
```
3、使用实例工厂创建，创建不是静态的方法，返回类对象，拿类对象创建。

```bash
<beans>    
	<bean id="beanFactory" class="com.herr.xml.BeanFactory"/> 
    <bean id="userDao" factory-bean="beanFactory" factory-method="getUserDao"/>    
</beans> 

public class BeanFactory{
	public UserDao getUserDao(){
		return new UserDao();
	}
}
```

bean有scope属性，默认为singleton（单例），还有prototype（多例）。

> 属性注入

属性注入，就是创建对象时，向类里面的属性设置值。方式有三种：有参构造器注入、set方法(包括P名称空间注入)、接口方法注入。Spring支持前两种注入。

Bean的元数据配置方式也有以下三种，基于xml配置，基于注解配置和基于Java类配置。推荐使用Java配置和注解混合配置。全局配置使用Java配置，业务Bean的配置使用注解配置。Spring容器解析这些元数据，进行Bean初始化、配置和管理依赖。

> 基于xml配置

有参构造使用constructor-arg标签，set方法使用property标签。

> 基于注解配置

1、声明Bean的注解，他们能等效的：

* @Component，没有明确角色。
* @Controller，在展现层/控制层（web层）使用。
* @Service，在业务逻辑层（service层）使用
* @Repository，在数据访问层/持久层（dao层）使用。

2、注入Bean的注解，可注解在set方法或者属性上（优先属性）：

* @Autowired，Spring提供的注解，默认使用type进行匹配。如果需要按名称进行装配，则需要配合@Qualifier。
* @Resource，@Inject，为JSR提供的注解，默认使用name进行匹配。

> 基于Java类配置

可通过@Configuration和@Bean来实现。@Configuration声明当前类是一个配置类，相当于一个xml文件。@Bean注解在方法上，声明当前方法的返回值是一个Bean。


``` bash
@Configuration    
public class JavaConfig{    
    @Bean    
    public UserDao userDao() {    
        return new UserDao();    
    }    
}  
```

以上java配置等同于在xml的配置。

``` bash
<beans>    
    <bean id="userDao" class="com.herr.xml.UserDao"/>    
</beans> 
```


> 接口多态、工厂模式、spring依赖注入区别

* 接口多态，耦合，更换时需要所有对象创建的地方修改。  
* 工厂模式，解耦，只需要修改工厂方法，直接去工厂获取对象。  
* spring依赖注入，不需要写工厂方法，由spring自动扫描、获取，实现动态的拆装组建和组件重用。  

## 三、Spring IoC代码实践    

> 项目目录基本结构

![](SpringBoot实战（1）入门/spring_project1.jpg)
1、说明

使用junit进行单元测试。相关说明请参考代码注释。  
* com.herr.xml为使用xml配置方式，由XMLTest.java进行测试。  
* com.herr.annotation为使用注解配置方式，由AnnotationTest.java进行测试。  
* com.herr.mix为使用java类和注解混合方式配置，由MixTest.java进行测试。  

2、pom.xml

``` java
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.herr</groupId>
    <artifactId>springtest</artifactId>
    <version>1.0</version>
    <packaging>jar</packaging>
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>1.5.10.RELEASE</version>
        <relativePath/> <!-- lookup parent from repository -->
    </parent>
    <properties>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <project.reporting.outputEncoding>UTF-8</project.reporting.outputEncoding>
        <java.version>1.8</java.version>
    </properties>

    <dependencies>
        <dependency>
            <groupId>org.springframework</groupId>
            <artifactId>spring-webmvc</artifactId>
        </dependency>
        <dependency>
            <groupId>junit</groupId>
            <artifactId>junit</artifactId>
            <version>4.12</version>
        </dependency>
        <dependency>
            <groupId>commons-logging</groupId>
            <artifactId>commons-logging</artifactId>
            <version>1.2</version>
        </dependency>
    </dependencies>
</project>
```

> XML文件和java类方式配置
1、UserDao.java

``` java 
package com.herr.xml;

public class UserDao {
    private String age;

    public UserDao() {
    }

    public void printName(){
        System.out.println("herr");
    }

    public UserDao(String age) {
        this.age = age;
    }

    public void printAge(){
        System.out.println(age);
    }
}

```

2、UserService.java

``` java 
package com.herr.xml;

public class UserService {

    private UserDao userDao;
    private String stringValue;

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    public void setStringValue(String stringValue) {
        this.stringValue = stringValue;
    }

    public void printName(){
        userDao.printName();
    }

    public void printString(){
        System.out.println(stringValue);
    }

}

```

3、xml-bean.xml

```java
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:p="http://www.springframework.org/schema/p"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">

    <!-- 默认，需要类中有"无参构造方法" -->
    <bean id="userDao" class="com.herr.xml.UserDao"/>

    <!-- 有参构造属性注入，需要类中有"有参构造方法" -->
    <bean id="userConstructor" class="com.herr.xml.UserDao">
        <constructor-arg name="age" value="18"/>
    </bean>

    <!-- setter属性注入，需要类中有"setter方法" -->
    <bean id="userService" class="com.herr.xml.UserService">
        <!-- 注入dao对象，name为service类里面的属性，ref为dao配置bean中的id值 -->
        <property name="userDao" ref="userDao"></property>
        <!-- 注入value、list、map等复杂类型都可，value为字符串的值。-->
        <property name="stringValue" value="setter://"></property>
    </bean>

    <!-- P标签注入，需要类中有"setter方法" -->
    <bean id="userServiceP" class="com.herr.xml.UserService" p:stringValue="p://"/>

</beans>
```

4、JavaConfig.java

``` java
package com.herr.xml;

import org.springframework.context.annotation.Bean;

public class JavaConfig {

    @Bean
    public UserDao userDao(){
        return new UserDao();
    }
}

```

5、XMLTest.java

``` java
package com.herr.xml;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.junit.Test;

public class XMLTest {

    @Test
    //使用new创建对象
    public void testNormalCreate(){
        UserDao userDao =new UserDao();
        userDao.printName();
    }

    @Test
    //使用java反射机制，创建对象
    public void testReflectionCreate() throws Exception {
        Class clazz= Class.forName("com.herr.xml.UserDao");
        UserDao userDao =(UserDao) clazz.newInstance();
        userDao.printName();
    }

    @Test
    //Spring方式，创建对象
    public void testSpringCreate(){
        ApplicationContext context=new ClassPathXmlApplicationContext("xml-bean.xml");
        UserDao userDao =(UserDao) context.getBean("userDao");
        userDao.printName();
    }

    @Test
    //正常方式，通过有参构造注入属性
    public void testeNormalConstuctor(){
        UserDao userDao = new UserDao("18");
        userDao.printAge();
    }

    @Test
    //Spring方式，通过有参构造注入属性
    public void testSpringConstructor(){
        ApplicationContext context=new ClassPathXmlApplicationContext("xml-bean.xml");
        UserDao userDao =(UserDao) context.getBean("userConstructor");
        userDao.printAge();
    }

    @Test
    //正常方式，通过setter注入属性
    public void testNormalSetter(){
        UserService userService =new UserService();
        userService.setStringValue("normal setter://");
        userService.printString();
    }

    @Test
    //Spring方式，通过setter注入属性
    public void testSpringSetter(){
        ApplicationContext context=new ClassPathXmlApplicationContext("xml-bean.xml");
        UserService userService =(UserService) context.getBean("userService");
        userService.printName();
        userService.printString();
    }

    @Test
    //Spring方式，通过P标签注入属性
    public void testSpringForPLabel(){
        ApplicationContext context=new ClassPathXmlApplicationContext("xml-bean.xml");
        UserService userService =(UserService) context.getBean("userServiceP");
        userService.printString();
    }
    
}

```

> 注解方式配置

1、PersonDao.java

``` java
package com.herr.annotation;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

//默认为@Component(value="personDao")，相当于<bean id="" class="">
@Component(value = "personDao123")
//默认为@Scope(value = "singleton")，为单例时，如同时实例化两个对象，两个对象地址一致。
@Scope(value = "prototype")
public class PersonDao {

    public void printName(){
        System.out.println("herr");
    }

}
``` 
2、PersonService.java

``` java
package com.herr.annotation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class PersonService {
    //自动注入，根据类名来找
    @Autowired
    private PersonDao personDao;
    //使用注解方式时不需要set方法

    @Resource(name = "personDao123")
    private PersonDao personDao123;

    public void printNameByAutowired(){
        System.out.println(personDao);
        personDao.printName();
    }

    public void printNameByResource(){
        System.out.println(personDao123);
        personDao123.printName();
    }

}
```

3、Annotation-bean.xml

``` java
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:context="http://www.springframework.org/schema/context"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd
       http://www.springframework.org/schema/context http://www.springframework.org/schema/context/spring-context-3.0.xsd">
    <!--相比xml配置，注解配置在上方需要添加context相关schema-->
    <!-- 开启注解扫描，到包里面扫描类、方法和属性是否有注解 -->
    <context:component-scan base-package="com.herr.annotation"/>

</beans>
``` 

4、AnnotationTest.java

``` java
package com.herr.annotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.junit.Test;

public class AnnotationTest {

    @Test
    //Spring的注解方式，创建对象
    public void testSpringAnnotationCreate(){
        ApplicationContext context=new ClassPathXmlApplicationContext("annotation-bean.xml");
        PersonDao personDao =(PersonDao) context.getBean("personDao");
        personDao.printName();
    }

    @Test
    //Spring的注解方式，通过setter注入属性
    public void testSpringAnnotationSetter(){
        ApplicationContext context=new ClassPathXmlApplicationContext("annotation-bean.xml");
        PersonService personService =(PersonService) context.getBean("personService");
        //当PersonService的注入属性PersonDao的Scope为单例时，两个对象打印出的地址一致。如为多例时，地址不一致。
        personService.printNameByAutowired();
        personService.printNameByResource();
    }
}
``` 

> java类和注解混合方式配置

1、JavaConfig.java

```bash
package com.herr.mix;

import com.herr.xml.UserDao;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JavaConfig {

    @Bean
    public UserDao userDao(){
        return new UserDao();
    }
}
```

2、MixConfig.java

```bash
package com.herr.mix;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
//配置扫描包里的所有注解
@ComponentScan("com.herr.annotation")
public class MixConfig {
}
```

3、MixTest.java

```bash
package com.herr.mix;

import com.herr.annotation.PersonDao;
import com.herr.xml.UserDao;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MixTest {

    @Test
    //Spring的java类配置方式，创建对象
    public void testSpringJavaConfigCreate(){
        ApplicationContext context = new AnnotationConfigApplicationContext(JavaConfig.class);
        UserDao userDao = context.getBean(UserDao.class);
        userDao.printName();
    }

    @Test
    //Spring的java类配置方式，自动扫描com.herr.annotation包注解，创建对象
    public void testSpringMixConfigCreate(){
        ApplicationContext context = new AnnotationConfigApplicationContext(MixConfig.class);
        PersonDao personDao = context.getBean(PersonDao.class);
        personDao.printName();
    }

}
```

## 四、AOP相关
> AOP概念

AOP：面向切面编程，相对于OOP面向对象编程。
Spring的AOP是为了解耦，AOP可以让一组类共享相同的行为，在OOP中只能通过继承类和实现接口，代码的耦合度增强，且只能单继承，阻碍更多行为添加到一组类上。

Spring支持AspectJ的注解式切面编程。
（1）使用@Aspect声明是一个切面  
（2）使用@After、@Before、@Around定义建言（advice），可直接将拦截规则（切点PointCut）作为参数。
（3）其中@After、@Before、@Around参数的拦截规则为切点（PointCut），为了使切点复用，可使用@PointCut专门定义拦截规则，然后在@After、@Before、@Around参数中调用。
（4）其中符合条件的每一个被拦截处为连接点（JoinPoint）。

> AOP两种实现

分为基于注解拦截和基于方法规则拦截两种，Spring本身在事务处理（@Transactional）和数据缓存（@Cacheable）上有使用注解拦截。

1、pom.xml

```bash
	<dependencies>
        <dependency>
            <groupId>org.aspectj</groupId>
            <artifactId>aspectjrt</artifactId>
        </dependency>
        <dependency>
            <groupId>org.aspectj</groupId>
            <artifactId>aspectjweaver</artifactId>
        </dependency>
    </dependencies>
```

2、Action.java #编写注解

```bash
package com.herr.aop;

import java.lang.annotation.*;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Action {
    String name();
}
```

3、AnnotationService.java

```bash
package com.herr.aop;

import org.springframework.stereotype.Service;

@Service
public class AnnotationService {
    @Action(name="注解式拦截的add操作")
    public void add(){
//        System.out.println("AnnotationService.add()");
    }
}
```
4、AopConfig.java

```bash
package com.herr.aop;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@Configuration
@ComponentScan("com.herr.aop")
@EnableAspectJAutoProxy
public class AopConfig {
}
```

5、LogAspect.java

```bash
package com.herr.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

@Aspect
@Component
public class LogAspect {

    @Pointcut("@annotation(com.herr.aop.Action)")
    public void annotationPointCut(){

    }

    @After("annotationPointCut()")
    public void after(JoinPoint joinPoint){
        MethodSignature signature=(MethodSignature)joinPoint.getSignature();
        Method method=signature.getMethod();
        Action action=method.getAnnotation(Action.class);
        System.out.println("注解式拦截，"+action.name());
    }

    @Before("execution(* com.herr.aop.MethodService.*(..))")
    public void before(JoinPoint joinPoint){
        MethodSignature signature=(MethodSignature)joinPoint.getSignature();
        Method method=signature.getMethod();
        System.out.println("方法式拦截，"+method.getName());
    }
}
```
6、MethodService.java

```bash
package com.herr.aop;

import org.springframework.stereotype.Service;

@Service
public class MethodService {
    public void add(){
        System.out.println("MethodService.add()");
    }
}
```

7、AopTest.java

```bash
package com.herr.aop;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class AopTest {

    @Test
    //Spring的java类配置方式，创建对象
    public void testSpringJavaConfigCreate(){
        ApplicationContext context = new AnnotationConfigApplicationContext(AopConfig.class);
        AnnotationService annotationService=context.getBean(AnnotationService.class);
        MethodService methodService=context.getBean(MethodService.class);
        annotationService.add();
        methodService.add();
    }
}
```

