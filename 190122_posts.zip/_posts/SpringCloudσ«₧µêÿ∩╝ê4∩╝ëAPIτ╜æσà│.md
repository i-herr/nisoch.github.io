---
title: SpringCloud实战（4）API网关
date: 2018-07-10 17:37:30
tags: [SpringCloud,Java]
---

## 一、API网关

API Gateway是一个服务器，也可以说是进入系统的唯一节点。这跟面向对象设计模式中的Facade模式很像。API Gateway封装内部系统的架构，并且提供API给各个客户端。它还可能有其他功能，如授权、监控、负载均衡、缓存、请求分片和管理、静态响应处理等。下图展示了一个适应当前架构的API Gateway。

![](SpringCloud实战（4）API网关/gateway.png)

如果客户端直接和各个微服务通信，会有如下问题：

* 客户端会多次请求不同的微服务，增加客户端复杂性
* 跨域请求
* 认证复杂
* 难以重构

## 二、 项目基础配置

Zuul是Netflix开源的微服务网关，只是API Gateway的一种实现，其他的还有Nginx Plus、Kong等等。SpringCloud对Zuul进行了整合和增强，Zuul的核心是一系列过滤器：

* 身份认证与安全
* 审查与监控
* 动态路由
* 压力测试
* 负载分配
* 静态响应处理
* 多区域弹性

为实现Zuul网关，需要几个基础的module，请参考上一节实战（3）。配置不变。

* eureka-server，作为eureka的server服务注册中心
* service-provider-1，eureka-client端，连接到eureka-server成为服务提供者1。


## 三、Zuul项目配置

1、pom.xml依赖

```
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-netflix-zuul</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
</dependency>
```

2、启动类中，增加注解@EnableZuulProxy激活zuul。

该注解整合了@EnableCircuitBreaker、@EnableDiscoveryClient，是个组合注解。

3、yml配置中，项目的spring.application.name为service-eureka-zuul，端口8040。

<!--more-->

```xml
server:
  port: 8040
spring:
  application:
    name: service-eureka-zuul
eureka:
  client:
    service-url:
      defaultZone: http://localhost:8761/eureka/
  instance:
    prefer-ip-address: true
management:
  endpoints:
    web:
      exposure:
        include: '*'
  endpoint:
    health:
      show-details: always

```

4、测试

需要先依次启动项目基础配置中的2个module(eureka-server和service-provider-1)。才能启动zuul项目。

* 访问http://localhost:8001/1 会返回service1。代表原有service-provider-1项目启动成功。
* 访问http://localhost:8040/service-provider/1 也同样会返回service1。代表zuul项目启动成功。
* 访问http://localhost:8761 可以看到1个SERVICE-PROVIDER和1个SERVICE-EUREKA-ZUUL。
* zuul集成了Hystrix和Ribon负载均衡。

![](SpringCloud实战（4）API网关/eureka.png)

## 四、zuul路径设置

zuul集成了routes端点，可访问http://localhost:8040/actuator/routes 查看映射关系详情。

```json
#routes端点返回
{
	"/user/**": "service-provider",
	"/service-provider/**": "service-provider"
}
```

> 默认规则

默认访问地址 http://localhost:8040/service-provider/1

访问http://GATEWAY:GATEWAY_PORT/想要访问的Eureka服务id的小写/** ，将会访问到，http://想要访问的Eureka服务id的小写:该服务端口/** 。

> 自定义路径

```yml
# 自定义访问地址 http://localhost:8040/user/1
zuul:
  ignored-services: service-provider  # 可以忽略的服务，不被路由，这样默认路径就无法访问了。
  routes:
    user:   # 可以随便写，在zuul上面唯一即可
      path: /user/**  # 想要映射到的路径
      service-id: service-provider  #Eureka中的serviceId

# 以下写法与上面等价    
zuul:
  ignored-services: service-provider
  routes:
    service-provider: /user/**
```

> 忽略微服务/微服务的某些路径

```yml
# 忽略指定微服务
zuul:
  ignored-services: service-provider
  
# 先忽略所有微服务，然后可指定微服务
zuul:
  ignored-services: service-provider
  
# 忽略某些路径，忽略包含/admin/的路径
zuul:
  ignored-patterns: /**/admin/**
  routes:
    service-provider: /user/**
```

> 路由前缀

```yml
# 以下用于路由前缀，访问Zuul的/api/service-provider/1路径，请求将被转发到service-provider的/api/1。
zuul:
  prefix: /api
  strip-prefix: false
  routes:
    service-provider: /user/**

# 以下用于路由前缀，访问Zuul的/user/1路径，请求将被转发到service-provider的/user/1。
zuul:
  routes:
    service-provider:
      path: /user/**
      strip-prefix: false
```

> 本地转发

```yml
# 以下用于本地转发，访问Zuul的/path-a/**路径，请求将被转发到Zuul的/path-b/**。
zuul:
  routes: 
    route-name: #只是个路由名称，任意起名
      path: /path-a/**
      url: forward:/path-b
```

> 同时指定path和URL

```yml
# 改方式将/user/** 映射到http://localhost:8000/。但该方式不会使用Hystrix和Ribbon特性。
zuul:
  routes:
    route-name:
      path: /user/**
      url: http://localhost:8000/
```

另外，还使用正则表达式指定Zuul的路由匹配规则借助PatternServiceRouteMapper，实现微服务到映射路由的正则配置。

若路由遇到问题，可以通过日志查看转发细节。

```yml
logging:
  level:
    com.netflix: DEBUG
```

> Header设置

```
# 设置/忽略header
zuul:
  sensitive-headers: Cookie,Set-Cookie,AUthorization
  ignored-headers: Header1,Header2
```

## 五、Zuul的过滤器

> 查看过滤器

zuul集成了filters端点，可访问http://localhost:8040/actuator/filters 查看过滤器的详情。

```json
#filters端点返回
{
	"error": [{
		"class": "org.springframework.cloud.netflix.zuul.filters.post.SendErrorFilter",
		"order": 0,
		"disabled": false,
		"static": true
	}],
	"post": [{
		"class": "org.springframework.cloud.netflix.zuul.filters.post.SendResponseFilter",
		"order": 1000,
		"disabled": false,
		"static": true
	}],
	"pre": [{
		"class": "org.springframework.cloud.netflix.zuul.filters.pre.DebugFilter",
		"order": 1,
		"disabled": false,
		"static": true
	}],
	"route": [{
		"class": "org.springframework.cloud.netflix.zuul.filters.route.SimpleHostRoutingFilter",
		"order": 100,
		"disabled": false,
		"static": true
	}]
}
```

> 过滤器介绍

过滤器是Zuul的核心组件，定义了4种标准过滤器类型。

* PRE，在请求被路由前调用。可实现身份验证、集群中选择请求的微服务、记录调试信息等。还可以实现安全认证、灰度发布、限流等。
* ROUTING，将请求路由到微服务。
* POST，在请求路由到微服务后执行。可为响应添加Header、收集统计信息和指标、将响应从微服务发送到客户端等。
* ERROR，在其他阶段发生错误时执行。
* 自定义过滤性，可自行创建。

SpringCloud默认为Zuul编写并启用了一些过滤性，通过@EnableZuulServer和@EnableZuulProxy这两个注解实现。

@EnableZuulProxy是@EnableZuulServer的增强版，额外包含了RibbonRoutingFilter等其他几个过滤器。

> 自定义Zuul过滤器

自定义Zuul过滤器代码如下，继承抽象类ZuulFilter并实现4个抽象方法即可。

```java
public class PreRequestLogFilter extends ZuulFilter {
    private static final Logger LOGGER = LoggerFactory.getLogger(PreRequestLogFilter.class);

    @Override
    public String filterType() {
        return FilterConstants.PRE_TYPE;
    }

    @Override
    public int filterOrder() {
        return FilterConstants.PRE_DECORATION_FILTER_ORDER -1;
    }

    @Override
    public boolean shouldFilter() {
        return true;
    }

    @Override
    public Object run() throws ZuulException {
        RequestContext ctx= RequestContext.getCurrentContext();
        HttpServletRequest request= ctx.getRequest();
        PreRequestLogFilter.LOGGER.info(String.format("send %s request to %s",request.getMethod(),request.getRequestURL().toString()));
        return null;
    }
}
```

> 禁用过滤器

```yml
#格式
zuul.<SimpleClassname>.<filterType>.disable=true

#示例，禁用上节定义的过滤器
zuul. PreRequestLogFilter.pre.disable=true
```

## 六、Zuul的其他特性

> Zuul的容错与回退

为Zuul添加回退，需实现FallbackProvider接口。

```java
@Component
public class MyFallbackProvider implements FallbackProvider {
    @Override
    public String getRoute() {
        // 为所有微服务提供回退
        return "*";
    }

    @Override
    public ClientHttpResponse fallbackResponse(String route, Throwable cause) {
        if (cause instanceof HystrixTimeoutException) {
            return response(HttpStatus.GATEWAY_TIMEOUT);
        } else {
            return this.fallbackResponse();
        }
    }

    public ClientHttpResponse fallbackResponse() {
        return this.response(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    private ClientHttpResponse response(final HttpStatus status) {
        return new ClientHttpResponse() {
            @Override
            public HttpStatus getStatusCode() throws IOException {
                return status;
            }

            @Override
            public int getRawStatusCode() throws IOException {
                return status.value();
            }

            @Override
            public String getStatusText() throws IOException {
                return status.getReasonPhrase();
            }

            @Override
            public void close() {
            }

            @Override
            public InputStream getBody() throws IOException {
                return new ByteArrayInputStream("服务不可用，请稍后再试。".getBytes());
            }

            @Override
            public HttpHeaders getHeaders() {
                // headers设定
                HttpHeaders headers = new HttpHeaders();
                MediaType mt = new MediaType("application", "json", Charset.forName("UTF-8"));
                headers.setContentType(mt);
                return headers;
            }
        };
    }
}
```

> Zuul中Hystrix隔离策略和线程池

```yml
zuul:
  #使用THREAD隔离策略
  ribbon-isolation-strategy: thread 
  thread-pool:
    #每个路由使用独立的线程池
    use-separate-thread-pools: true
    #变更HystrixThreadPoolkey  
    thread-pool-key-prefix: prefix- 
```

> 高可用性

1、如请求Zuul的客户端也注册到了Eureka上，则会自动实现Zuul的高可用性。
![](SpringCloud实战（4）API网关/zuul_cluster1.jpg)

2、如请求Zuul的客户端未注册到了Eureka上，可借助额外的负载均衡器来实现Zuul的高可用性。
![](SpringCloud实战（4）API网关/zuul_cluster2.jpg)

> 微服务聚合

Zuul可结合RxJava，由Zuul来请求多个微服务的请求，并组织好数据返回。

## 七、Sidecar整合非JVM微服务

非JVM微服务可操作Eureka的Rest端点实现注册与发现。也可以使用SpringCloud Netflix Sidecar来整合。

> Node.js微服务

1、node-service.js

```js
var http = require('http');
var url = require("url");
var path = require('path');

// 创建server
var server = http.createServer(function(req, res) {
    // 获得请求的路径
    var pathname = url.parse(req.url).pathname;
    res.writeHead(200, { 'Content-Type' : 'application/json; charset=utf-8' });
    // 访问http://localhost:8060/，将会返回{"index":"欢迎来到首页"}
    if (pathname === '/') {
        res.end(JSON.stringify({ "index" : "欢迎来到首页" }));
    }
    // 访问http://localhost:8060/health，将会返回{"status":"UP"}
    else if (pathname === '/health.json') {
        res.end(JSON.stringify({ "status" : "UP" }));
    }
    // 其他情况返回404
    else {
        res.end("404");
    }
});
// 创建监听，并打印日志
server.listen(8060, function() {
    console.log('listening on localhost:8060');
});
```

2、命令启动

```bash
$ node node-service.js
```

3、访问http://localhost:8060/health.json 和http://localhost:8060/ 

> Sidecar项目

1、POM依赖

```xml
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-netflix-zuul</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-netflix-sidecar</artifactId>
</dependency>
```

2、yml配置

```yml
server:
  port: 8070
spring:
  application:
    name: service-sidecar
eureka:
  client:
    service-url:
      defaultZone: http://localhost:8761/eureka/
  instance:
    prefer-ip-address: true
sidecar:
  port: 8060   # Node.js微服务的端口
  health-uri: http://localhost:8060/health.json # Node.js微服务的健康检查URL
  ip-address: #如果Sidecar和Node分离部署，可以设置非JVN微服务的IP地址
  hostname: #如果Sidecar和Node分离部署，可以设置非JVN微服务的hostname
```

3、service-provider-1增加testNode节点，使用Ribbon调用node服务。

```java
    @GetMapping("/testNode")
    public String fintestNodedByhahaId() {
        return this.restTemplate.getForObject("http://service-sidecar/",String.class);
    }
```

4、测试

* 非JVM调用JVM，可访问地址http://localhost:8070/service-provider/1 来调用JVM微服务。
* JVM调用非JVM，http://localhost:8070/service-provider/testNode 来调用Node微服务。
* 查看service-sidecar在erureka上的注册信息，http://localhost:8761/eureka/apps/service-sidecar 
* 停掉Node微服务node-service后，Eureka Server能感知到非JVM微服务的健康状态。

![](SpringCloud实战（4）API网关/sidecar_eureka.png)

5、Sidecar端点

* /：展示常用端点
* /hosts/{serviceId}：指定微服务在Eureka的实例列表
* /ping：返回OK


## 八、相关代码

[『代码传送门』](https://gitee.com/iherr/spring-cloud-trip-zuul.git)