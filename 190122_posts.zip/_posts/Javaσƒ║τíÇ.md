---
title: Java基础
date: 2015-05-26 16:22:53
tags: [Java]
---

## 一、基础概念
* java编写的程序，既是编译型的，又是解释型的。代码经过编译会生成字节码class文件，由JVM对字节码进行解释和运行。编译只进行一次，而解释在每次程序运行时都会进行。  
* 有3个版本，Java SE（标准），Java EE（企业），Java ME（嵌入）。
* 需安装JDK（Java Development Kits），里面包含JRE(Java Runtime Environment)。需做相关环境配置。 
* 编译运行java程序，且Java虚拟机只会选择从main方法开始执行。

```bash
$ javac -d . HelloWorld.java //javac -d destdir srcFile
$ java HelloWorld //java java类名
$ java HelloWorld arg1 arg2 //增加arg1和arg2两个参数，赋值给main方法的参数
``` 

```java
public static void main(String[] args){
}
```

## 二、数据类型和基础类库  

Java支持两种数据类型，基本类型和引用类型。

> 基本数据类型

包括数值型（整数、浮点）、字符型和布尔型。  

> 包装类

java.lang包中的Integer、Long和Short类，将基本类型封装成一个类，都是Number的子类。  

Java为8种基本类型提供面向对象的支持，定义了响应的引用类型，称之为基础数据类型的包装类。JDK1.5以后提供自动装箱和自动拆箱功能，简化两者的转换。

| 封装类 | 对应基本类型 | 构造方法 |
| :-------:  |:---: 	|---		|
|	Integer	|int|	Integer(int number); Integer(String str);
|	Boolean   |	boolean 	|	Boolean(boolean value);Boolean(String str);  |   	|
|	Byte 	   |	byte	   |	Byte(byte value); Byte(String str);   |   	| 
|	Character |  char 	   |	Character(char value)  |  |
|	Double |  double 	   |	Double(double value); Double(String str);  |  |
|	Short |  short 	   |	Short(short value); Short(String str);  |  |
|	Long |  long 	   |	Long(long value); Long(String str);  |  |
|	Float |  float 	   |	Float(float value); Float(String str);  |  |


包装类实现了基本类型变量和字符串的转换。把字符串转换为基本类型的方式：

* 包装类parseXxx(String s)静态方法（除Charater外）
* 包装类valueOf(String s)静态方法

String类提供多个重载valueOf()静态方法，将基本类型变量转换成字符串。

> 字符串 

| 序列 | 操作 | 方法 | 说明 | 
| --- | -------  |:---: 	|:---:	|
|  1 |	连接字符串	|	+	|	 	
|  2 |	长度 |	str.length(); 	|	  
|  3 |	字符串查找 	|str.indexOf(substr); str.lastIndexOf(substr) 	|	  
|  4 |	获取指定索引的字符 		|  str.charAt(6); |
|  5 |	获取子字符串 		|  str.substring(int beginIndex); str.substring(int beginIndex,int endIndex); |
|  6 |	去空格 		|  str.trim(); |	 	
|  7 |	字符串替换 		|  str.replace(char oldChar,char newChar); |	 	
|  8 |	字符串的开始与结尾 		|  str.startsWith(String prefix); str.endsWith(String suffix); |	 
|  9 |	是否相等 		|  equals();equalsIgnoreCase() |“==”比较的是两个字符串的地址是否相同。
|  10 |	按字典顺序比较 		|  str.compareTo(String otherstr); |	如在参数之前为负整数，相等为0，之后为正整数 
|  11 |	字母大小写转换 		|  str.toLowerCase(); str.toUpperCase();  |	 
|  12 |	字符串分割 		|  str.split(String sign);  str.split(String sign,int limit); |可限定分割次数	 
|  13 |	字符串格式化 		|  str.format(String format,Object...args); |	可对日期、时间以及组合，各种进制（如%d为十进制）、其他类型进行格式化。 
|  14 |	使用正则表达式 		|  str.matches(regex); |
|  14 |	StringBuilder类 		|  bf.append(content); bf.insert(int offset,arg);  bf.delete(int start,int end); |字符串创建后，长度固定，内容不能被改变和变异。+会生成新的String实例，如需要频繁修改，会增加系统开销	 	 	

> 数组： 
 
1. 声明 int arr[];（或int[] arr;） arr=new int[5];等价于int arr[]=new int[5];   
2. 初始化数组 int arr[]=new int[]{1,2,3,4,5};等价于int arr[]={1,2,3,4,5};  
3. 使用一维数组 int value=arr[int i];  
4. 遍历数组 for(int k=0,k<str.length();k++)或 foreach. 
5. 排序 Array.sort(object);  
6. 复制数组 Array.copyOfRange(arr,int newlength);Array.copyOfRange(arr,int fromIndex,int toIndex);前包后不包括。  
7. 排序算法 冒泡排序、直接选择排序，详情见算法导论。

> 数学运算：Math类

三角函数、指数对数函数、取整函数、最值函数等。

```java
Math.PI;   
Math.E;   
Math.sin(Math.PI);  
Math.exp(2);  
Math.log(2);  
Math.sqrt(4);  
Math.cbrt(8);  
Math.pow(2,2); //2的2次方  
Math.ceil(1.1); //大于等于参数的最小整数  
Math.floor(1.2); //小于等于参数的最大整数  
Math.rint(1.2); //最接近参数的整数，如一样近取偶数。  
Math.abs(-1.1);  
Math.max(4,8);  
Math.min(4,8);
```

> 随机数
  
Math.random();随机数，0.0<=值产生<1.0

(int)(Math.Random()*n)，是根据当前时间作为参数的伪随机数。

也可使用java.util.Random类来生成。

> 大数字运算：java.math.BigInteger类和java.math.BigDecimal类。

```java
BigInteger value=new BigInteger(String val);
BigDecimal value=new BigDecimal(double val);
BigDecimal value=new BigDecimal(String val);
```

| 常用类  | 说明 |
| :-----: |-----|
|Scanner|	键盘输入|
|System|	标准输入输出|
|Runtime|	运行环境|
|Object|	基类|
|Date|	日期|
|Calendar|	日历|
|Pattern|	正则表达式|
|Matcher|	正则匹配|

> 枚举常量

类型安全，运行效率高。

``` bash
public enum Constants{
	Constans_A,
	Constans_B,
	Constans_C
}
``` 

枚举常用方法：  
values() 返回枚举成员的数组形式。valueOf将字符串转换为枚举实例，ordinal()得到枚举成员的位置索引。

## 三、类和对象
> 类

从面向过程到面向对象，先抽象出对象，识别属性和行为。类就是封装属性和行为的载体，对象是类的一个实例。

类定义=成员变量（状态数据）+方法（行为）

面向过程中，一切以函数为中心，而面向对象中，一切以对象为中心。

```
吃(猪八戒,西瓜) //面向过程
猪八戒.吃(西瓜) //面向对象
```

类定义=成员变量（状态数据）+方法（行为）

```java
[修饰符] class 类名
{
	0到多个构造器定义
	0到多个成员变量
	0到多个方法
}
```

> 对象

* 对象创建的根本途径是构造器，通过new关键字来调用某个类的构造器。Test test=new Test();   
* 访问对象的属性和行为，使用“对象.类成员”来获取。  
* 对象的成员变量数据实际存在在堆内存里，而引用变量只是指向该堆内存里的对象，引用变量存放在栈内存中。
* 对象的比较，使用 “==”运算符代表两个对象引用的地址是否相等。  
* 对象的销毁，当对象引用超过作用范围，被会视为垃圾。将对象赋值为null。  
* 针对垃圾回收机制，finalize()方法可能无效，可使用System.gc()来手动执行回收。 
* this，总是指向调用该方法的对象，是本类对象的引用。Java允许对象的一个成员直接调用另一个成员，可以省略this前缀。 

> 变量

变量分为成员变量和局部变量。

1、成员变量分为静态变量和实例变量。

静态变量，也叫类变量，添加static关键字，能以“类名.类变量”的方式调用，也允许以“实例.类变量”的方式调用。

实例变量，能以“实例.实例变量”的方式调用。

成员变量的初始化，当系统加载类或者创建该类实例时，会自动为成员变量分配内存空间，并指定初始值。以引用类型为例，栈内存为引用的变量，堆内存包含类变量（只创建一次）和实例变量（每次初始化均创建）。

2、局部变量分为形参、方法局部变量和代码块局部变量。与成员变量不同，局部变量除形参之外，都必须显式初始化，否则不可以访问它们。

局部变量的初始化，局部变量定义后，系统不会为局部变量执行初始化，并未分配内存，等到为变量赋初始值后才分配内存。栈内存中的变量无须系统垃圾回收，随方法或代码块的结束而结束。

Java允许局部变量和成员变量同名，方法局部变量会覆盖成员变量，如在方法里需引用成员变量，可使用this（实例变量）或类名（类变量）作为调用者来访问。

> 方法

* 方法不能独立定义，必须属于类或对象。
* 永远不能独立执行方法，执行方法必须使用类或对象作为调用者。
* Java里方法的参数传递只有值传递这一种，无论是基本类型的值的复制，还是引用类型在栈内存中引用变量的地址的值的复制。
* 静态方法中不能使用this关键字，不能直接调用非静态方法，以“类名.静态方法”的方式调用。     
* 类的main主方法，是类的入口点，它定义了程序从何处开始，是静态的，调用其他方法也必须静态，且没有返回值。主方法的形参为数组，代表程序的n个参数。 
* 类的构造方法：没有返回值，名称与类名称相同。Java类至少包含一个构造器，系统默认会提供一个无参数的构造器。构造器可重载。 

<!--more-->

形参个数可变的方法

```java
public static void test(int a,String... books){
	for (String tmp : books){
		System.out.println(tmp);
	}
}

//调用方法
test(5,"booktitle1","booktitle2")
```

面向对象的特点有：封装，继承和多态。

> 封装

将对象的状态信息隐藏在对象内部，不允许外部程序直接访问对象内部信息，而是通过该类所提供的方法来实现对内部信息的操作和访问。良好的封装可实现以下目的

* 隐藏类的实现细节
* 让使用者只能通过事先预定的方法来访问数据
* 可进行数据检查，保证对象信息的完整性
* 便于修改，提高代码的可维护性

Java提供了3个访问控制符，还有个不加任何访问控制符，提供了4个访问控制级别。

| 访问修饰符 | 同一个类 | 同包 | 不同包，子类 | 不同包，非子类
| -------  |:---: 	|:---:		|:---:	|:-----: |
|	private	|	√	|	 	|   	|
|	default 	|  √	|	√ 	|   	|
|	protected |	√ 	|	√  |  √ 	|
|	public 	|	√	|	√  |  √ 	| √

> 包

一种管理类文件的机制，就是类包，避免类名称冲突。同一个包中的类相互访问可以不指定包名。包名全部小写，使用package关键字定义，使用import关键字导入。可以使用import static 导入类中静态方法或成员变量。

> 继承

1、Java继承使用extends关键字，本意拓展，只能单继承，最多只有一个直接父类。

2、方法重写：子类包含与父类同名方法的现象被称为方法重写/覆盖（Override）。重写要遵循“两同两小一大”，“两同”方法名和形参列表相同，“两小”子类方法返回值类型要比父类更小或相等，子类声明抛出的异常类比父类更小或相等，“一大”子类方法的访问权限比父类更大或相等。

3、依赖super关键字，可以在子类方法中调用父类被覆盖的实例方法、实例成员，以及父类构造器。在实例化子类对象时，子类调用父类构造器分以下情况:

* 如第一行使用super显式调用父类构造器，系统根据super调用的实参列表调用父类对应的构造器。
* 如第一行使用this显式调用本类中重载的构造器，系统根据this调用的实参列表调用本类的另一个构造器。执行该构造器时会调用父类构造器。
* 如既没有super和this调用，会在子类的构造器之前，自动调用父类的无参构造方法。（父类的有参构造方法并不能被自动调用，只能依赖super关键字显式调用。）

4、所有类的基类，是java.lang.Object类。如创建类时无指定，则默认继承Object类。有几个重要方法：getClass().getname(); toString(); equals(); equals方法默认使用“==”运算符比较两个对象的引用地址，如需要比较两个对象的内容，需要在自定义类中重写equals()方法。

5、继承是“是”（is-a）的关系，组合是“有”（has-a）的关系。

> 多态

1、Java引用变量有两个类型：编译时类型和运行时类型。编译时类型由声明决定，运行时类型由实际赋给变量的对象决定。当编译时类型与运行时类型不一致时，可能出现多态。

2、引用类型的转换，只能在具有继承关系的两个类型之间进行，没有继承关系的无法进行类型转换，否则编译时会出现错误。

向上转型：将子类对象看做是父类对象（子类是特殊的父类，比如鸟一定是动物）。由于向上转型是具体类到抽象类的转换，因此是安全的。  
向下转型：将父类对象强制转换为某个子类对象时，需要强制类型转换。但可能产生ClassCastException异常，可使用instanceof运算符来判断父类对象是否为子类的实例，然后再使用(type)运算符进行强制类型转换。

```
#在编译状态中，class可以是object对象的父类，自身类，子类。在这三种情况下Java编译时不会报错。
#在运行转态中，class可以是object对象的父类，自身类，不能是子类。在前两种情况下result的结果为true，最后一种为false。但是class为子类时编译不会报错。运行结果为false。

if(parent instanceof Child){
	Child child = (Child)parent;//向下转型
}
```

3、多态：“一个接口，多种方法”。同一操作作用于不同的对象，可以有不同的解释，产生不同的执行结果，以此解决代码冗余问题。父类引用指向子类对象，调用方法时会调用子类的实现，而不是父类的实现。

``` bash
Parent instance = new Child();
instance.foo(); //==> Child foo()
```

成员变量，编译看父类，运行看父类。  
成员方法，编译看父类，运行看子类。动态绑定。  
静态方法，编译看父类，运行看父类。 (静态和类相关，算不上重写）

4、多态的三个条件:

* 继承的存在(继承是多态的基础,没有继承就没有多态)  
* 子类重写父类的方法(多态下调用子类重写的方法)  
* 父类引用变量指向子类对象(子类到父类的向上转型安全)

5、重载（overload）和重写（override）是实现多态的两种主要方式。

重载：在同一个类允许同时存在一个以上的同名方法，只要这些方法的参数个数或类型不同即可。当只有返回类型时不同不足以区分重载。

``` bash
//重载
void foo(String str);
void foo(int number);
```

重写：父类与子类有同样的方法名和参数。

``` bash
//重写
class Parent {
    void foo() {
        System.out.println("Parent foo()");
    }
}
class Child extends Parent {
    void foo() {
        System.out.println("Child foo()");
    }
}
```

> 初始化块

* 构造器用于Java对象的状态初始化，也可使用初始化块来对Java对象进行初始化操作。
* 一个类里可以有多个初始化块，按顺序执行。
* 被static修饰的称为静态初始化块，不能访问非静态成员。
* 初始化块只在创建Java对象时隐式执行，且在执行构造器之前执行。
* 静态初始化块在类初始化阶段执行，而不是在创建对象时才执行，且只需执行一次。

```
[修饰符] {
	//code
}
```

> static修饰符

* static关键字修饰的成员就是类成员，包括类变量、类方法、静态初始化块、内部类等。
* static不能修饰构造器，因为static修饰的成员属于整个类，而不是实例。
* 类成员不能访问实例成员，因为可能类成员初始化完成后，实例成员还未初始化。
* 可通过static静态方法，返回实例，来实现单例。

> final修饰符

final关键字可用于修饰类、变量和方法，表示修饰的类、方法和变量不可改变。通常final定义的变量为常量。一旦设定，不可改变变量的值。

1、final修饰成员变量，成员变量随类/对象的初始化而初始化，并分配默认值。final修饰后不可改变，因此java语法规定，final修饰的成员变量必须由程序员显式地指定初始值。成员变量的初始值可以在定义该变量时指定默认值，或者在初始化块、构造器中指定初始值。

2、final修饰局部变量，系统不会对局部变量进行初始化，因此使用final修饰局部变量时，可在定义时指定默认值，也可不指定。

3、final修饰基本类型变量和引用类型变量的区别：基本类型变量不能被改变，但对象引用也只能指向唯一一个对象，不可以再指向其他对象，但是一个对象本身的值确实可以改变的。为了真正不可更改，可以将常量声明为static final，在装载类时被初始化，而不是每次创建对象时被初始化。

4、final方法：定义为final的方法不能被重写，可以被重载。如果是父类方法使用private final，子类可以生成新的方法，但不是覆盖。

5、final类：定义为final的类不能被继承。

6、不可变类：8个包装类和String类都是不可变类。创建实例后，该实例的实例变量是不可改变的。

> 抽象类

* 抽象类体现的是一种模板模式，从多个类中抽象出来的模板，只实现通用部分，不通用的部分抽象成抽象方法，留给子类实现。
* 使用abstract关键字，定义的类为抽象类，定义的方法为抽象方法。
* 有抽象方法的类只能被定义成抽象类，抽象类里可以没有抽象方法。
* 抽象方法不能有方法体，连括号都没有，区别于空方法体。
* 抽放类可以包含成员变量、方法、构造器、初始化块和内部类（接口、枚举）5种成分。
* 抽放类不能被实例化，因此抽象类的构造器不能用于创建实例，主要用于被其子类调用。
* 抽象类只能当做父类被继承，且子类必须实现抽象类中的所有抽象方法。

> 接口

* 接口是特殊（纯粹）的“抽象类”，体现的是规范和实现彻底分离的设计哲学。是开放的（public）且不能随意更改的（final）的规范。
* 接口使用interface关键字定义，一个类实现接口可以使用implements关键字。
* java规定一个类不能同时继承多个父类，但一个类可以同时实现多个接口，子类重写父类时访问权限只能更大或相等，因此实现类的方法只能是public。
* 修饰符可以是public或者省略，接口里的常量、方法、内部类和内部枚举都是public访问权限。
* 接口是一种规范，因此不能包含构造器和初始化块。成员变量必须是静态变量（系统会自动为接口内的成员变量增加static和final两个修饰符，只能在定义时指定默认值），方法只能是抽象方法（不修饰，自动增加public和abstract修饰符进行抽象）、类方法（static修饰）、默认方法（default修饰）和私有方法（private修饰，Java9功能）。

接口和抽象类的相同点：

* 都不能被实例化，位于继承树的顶端，用于被其他类实现和继承。
* 都可以包含抽象方法，实现接口或继承抽象类的子类必须实现这些抽象方法。

差异：

* 接口不能为普通方法提供方法实现，抽象类可包含普通方法。
* 接口里只能定义静态常量，不能定义普通成员变量。抽象类都可以。原因：一个类可以实现多个接口，会导致同名变量混淆。但一个类只能继承一个抽象类，不存在这个问题。
* 接口里不包含构造器，抽象类包含构造器，但只用于子类调用来完成抽象类的初始化。
* 接口里不包含初始化块，抽象类包含初始化块。
* 一个类可以实现多个接口，但一个类只能继承一个抽象类。

面向接口的编程：

* 简单工厂模式，
* 命令模式

>  内部类 

* 如果在类内部再定义一个类，被称为内部类。
* 内部类比外部类多使用三个修饰符：private、protected、static。
* 内部类成员可直接访问外部类的私有数据。如果外部类成员变量、内部类非静态成员变量和内部类方法的局部变量同名，可使用this、外部类类名.this作为限定来区分。
* 外部类不能直接访问非静态内部类的实例变量，需要显式创建内部类对象才可访问。
* 使用static修饰的内部类称为静态内部类（类内部类），这个类时属于外部类本身，而不是某个外部类对象。
* 静态成员不能访问非静态成员，因此外部类的静态方法、静态代码块不能访问非静态内部类。会出现类加载时还没有创建内部类，就访问内部类实例的异常情况。
* 不允许在非静态内部类里定义静态成员。会导致该静态成员无法通过“外部类.内部类.静态变量”访问。
* 静态内部类里，可以包含静态成员和非静态成员。静态内部类不能访问外部类的实例成员，只能访问外部类的类成员。

内部类使用：

1、外部类内部使用内部类

和平常的类使用没有区别。

2、外部类以外使用非静态内部类

```java
OuterClass out=new OutClass();
OuterClass.InnerClass in=out.new InnerClass();
```

3、外部类以外使用静态内部类

```java
OuterClass.InnerClass in=new OutClass().InnerClass();
```

> 匿名内部类

* 匿名内部类必须继承一个父类或实现一个接口，最多只能一个。
* 匿名内部类不能是抽象类，在创建匿名内部类时会立即创建对象。
* 匿名内部类不能定义构造器。没有类名，无法使用构造器。但可以定义初始化块。


```java
new 实现接口() | 父类构造器(实参列表){
}
```

> Lambda表达式

* 可使用java8新增的Lambda表达式来简化创建匿名内部类对象，Lambda支持将代码块作为方法参数，使用更简洁的代码来创建只有一个抽象方法的接口（函数式接口）的实例。
* Lambda包含形参列表、箭头（->）、代码块，省略了new Xxx(){}、重写的方法名字、重写方法的返回值。
* Java8提供@FunctionalInterface注解，用于标记函数式接口。Lambda表达式的目标类型，必须是明确的函数式接口。

当Lambda表达式的代码只有一条，可以使用方法引用和构造器引用。

```java
@FunctionalInterface
interface Converter{
    Integer convert(String from);
}

@FunctionalInterface
interface MyTest{
    String test(String a,int b,int c);
}

@FunctionalInterface
interface MyTest2{
    String newStr(String title);
}

public class MethodRefer {
    public static void main(String[] args) {
        Converter converter1 = from -> Integer.valueOf(from);
        Integer val=converter1.convert("99");
        System.out.println(val);
        //1、引用类方法，格式为：类名::类方法，对应的Lambda表达式：(a,b,...)->类名.类方法(a,b,...)
        Converter converter2=Integer::valueOf;
        System.out.println(converter2.convert("199"));

        Converter converter3=from -> "iherr".indexOf(from);
        Integer value=converter3.convert("er");
        System.out.println(value);
        //2、引用特定对象的实例方法，格式为：特定对象::实例方法，对应的Lambda表达式：(a,b,...)->特定对象.实例方法(a,b,...)
        Converter converter4= "iherr"::indexOf;
        System.out.println(converter4.convert("er"));

        MyTest mt=((a, b, c) -> a.substring(b,c));
        String str=mt.test("Hello herr",2,7);
        System.out.println(str);
        //3、引用某类对象的实例方法，格式为：类名::实例方法，对应的Lambda表达式：(a,b,...)->a.实例方法(b,...)
        MyTest mt2= String::substring;
        System.out.println(mt2.test("Hello herr",2,7));

        MyTest2 mt3=title -> new String(title);
        String str3= mt3.newStr("herr");
        System.out.println(str3);
        //4、引用构造器，格式为：类名::new，对应的Lambda表达式：(a,b,...)->new 类名(a,b,...)
        MyTest2 mt4=String::new;
        System.out.println(mt4.newStr("herr"));
    }
}
```

## 四、集合类

![](Java基础/jihe.jpg)

* 集合类用于存储数量不等的对象，可实现常用的数据类型，如栈、队列等。
* 集合和数组的区别：数组长度固定，集合长度可变。数组只能存储相同数据类型的数据，集合可以存储各种类型的数据。集合里不能放基本类型的值，但支持自动装箱。
* 集合分为Map和Collection（包含List、Set、Queue）。其中List允许重复且有顺序，Set无重复且无序，Queue队列。  

> Collection

Collection接口定义了add、addAll、remove、removeAll、clear、contains、isEmpty、iterator迭代器、size等操作集合元素的方法。 

集合遍历

```java
	Collection c =new ArrayList();
	c.add("herr1");
	c.add("herr2");
		
	//1、使用java8增强的Iterator遍历集合
	Iterator it=c.iterator();
	while(it.hasNext()){
	    String str=(String)it.next();
	    System.out.println(str);
	}
		
	//2、使用Lambda表达式遍历集合
	c.forEach(obj-> System.out.println(obj));
		
	//3、使用Lambda表达式遍历Iterator
	Iterator it2=c.iterator();
	it2.forEachRemaining(obj->System.out.println(obj));
		
	//4、使用foreach循环遍历
	for (Object obj:c){
	    System.out.println(obj);
	}
	
	//5、使用java8新增的Stream操作集合
    System.out.println(c.stream().filter(obj ->((String)obj).length()<2).count());
    //6、使用java8新增的Predicate操作集合
    c.removeIf(obj ->((String)obj).length()>2);

    System.out.println(c);
```

> Set

常见实现类有HashSet、TreeSet和EnumSet类。都是线程不安全的，可通过Collections工具类的synchronizedSortedSet方法来包装实现同步。

1、HashSet

* 不在保证迭代顺序，根据对象的hashCode()方法得到的hashCode值来决定存储位置，具备很好的存取和查找性能。
* 不是同步的，当多线程处理时需保证同步。
* 允许使用null元素。
* HashSet判断两个元素相等的标准是两个对象通过equal()方法比较相等，且两个对象的hashCode()返回值也相等。
* 有子类LinkedHashSet，还是按hashCode值来决定存储位置，但使用链表维护元素的次序，将会按元素添加顺序来访问集合里的元素。

2、TreeSet

* TreeSet是SortedSet接口的实现类，确保集合元素处于排序状态。
* TreeSet采用红黑树的数据结构来存储集合元素。支持两种排序方法：自然排序和定制排序。性能差
* 自然排序，按升序排列元素需要实现Comparable接口的compareTo方法，因此TreeSet只能添加同一种类型的对象。且判断相等的标准是两个对象的compareTo方法是否返回0。
* 定制排序，可在创建集合对象时，提供Comparator对象关联。

```java
	TreeSet nums = new TreeSet();
	nums.add(5);
	nums.add(15);
	nums.add(-5);
	nums.add(25);
	
	System.out.println(nums);
	
	System.out.println(nums.first());
	System.out.println(nums.last());
	System.out.println(nums.headSet(5));
	System.out.println(nums.tailSet(5));
	System.out.println(nums.subSet(5,15));
```

3、EnumSet

* 专门为枚举类设计的集合类，所有元素都必须是枚举类型的枚举值。
* 以位向量的形式存储，紧凑、高效。
* 不允许加入null元素。

```java
enum Season{
    SPRING,SUMMER,FALL,WINTER
}

public class EnumSetTest {
    public static void main(String[] args) {
        EnumSet es1=EnumSet.allOf(Season.class);
        System.out.println(es1);
        EnumSet es2=EnumSet.noneOf(Season.class);
        System.out.println(es2);
        es2.add(Season.WINTER);
        //of方法创建的是不可变集合
        EnumSet es3=EnumSet.of(Season.SUMMER,Season.WINTER);
        System.out.println(es3);
        EnumSet es4=EnumSet.range(Season.SUMMER,Season.WINTER);
        System.out.println(es4);
    }
}
```

> List

List是Collection接口的子接口。增加了一些根据索引来操作集合元素的方法。

```java
    List books =new ArrayList();
    books.add("book1");
    books.add("book2");
    books.add("book3");
    System.out.println(books);

    System.out.println(books.get(1));
    books.add(1,"add1");
    books.remove(2);
    books.set(2,"resetbook3");
    System.out.println(books);
    System.out.println(books.subList(1,2));
    books.sort((o1, o2) -> ((String)o1).length()-((String)o2).length());
    System.out.println(books);
```

* ArrayList和Vector都是List接口的实现，封装了可变数组，底层采用一个动态的、可重新分配的Object[]数组来存储集合元素，当元素集合超过该数组容量时，会重新再分配一个Object[]数组。
* Vector很古老，虽然线程安全，但不推荐使用。
* 如有多个线程同时访问元素，因为大部分都是线程不安全的，可以通过Collections工具类包装成线程安全。也可使用Concurrent开头的集合类，如ConcurrentHashMap等，支持并发访问，且写入线程的操作时线程安全的。
* 数组工具类Arrays的asList方法，是Arrays内部类ArrayList的实例，是固定长度。
* 此外还有LinkedList，实现了Deque接口，可作为List集合、双端队列、栈来使用。和基于数组的线性表ArrayList相比，LinkedList基于链表结构，插入/删除元素时性能出色，但随即访问元素时性能较差。
* 通常不需要考虑ArrayList和LinkedList性能差异，大部分情况考虑使用ArrayList。对于经常执行插入删除操作包含大量数据的List集合，可考虑使用LinkedList。
* 如需要遍历List集合元素，对于ArrayList和Vector，使用get方法来遍历集合，对于LinkedList，采用迭代器（Iterator）来遍历，这样性能更好。
* Enumeration接口是Iterator迭代器的古老版本，只能遍历Vector、HashTable这种古老的集合，不推荐使用。

> Queue集合

* Queue用于模拟队列，实现“先进先出”(FIFO)的容器。
* Queue接口定义了将元素加入队列尾部，获取队列头部元素等方法。
* Queue接口有一个PriorityQueue实现类，并且按照队列元素的大小重新排序。

Deque是Queue接口的子接口，代表双端队列，可以当成队列使用，也可当成栈来使用。Deque方法与Queue和Stack的方法对照表如下：

| Queue方法  | Deque方法 | 说明
| ----- |-----|-----|
|add(e)/offer(e)|	addLast(e)/offerLast(e)| 将元素添加到队列尾部
|remove()/poll()|	removeFirst()/pollFirst()|获取头部元素，删除该元素
|element()/peek()|	getFirst()/peekFirst()| 获取头部元素，不删除该元素

| Stack方法  | Deque方法 | 说明
| ----- |-----|-----|
|push(e)|	addFirst(e)/offerFirst(e)| 将元素添加到队列头部
|pop()|	removeFirst()/pollFirst()|获取头部元素，删除该元素
|peek()|	getFirst()/peekFirst()| 获取头部元素，不删除该元素

Deque接口提供的实现类为ArrayDeque，和ArrayList一样，底层采用一个动态的、可重新分配的Object[]数组来存储集合元素。

```java
    // 1、当成栈使用
    ArrayDeque stack = new ArrayDeque();
    stack.push("stack1");
    stack.push("stack2");
    stack.addFirst("stack3");
    System.out.println(stack);//[stack3, stack2, stack1]
    //获取并删除
    System.out.println(stack.pop());
    System.out.println(stack);
    //获取不删除
    System.out.println(stack.peek());
    System.out.println(stack);

    // 2、当成队列使用
    ArrayDeque queue =new ArrayDeque();
    queue.offer("queue1");
    queue.offerLast("queue2");
    queue.addLast("queue3");
    System.out.println(queue);//[queue1, queue2, queue3]
    //获取并删除
    System.out.println(queue.poll());
    System.out.println(queue);
    //获取不删除
    System.out.println(queue.peek());
    System.out.println(queue);
```

> Map集合

* Map接口不继承Collection，提供key到value的映射，允许值对象为null，且没有个数限制。
* Map里的Key集，和Set集合关系密切，元素的存储形式很像。Map里的Value集，和List集合也类似。
* HashMap和Hashtable都是Map接口的典型实现，Hashtable是古老的，线程安全的。HashMap性能高，但线程不安全。类似于ArrayList和Vector的关系。HashMap允许使用null作为key或value。
* 用作HashMap的key的对象必须实现hashCode()和equal()方法。判断两个key是否相等需要两个方法同时满足。
* LinkedHashMap，是HashMap的子类。还是按hashCode值来决定存储位置，但使用双向链表维护元素的次序，将会按元素添加顺序来访问集合里的元素。

```java
	Map map=new HashMap();
	map.put("key1",100);
	map.put("key2",50);
	map.put("key3",150);
	System.out.println(map);
	System.out.println(map.containsKey("key1"));
	
	for (Object key:map.keySet()){
	    System.out.println(key+"-->"+map.get(key));
	}
	map.forEach((key,value)-> System.out.println(key+"--->"+value));
	
	map.remove("key1");
	System.out.println(map);
	
	map.replace("key2",66);
	System.out.println(map);
	    
	map.merge("key3",20,(oldVal,param)->(Integer)oldVal+(Integer)param);
	System.out.println(map);
	
	map.computeIfAbsent("key4",(key)->((String)key).length());
	System.out.println(map);
	
	map.computeIfPresent("key4",(key,value)->(Integer)value*(Integer)value);
	System.out.println(map);
		
	Map map1=new HashMap();
	map1.put("语文",100);
	map1.put("英语",50);
	map1.put("数学",150);
	System.out.println(map1);//{数学=150, 语文=100, 英语=50}
	
	Map map2=new LinkedHashMap();
	map2.put("语文",100);
	map2.put("英语",50);
	map2.put("数学",150);
	System.out.println(map2);//{语文=100, 英语=50, 数学=150}
```

其他实现类：

* Properties类时HashMap的子类，增加load、store、setProperty、getProperty等操作。
* SortedMap是Map接口的子接口，SortedMap接口有TreeMap实现类。和TreeSet一样，是红黑树数据结构，需要根据key对节点进行排序。TreeMap的所有key必须实现Comparable接口。
* WeakHashMap实现类，WeakHashMap的key只保留了对实际对象的弱引用，可能会被垃圾回收。而HashMap的key保留了对实际对象的强引用，HashMap对象不被销毁则key所引用的对象不会被垃圾回收。
* IdentityHashMap实现类，判断key是否相等，采用严格相等（key1==key2），而HashMap则使用equals和hashCode方法来判断。
* EnumMap实现类，要求所有的key必须是单个枚举类的枚举值，内部以数组形式保存。创建时必须制定一个枚举类。

> Collections工具类

Collections工具类提供了大量方法对集合元素进行排序、查询和修改操作，还提供将集合对象设置为不可变、同步控制等方法。

1、排序、查找、替换操作

```java
	ArrayList nums= new ArrayList();
	nums.add(2);
	nums.add(-5);
	nums.add(3);
	nums.add(0);
	System.out.println(nums);
	Collections.replaceAll(nums,0,1);
	System.out.println(nums);
	System.out.println(Collections.max(nums));
	System.out.println(Collections.min(nums));
	System.out.println(Collections.frequency(nums,-5));
	
	Collections.reverse(nums);
	System.out.println(nums);
	
	Collections.shuffle(nums);
	System.out.println(nums);
	
	Collections.sort(nums);
	System.out.println(nums);
	//排序后才能使用二分法查询
	System.out.println(Collections.binarySearch(nums,3));
```

2、同步控制，解决多线程并发访问集合时的线程安全问题

```java
	List list= Collections.synchronizedList(new ArrayList());
	Map map= Collections.synchronizedMap(new HashMap());
	Set set= Collections.synchronizedSet(new HashSet());
```

3、不可变集

```java
    List unmodifiedList = Collections.emptyList();
    Set unmodifiedSet=Collections.singleton("set1");
    Map modifiedMap =new HashMap();
    map.put("key1",80);
    Map unmodifiedMap =Collections.unmodifiableMap(modifiedMap);
```

## 五、泛型（Generic）

> 泛型使用

* Java集合有个缺点，把一个对象放进集合，集合会忘记对象的数据类型。当再次取出该对象时，该对象的编译类型变成Object类型（运行时类型没变）。
* 所谓泛型，就是允许在定义类、接口、方法时使用泛型形参（区别于数据形参），在声明变量、创建对象、调用方法时动态地指定。泛型形参可当成类型使用。
* Java7开始，允许在构造器后不需要带完整的泛型信息，只需要一对尖括号（<>），称为菱形语法。Java9开始允许在创建匿名内部类时使用菱形语法。
* 泛型指的是程序员定义安全的类型。Java提供了对Object的引用“任意化”操作，进行向上转型以及向下转型。  
* 不管泛型形参传入哪一种类型实参，对Java来讲都是同一个类来处理，因此在静态方法、静态初始化块、静态变量的声明和初始化中，不允许使用泛型形参。
* 数组和泛型不同，假设Foo是Bar的子类型，那么Foo[]依然是Bar[]的子类型，但G<Foo>不是G<Bar>的子类型，Foo[]自动向上转型为Bar[]，称为型变。因此数组支持型变，集合不支持型变。
* 泛型只在编译阶段有效。泛型的设计原则，只要代码在编译时没有出现警告，就不会碰到运行时ClassCastException异常。

1、常用的被泛型化的集合类：

| 集合类 | 泛型定义 |
| -------  |:---: 	|
|	ArrayList	|	ArrayList&lt;E&gt;|
|	HashMap   |	HashMap&lt;K,V&gt; |
|	HashSet 	|	HashSet&lt;E&gt;	  |
|	Vector 	|  Vector&lt;E&gt;	  |

```java
    List<String> books= new ArrayList<>();
    books.add("book1");
    books.add("book2");
    books.forEach(ele-> System.out.println(ele));

    Map<String,List<String>> schoolInfo = new HashMap<>();

    List<String> schools= new ArrayList<>();
    schools.add("1");
    schools.add("2");
    schoolInfo.put("key",schools);
    schoolInfo.forEach((key,value)-> System.out.println(key+"-->"+value));
```

2、可以为任何类、接口增加泛型声明，OverClass<T>，T代表一个类型的名称。MutiOverClass<T1,T2>为多个类型。

``` bash
public class Fanxing<T> {
    private  T over;

    //构造器依然是Fanxing，而不是Fanxing<T>。调用构造器时却可以使用Fanxing<T>的形式。
    public Fanxing() {}

    public T getOver() {
        return over;
    }

    public void setOver(T over) {
        this.over = over;
    }

    public static void main(String[] args){
        Fanxing<Boolean> over1=new Fanxing<Boolean>();
        Fanxing<Float> over2=new Fanxing<Float>();
        over1.setOver(true);
        Boolean b=over1.getOver();

        over2.setOver(1.0f);
        Float f=over2.getOver();
    }
}

//从泛型类派生子类，不能写成public class FanxingSub extends Fanxing<T>
public class FanxingSub extends Fanxing<String>{
    //该返回值不能是T，需和子类继承时指定的泛型形参匹配
    public String getOver(){
        return "子类："+super.getOver();
    }

    public static void main(String[] args) {
        FanxingSub fanxingSub =new FanxingSub();
        fanxingSub.setOver("herr");
        System.out.println(fanxingSub.getOver());
    }
}
```

> 类型通配符

``` java
List<?>// 相当于List<? extends Object>
```

1、为什么要用通配符和边界？

使用泛型的过程中，经常出现一种很别扭的情况。比如我们有Fruit类，和它的派生类Apple类。

```java
class Fruit {}
class Apple extends Fruit {}
```
然后有一个最简单的容器：Plate类。盘子里可以放一个泛型的“东西”。我们可以对这个东西做最简单的“放”和“取”的动作。

```java
class Plate<T>{
    private T item;
    public Plate(T t){item=t;}
    public void set(T t){item=t;}
    public T get(){return item;}
}
```
现在我定义一个“水果盘子”，逻辑上水果盘子当然可以装苹果。

Plate<Fruit> p=new Plate<Apple>(new Apple());
但实际上Java编译器不允许这个操作。会报错，“装苹果的盘子”无法转换成“装水果的盘子”。

```java
error: incompatible types: Plate<Apple> cannot be converted to Plate<Fruit>
```
实际上，编译器脑袋里认定的逻辑是这样的：

* 苹果 IS-A 水果
* 装苹果的盘子 NOT IS-A 装水果的盘子

所以，就算容器里装的东西之间有继承关系，但容器之间是没有继承关系的。所以我们不可以把Plate的引用传递给Plate。
为了让泛型用起来更舒服，Sun的大脑袋们就想出了<? extends T>和<? super T>的办法，来让”水果盘子“和”苹果盘子“之间发生关系。

2、上界通配符（Upper Bounds Wildcards），用于表示实例化时可以确定父类型的未知类型

```java
Plate<？ extends Fruit>
// <? extends 父类型> //类型通配符的上限
```

翻译成人话就是：一个能放水果以及一切是水果派生类的盘子。再直白点就是：啥水果都能放的盘子。指定通配符上限是为了支持协变，比如Fruit是Apple的父类，但Plate<Fruit>不是Plate<Apple>的父类，但Plate<? extends Fruit>可以相当于Plate<Apple>的父类，所以可以将Plate<Apple>赋值给Plate<? extends Fruit>类型的变量，直接的好处就是，我们可以用“苹果盘子”给“水果盘子”赋值了。

```
Plate<? extends Fruit> p=new Plate<Apple>(new Apple());
```

![](Java基础/generic_extends.png)

3、下界通配符（Lower Bounds Wildcards），用于表示实例化时可以确定子类型的未知类型

```java
Plate<？ super Fruit>
// <? super 子类型> //类型通配符的下限
```

表达的就是相反的概念：一个能放水果以及一切是水果基类的盘子。Plate<？ super Fruit>是Plate<Fruit>的基类，但不是Plate<Apple>的基类。

4、上下界通配符的副作用

边界让Java不同泛型之间的转换更容易了。但不要忘记，这样的转换也有一定的副作用。那就是容器的部分功能可能失效。

还是以刚才的Plate为例。我们可以对盘子做两件事，往盘子里set()新东西，以及从盘子里get()东西。

上界<? extends T>不能往里存，只能往外取。

<? extends Fruit>会使往盘子里放东西的set()方法失效。但取东西get()方法还有效。比如下面例子里两个set()方法，插入Apple和Fruit都报错。

```java
Plate<? extends Fruit> p=new Plate<Apple>(new Apple());
    
//不能存入任何元素
p.set(new Fruit());    //Error
p.set(new Apple());    //Error

//读取出来的东西只能存放在Fruit或它的基类里。
Fruit newFruit1=p.get();
Object newFruit2=p.get();
Apple newFruit3=p.get();    //Error
```

下界<? super T>不影响往里存，但往外取只能放在Object对象里

使用下界<? super Fruit>会使从盘子里取东西的get( )方法部分失效，只能存放到Object对象里。set( )方法正常。

```java
Plate<? super Fruit> p=new Plate<Fruit>(new Fruit());

//存入元素正常
p.set(new Fruit());
p.set(new Apple());

//读取出来的东西只能存放在Object类里。
Apple newFruit3=p.get();    //Error
Fruit newFruit1=p.get();    //Error
Object newFruit2=p.get();
```


![](Java基础/generic_super.png)

5、总结

类型通配符上限，为了支持协变，包括类型通配符，实例出来的对象，只能删除和读取（元素总是上限的类型），不能添加元素。
类型通配符下限，为了支持逆变，只能添加元素，不能读取元素。

PECS（Producer Extends Consumer Super）原则：

* 频繁往外读取内容的，适合用上界Extends。
* 经常往里插入的，适合用下界Super。

> 泛型方法

* 泛型方法定义了一个T泛型形参，这个T类型就可以在该方法内当成普通类型使用。
* 泛型方法只能在该方法里使用，而接口、类声明中定义的泛型则可以在整个接口、类中使用。
* 大多数时候都可以使用泛型方法来代替类型通配符。

```
public class GenericMethodTest {

    static void fromArrayToCollection1(Object[] a, Collection<Object> c){
        for (Object o :a){
            c.add(o);
        }
    }

    //定义泛型方法
    static <T> void fromArrayToCollection(T[] a, Collection<T> c){
        for (T o :a){
            c.add(o);
        }
    }

    public static void main(String[] args) {
        Object[] oa =new Object[100];
        Collection<Object> co =new ArrayList<>();
        fromArrayToCollection(oa,co);


        String[] sa =new String[100];
        Collection<Object> cs =new ArrayList<>();
        fromArrayToCollection(sa,cs);

        fromArrayToCollection(sa,co);

        System.out.println(co);
    }
}
```

```java
public interface Collection<E>{
	boolean containsAll(Collection<?> c);
	boolean addAll(Collection<? extends E> c);
	...
}

public interface Collection<E>{
	<T> boolean containsAll(Collection<T> c);
	<T extends E> boolean addAll(Collection<T> c);
	...
}
```

## 六、异常处理
1、使用说明

* try catch finally块，可使用多个catch来区分异常，名为Exception类的catch块要放到最后（先处理小异常，再处理大异常）
* 一个方法被覆盖时，覆盖的方法必须抛出相同的异常或者异常的子类/子集。 
* Java7以后，每个catch块可捕获多种类型的异常，使用竖线隔开即可。
* 所有的异常对象，都包含如下几个方法：getMessage 获取异常的详细描述字符串、printStackTrace 将异常的跟踪栈信息输出、getStackTrace 获取异常的跟踪栈信息。 
* 使用finally回收资源，如数据库连接、网络连接和磁盘文件等物理资源。Java7以后可以使用try后紧跟的圆括号()来声明、初始化资源，并在程序结束后显式关闭资源。
* 异常链，捕获一个异常，把原始异常信息保存下，然后接着抛出另一个异常，是一种典型的链式处理（23种设计模式之一：责任链模式），可以避免向上暴露太多的实现细节。
* 不要过度使用异常，异常只应该用于处理非正常的情况，不能代替流程控制。不要使用过于庞大的try块，不要忽略捕获到的异常。

2、自定义异常

* 创建自定义异常类，extends Exception。如果需要定义Runtime异常，需要extends RuntimeException。
* 通过throw关键字定义方法，抛出异常(区别于声明抛出的throws关键字)
* 调用时使用try catch语句捕获并处理  

3、异常类为Throwable类，包含Exception和Error类。

Error类描述Java运行系统内部错误和资源耗尽错误，一般和虚拟机相关，较为严重，无法恢复或不可捕获，将导致应用程序终端。

Exception类为非致命性类，可捕捉处理。Exception又分为RuntimeException（Runtime异常）和非RunTimeException（Checked异常）。常见的RuntimeException有：NullPointerException、ArrayIndexOutOfBoundsException、IllegalArgumentException等。

Checked异常要求程序员必须注意该异常，要么显式声明抛出(throws)，要么显式捕获并处理它(try catch)。可增强程序的健壮性，但降低了生产率和代码执行效率。

RuntimeException可以完全不用理会，比抛出Checked异常的灵活性更好。

## 七、数据库操作
> JDBC（Java DataBase Connectivity）

用于执行SQL语句的Java API，是连接数据库和程序的纽带。JDBC用于与数据库建立连接，向数据库发送SQL语句，处理从数据库返回的结果。JDBC不能直接访问数据库，必须依赖数据库厂商提供的JDBC驱动程序，有以下分类：

* JDBC-ODBC桥，依靠ODBC驱动器和数据库通信。需要将ODBC二进制代码加载到客户端。目前较为过时。  
* API部分使用Java编写的驱动程序，将客户机API上的JDBC调用转换为Oracle、DB2等DBMS的调用。  
* JDBC网络驱动，将JDBC转换为与DBMS无关的网络协议，需要安装中间件。  
* 本地协议驱动，纯Java驱动程序，将JDBC调用直接转换为DBMS所使用的网络协议，允许客户机上直接调用DBMS服务器。  

> 常用类和接口 

Connection接口，代表与数据库的连接。Statement接口，用于在建立连接的基础上向数据库发送SQL语句，包含PreparedStatement和CallableStatement，用来执行动态SQL语句和存储过程的调用。DriverManager类，用于管理数据库中的所有驱动程序。ResultSet接口，用于暂时存放SQL结果集。

连接数据库，需要先加载数据库驱动类。

``` java
Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/test","root","123");
Statement sql=con.createStatement();
ResultSet res=sql.executeQuery("select * from tb_tmp");

Statement sql=con.preparedStatement("select * from tb_tmp where id =?");
sql.setInt(1,2);
```
## 八、注解

注解是一个接口，用来为程序元素（类、方法、成员变量）设置元数据（MetaData）。程序可以通过反射来获取元素的Annotation对象，然后通过该对象提取注解里的元数据。

> 常用注解

1、@Override，限定重写父类方法。只能修饰方法，如子类某个被修饰的方法没有重写，会编译报错。

2、@Deprecated，类、方法过时，给出编译警告。Java9增加两个属性，forRemoval 将来是否会删除，since，从哪个版本过时。

3、@SuppressWarnings，抑制编译器警告。

4、@SageVarargs，堆污染警告

5、@FunctionalInterface，函数式接口

> JDK的元注解

元注解只能修饰注解定义。

1、@Retention，指定被修饰的注解可以保留多长时间。包含一个RetentionPolicy类型的value成员变量。

* RetentionPolicy.CLASS，默认值，编译器把注解记录在class文件中，且运行时JVM不可获取注解信息。
* RetentionPolicy.RUNTIME，编译器把注解记录在class文件中，且运行时JVM可获取注解信息，程序可以通过反射获取该注解信息。
* RetentionPolicy.SOURCE，只保留在源码，编译器直接丢弃这种注解。

2、@Target，指定被修饰的注解能用于修饰哪些程序单元。包含一个名为value的成员变量。

* ElementType.ANNOTATION_TYPE，只能修饰注解
* ElementType.CONSTRUCTOR，只能修饰构造器
* ElementType.FIELD，只能修饰成员变量
* ElementType.LOCAL_VARIABLE，只能修饰局部变量
* ElementType.METHOD，只能修饰方法定义
* ElementType.PACKAGE，只能修饰包定义
* ElementType.PARAMETER，只能修饰参数
* ElementType.TYPE，只能修饰类、接口（注解类型）、枚举定义

java8新增TYPE_PARAMETER和TYPE_USE两个枚举值，类型注解，可用于修饰在任何地方出现的类型。

3、@Document，用于指定该朱解决将被javadoc工具提取成文档。

4、@Inherited，指定被它修饰的注解将具有继承性。

> 自定义注解

* 使用@Interface定义注解，可在注解里定义成员变量。
* 根据是否包含成员变量，分为标记注解和元数据注解。
* 在程序中仅使用注解是不会起到任何作用的，需要使用注解处理器来处理注解。APT（Annotation Processing Tool）是一种注解处理器。每个注解处理器都需要实现javax.annotation.processing包下的Processor接口。可使用javac -processor命令来选择注解处理器并编译。

1、创建注解

```java
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface MyTag {

    String name() default "name";
    int age() default 0;
}
```

2、使用注解

```java
public class AnnotationTest {
    public static void main(String[] args) throws ClassNotFoundException,NoSuchMethodException {
        Annotation[] aArray =Class.forName("com.herr.annotation.AnnotationTest").getMethod("info").getAnnotations();

        for (Annotation tag: aArray){
            System.out.println(tag);
            if (tag instanceof MyTag){
                System.out.println("tag.name()："+((MyTag) tag).name());
                System.out.println("tag.age()："+((MyTag) tag).age());
            }
        }

        for (Method m :Class.forName("com.herr.annotation.AnnotationTest").getMethods()){
            if (m.isAnnotationPresent(MyTag.class)){
                System.out.println("annotation method："+m);
            }
        }

    }
    @MyTag(name = "herr",age = 32)
    public void info(){
        System.out.println("1");
    }
}
```


## 九、I/O（输入/输出）

* 流，是一组有序的数据序列，按照流的流向分为输入流和输出流，一边是文件、网络、压缩包或其他数据源，另一边是目的地或源。
* 所有输入流都是抽象类InputStream（字节输入流，8位的字节）或抽象类Reader（字符输入流，16位的字符）。所有输出流都是抽象类OutputStream（字节输出流）或抽象类Writer（字符输出流）。
* 按照流的角色可分为节点流和处理流。
* Java流的类都在java.io包中。
* Java以 UTF-16作为内存的字符存储格式Java字符，是Unicode编码，双字节。
* 通常来说，字节流的功能比字符流强大，字节流可以处理计算机里所有的数据（都是二进制）。但如果使用字节流处理文本，需要把字节转换成字符，增加了变成的复杂度。因此字符文本的处理应该考虑使用字符流Reader或Writer，二进制内容的处理应该考虑使用字节流InputStream或OutputStream。

以下为输入输出流体系：

| 分类  | 字节输入流 | 字节输出流 | 字符输入流 | 字符输出流 |
| ----- |-----|-----|-----|-----|
|抽象基类（抽象类）|	InputStream|	OutputStream|	Reader|Writer
|访问文件（节点流）|FileInputStream|FileOutputStream|FileReader|FileWriter
|访问数组（节点流）|	BiteArrayInputStream|	BiteArrayOutputStream	|CharArrayReader	|CharArrayWriter
|访问管道（节点流）|PipedInputStream|	PipedOutputStream	|PipedReader	|PipedWriter
|访问字符串（节点流）	|| 	 |	StringReader|	StringWriter
|缓冲流	|BufferedInputStream	|BufferedOutputStream	|BufferedReader	|BufferedWriter
|转换流	 	||| 	InputStreamReader	|OutputStreamWriter
|对象流	|||ObjectInputStream	|ObjectOutputStream
|抽象基类（抽象类）	|FilterInputStream|	FilterOutputStream	|FilterReader	|FilterWriter
|打印流	 ||	PrintStream	|| 	PrintWriter
|推回输入流|	PushbackInputStream	 ||	PushbackReader	 
|特殊流|	DataInputStream|	DataOutputStream|	 	 

1、字节流

InputStream包含read()读取下一个字节、read(byte[] b)读取一定长度的字节，mark(int readlimit)允许当前位置作标记，reset()返回标记处，skip()跳过输入流上的n个字节，close()方法关闭输入流并释放系统资源。

OutputStream包含write(int b)讲指定的字节写入输出流，flush()彻底完成输出并清空缓存区，close()方法关闭输出流。

2、文件流

File类，使用File(String pathname)来创建文件，可获取文件的信息，getName,canWrite,exits,length,isHidden,lastModified等。

文件输入/输出流：FileInputStream/FileOutputStream。最好使用FileReader和FileWriter类，因为汉字也占两个字节，如果使用字节流可能会出现乱码。

3、缓存流

带缓存的输入/输出流：缓存是I/O的一种性能优化。缓存流为I/O流增加了内存缓存区，使得在流上执行skip、mark、reset等操作。BufferedInputStream/BufferedOutputStream和BufferedWriter/BufferedReader。

文件--> InputStream --> BufferedInputStream --> 目的地
BufferedInputStream比InputStream多一个flush()方法来将缓存区的数据强制输出完。
BufferedInputStream构造方法：  
BufferedInputStream(InputStream in);//默认32字节   
BufferedInputStream(InputStream in,int size);

BufferedReader增加readLine()。

``` bash
File file=new File("word.txt");
try {
    FileWriter fw= new FileWriter(file);
    BufferedWriter bufw=new BufferedWriter(fw);
}

try {
    FileReader fr= new FileReader(file);
    BufferedReader bufr=new BufferedReader(fr);
}
```

4、数据流

数据输入/输出流：允许应用程序以与机器无关的方式读取数据。DataInputStream和DataOutputStream。  

5、zip压缩流

zip压缩输入/输出流：允许应用程序使用zip文件压缩节省存储空间。ZipInputStream和ZipOutputStream。

6、处理流

使用处理流时的典型思路是，不直接使用节点流，可使用处理流来包装节点流，程序通过处理流来执行输出/输入功能。

例如使用PrintStream来包装OutputStream。

7、转换流

用于将字节流转换成字符流。InputStreamReader将字节输入流转换成字符输入流。OutputStreamWriter将字节输出流转换成字符输出流。

```
    InputStreamReader reader =new InputStreamReader(System.in);
    BufferedReader bufferedReader=new BufferedReader(reader);
```

8、推回输入流

都带有一个推回缓冲区，使用unread方法将内容推回到推回缓冲区里，从而允许重复读取。

> 其他

1、重定向标准输入/输出，Java使用System.in和System.out，分别代表键盘和显示器。提供setErr、setIn、setOut方法来重定向

```java
	PrintStream ps = new PrintStream(new FileOutputStream("out.txt"));
	System.setOut(ps);
	System.out.println("herr");
```

2、JVM读写其他进程的数据，通过Process类提供的三个方法，让程序和子进程进行通信。

```java
	Process p =Runtime.getRuntime().exec("javac");
	try (
	    BufferedReader br =new BufferedReader(new InputStreamReader(p.getInputStream()));
	)
```

3、对象序列化

* 对象序列化是将对象保存到磁盘中，或者允许在网络中直接传输。将内存中的Java对象转换成平台无关的二进制流，并且将二进制流保存或者通过网络传输。
* 如需要让某个对象支持序列化机制，它的类需要是可序列化的，必须实现两个接口之一。Serializable或Externalizable。
* 所有在网络上传输的对象都应该是序列化的，比如RMI（远程方法调用）的参数和返回值等。所有需要保存到磁盘里的对象的类也必须序列化。
* 反序列化时需要验证serialVersionUID。系统编译时如果没有定义serialVersionUID，class自动生成一个serialVersionUID作为序列化版本。需要手动定义，不然随着编译版本变化，会导致反序列化失败。
* 实例变量前添加使用transient关键字修饰，可以指定Java序列化时无须理会该实例变量。
* 可重写对象的Serializable接口的writeObject和readObject方法实现自定义序列化。也可重写对象的Externalizable接口的readExternal和writeExternal方法来实现另一个自定义序列化机制。

```java
public class Person implements java.io.Serializable{
    //序列化ID
    private static final long serialVersionUID = -5809782578272943999L;
    
    private String name;
    private transient int age;//使用transient，不会序列化
	
	... getter and setter
}
```

```java
//序列化
public class WriteObject {
    public static void main(String[] args) {
        try(
            ObjectOutputStream oos =new ObjectOutputStream(new FileOutputStream("object.txt"));
        )
        {
            Person person = new Person("iherr1",500);
            oos.writeObject(person);
        }catch (IOException ex){
            ex.printStackTrace();
        }
    }
}

//反序列化
public class ReadObject {
    public static void main(String[] args) {
        try(
            ObjectInputStream ois =new ObjectInputStream(new FileInputStream("object.txt"));
        )
        {
            Person person = (Person)ois.readObject();
            System.out.println("name:"+person.getName()+"\nage:"+person.getAge()); //age会因为未序列化，返回0
        }catch (Exception ex){
            ex.printStackTrace();
        }
    }
}
```

4、NIO

* NIO是 New IO，新增了许多用于处理输入/输出的类，放到java.nio包下。
* Channel（通道）和Buffer（缓冲）是NIO的两个核心对象，Channel是对传统输入/输出的模拟，Buffer可以理解成一个容器（数组），发送到Channel的数据必须先放到Buffer中。
* NIO采用内存映射的方式来处理输入/输出，效率很高。Channel可以直接将指定文件的部分或全部直接映射成Buffer。
* JDK提供Charset来处理字符集，来进行二进制和字符的编码和解码。
* NIO支持文件锁来阻止多个进程并发修改同一个文件。
* Java7的NIO.2提供了全面的文件IO和基于异步Channel的IO。有Path、Paths、Files核心API。

## 十、网络通信
1、套接字，用于将应用程序和端口连接起来，相当于插座，Socket类。

2、InetAddress类，获取ip地址相关信息。

``` java
InetAddress ip;
try{
    ip=InetAddress.getLocalHost();
    out.println(ip.getHostName() + ip.getHostAddress());
}catch (Exception e){
    e.printStackTrace();
}
```

3、ServerSocket类，用于服务器套接字，通过制定端口来等待网络上的请求连接的套接字。和客户端的Socket配合，进行消息传递。

4、UDP基础，传输不可靠，无法知道是否送达。使用DatagramSocket类创建数据包套接字，使用DatagramPacket创建和接收数据包。使用DatagramSocket的send()发送数据包，使用DatagramPacket的receive()方法接收UDP包。


## 十一、类的加载机制和反射

> 类的加载、连接和初始化

* 当调用java运行某个java程序时，将会启动JVM进程，同一个JVM的所有线程、变量都处于该进程，共同使用JVM进程的内存区。当Java程序运行结束时，JVM进程结束，该进程在内存中状态将会丢失。
* 当程序使用某个类时，如果该类还未被加载到内存中，会通过加载、连接、初始化三个步骤对类进行初始化。
* 类的加载由类加载器（通常由JVM提供）完成，可预加载，可以从本地class文件、jar包class文件、网络class文件、动态编译源文件并加载等方式。
* 类的连接，会把类的二进制数据合并到JRE中。
* 类的初始化，由虚拟机对类变量进行初始化。
* 当Java程序首次通过以下方式来使用某类或接口时，系统就会初始化该类或接口。（1）创建类的实例 （2）调用类的类方法（3）访问类的类变量或赋值 （4）使用反射方式强制创建类对应的java.lang.Class对象。（5）初始化某各类的子类（6）使用java命令运行某个主类

> 使用反射生成并操作对象

```java
    //通过默认构造器生成对象
    Class<?> clazz= Class.forName("com.herr.io.Person");
    Person p1 = (Person) clazz.getConstructor().newInstance();
    System.out.println(p1);

    //通过特定构造器生成对象
    Constructor ctor =clazz.getConstructor(String.class,int.class);
    Person p2 = (Person) ctor.newInstance("iherr反射",10);
    System.out.println(p2);

    //通过对象的getClass()方法获取Class对象，也可通过类的class属性来获取Class对象
    Object object="11";
    Class clazz1 =object.getClass();
    Class clazz2 =Object.class;

    //可通过Class对象访问对应类的构造方法、成员变量和方法，并可调用方法、设置成员变量。
    Method[] methods=clazz2.getMethods();
    for (Method md:methods){
        System.out.println(md);
    }
```

> 使用反射生成JDK动态代理

* 使用Proxy和InvocationHandler可以创建动态代理，当执行代理对象的方法时都会调用InvocationHandler对象的invoke()方法。
* 动态代理是实现AOP的方式，可以非常灵活的实现解耦。

## 十二、多线程

> 线程和进程

* 进程有独立性、动态性、并发性这3个特征。
* 操作系统支持多进程并发执行，是CPU（单核）快速在进程之间轮换执行造成的错觉。
* 多线程拓展了多进程的概念，使得同一个进程可以同时并发处理多个任务。
* 多线程的优势如下：线程之间共享内存非常容易。创建线程代价小。

> 线程实现方式

创建线程的方式有三种，继承java.lang.Thread与实现java.lang.Runnable、Callable接口。

1、Thread()继承Thread类，并且重写run()方法，通过Thread().start()启动线程。

2、实现Runable接口语法：public class Thread extends Object implements Runnable，一般通过匿名内部类形式对Thread实例进行初始化。

3、Callable接口是Runable接口的加强，Callable接口里定义的方法有返回值，可以声明抛出异常。

一般推荐使用接口方式创建多线程，虽然编程稍稍复杂，但线程类还可以继承其他类，多个线程可以共享同一个target对象。

* 简历Runable对象
* 使用Runable参数构造Thread对象，Thread(Runable target)。
* 调用start()方法启动线程

> 线程生命周期

* 出生状态(New)-->刚创建
* 就绪状态(Ready)-->调用start方法后
* 执行状态(Run)-->得到系统资源
* 阻塞状态(Blocked)，阻塞后可以重新解除进入就绪状态
* 死亡状态(Dead)
* 等待状态-->t.wait()
* 休眠状态-->t.sleep()

![](Java基础/java_thread.jpg)

> 线程操作 
 
1、线程的加入，join()方法，使当前线程暂停，直到调用join()方法的线程执行完毕后再执行。

2、线程的中断：目前已废除stop()方法，可在run方法中使用布尔标记控制无限循环的停止。如线程是因为sleep或wait方法进入就绪状态，则可使用interrupted()方法，会在程序中抛出InterruptedException异常，并在异常处理时结束while循环。

3、线程的礼让：yield，一般不使用。

4、线程优先级：通过setPriority()方法设置。最小是1，最大是10，默认为5。

5、线程安全：多线程导致线程安全问题，来源于两个线程同时存取单一对象的数据导致。

6、线程同步机制：相当于给共享资源上一道锁，java提供同步机制，有效防止资源冲突。使用关键字synchronized

7、同步块：将共享资源的操作放到synchronized定义的区域内，
synchronized(Object){ }

8、同步方法：通过synchronized修饰方法

9、同步锁：由Lock对象充当，是控制多个线程对共享资源进行访问的工具。

10、线程通信：（1）使用synchronized关键字保证同步，可使用隐式的同步监听器，通过wait()、notify()、notifyAll()方法进行线程通信。（2）使用Lock对象保证同步时，使用Condition对象的await()、signal()、signalAll()方法来控制线程通信。（3）使用阻塞队列（BlockingQueue）来控制线程通信，当队列已经满放入元素，或者队列已空取出元素时，线程会被阻塞。

11、可定义线程的线程组，这样可以来操作整个线程组里的所有线程。可使用setUncaughtExceptionHandler为指定的线程实例设置异常处理类。可使用线程池来有效控制系统并发线程的数量，节约启动新线程的成本，提高性能。