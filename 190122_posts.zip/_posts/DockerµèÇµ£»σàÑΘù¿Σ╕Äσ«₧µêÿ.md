---
title: Docker技术入门与实战
date: 2016-10-24 13:48:27
tags: [Docker]
---

## 一、Docker简介
> Docker和集装箱

集装箱，港口运输业最伟大的发明。Docker，聪明的技术人员从传统的运输行业找到了答案。

Docker是一个开源的容器引擎，将应用程序和基础设施层隔离，实现Build，Ship，and Run Any App，Anywhere，即任何应用都可以构建、发布、运行于任何环境。看看Docker的icon就明白了。基本使用Golang进行开发。
![](Docker技术入门与实战/docker_icon.jpeg)

> 下载安装

分为企业版EE和社区版CE，版本采用YY.MM形式控制。使用命令docker version验证安装版本。

* Mac版，去[『Docker官网』](https://www.docker.com)运行docker for mac安装。
* CentOS，要求CentOS 7以上，可使用yum或脚本安装。
* Ubuntu，要求版本和平台，较为复杂，使用APT或脚本安装。
* Windows，Docker for Windows需要64位Win 10 Pro，必须开启Hyper-V。

> Docker优点

Docker使用的基础技术，Linux的命名空间Namespace、控制组Control Group、分层文件系统、网络虚拟化等在Docker之前就存在很多年，但容器一直没有得到关注的原因，在于易用性，docker通过简单的指令或接口来维护容器，降低部署难度，提升维护效率。它提供一种统一的实践方法（维护一个Dockerfile文件或Compose的方式），供开发和运维团队来透明和合作，降低沟通和部署成本。

* 快速上手新技术，不纠结于环境搭建的学习成本。  
* 容器化的代码仓库，所有常用代码都可以以容器化的方式保存，并可以调出随时运行。  
* 面向业务编程，使得软件工程师更加专注于业务需求，快速启用新技能。  
* 使用Docker Hub发布开源项目。  

> 容器化开发模式  

工作流程比较
![](Docker技术入门与实战/docker_workflow.jpg)

开发、测试、运维协同
![](Docker技术入门与实战/docker_flow.jpg)

> 容器与云服务

目前AWS、Google、Azure、Docker官方、腾讯、阿里、华为、UCloud等都推出了公有云的容器服务，来支撑企业级IT架构的云化与容器化、微服务化。

有些甚至还推出了容器云服务（Container as a Service，CaaS）。按需提供容器化环境和应用服务，让开发和运维团队相互协作，构建和部署应用。从而使得容器成为生产主流。主要有网易蜂巢、时速云、Daocloud、数人云等。提供容器调度、服务发现、网络配置、安全配置、负载、数据持久、容错与高可用性等需求。

> 容器与生产环境

Docker还是个IT生产环境和基础设施的新成员，目前容器还存在一些分支和分歧，成立OCI（Open Container Initiative）组织来建立通用容器技术标准。传统数据库或有状态应用、网络吞吐性能高要求的应用还不适合容器化。因此需要考虑：  

* Docker出现不可控风险后的备选方案  
* Docker怎么做资源的限制  
* Docker对容器安全管理是否完善    
* 内部私有仓库、镜像的管理是否解决  

但是，有一句话还得送给大家，容器技术非常热门，未来将成为主流，那么你就应该尽快掌握。

## 二、Docker镜像(Image)

> 获取镜像

``` bash
$ docker pull NAME[:TAG]
```
其中，NAME是镜像仓库的名称，TAG是镜像的标签，例如ubuntu:14.04。如不指定TAG，则默认为latest标签，下载最新版本。

默认使用官方注册服务器registry.hub.docker.com/ubuntu:14.04命令，如需从非官方仓库下载，可指定如下：

``` bash
$ docker pull hub.c.163.com/public/ubuntu:14.04
```

> 查看镜像信息

1、列出本地主机上已有镜像的基本信息，字段包含归属仓库、镜像标签、镜像ID、创建时间和镜像大小

``` bash
$ docker images
```

![](Docker技术入门与实战/docker_images.png)

2、使用tag命令添加标签镜像，可为本地镜像添加新的标签，他们都指向同一个镜像文件，只是有别名而已。

``` bash
$ docker tag nginx:latest mynginx:latest
```

3、使用inspect命令查看详细信息

``` bash
$ docker inspect ubuntu:14.04
```

4、使用history查看镜像历史

``` bash
$ docker history ubuntu:14.04
```

<!--more-->

> 搜寻镜像
  
搜索所有自动创建的star为3+的nginx镜像

``` bash
$ docker search --automated -s 3 nginx
```

> 删除镜像 
 
1、使用标签删除镜像

``` bash
$ docker rmi myubuntu:latest
```

2、使用镜像ID删除镜像

``` bash
$ docker rmi 8f1bd21bd25c
```
如遇到无法删除，有可能为有对应的容器正在运行，可先删除容器

``` bash
$ docker ps -a
$ docker rm a21c0840213e
```

> 创建镜像

1、基于已有镜像的容器创建

``` bash
$ docker commit -m "something" -a "something" a925cb40b3f0 test:0.1
```
会返回创建的镜像id（64位16进制字符，只显示前12位），生成test:0.1的镜像。

2、从本地模板导入docker import

> 存出和载入镜像

存出镜像

```bash
$ docker save -o ubuntu_14.04.tar ubuntu:14.04
```

文件分享给他人后，可以使用命令导入

```bash
$ docker load --input ubuntu_14.04.tar
```

> 构建镜像

使用Dockerfile创建镜像，使用-t指定生成的镜像的标签

```bash
$ docker build -t IMAGE_NAME:TAG_NAME DOCKERFILE_PATH
```

> 上传镜像

默认到Docker Hub官方仓库，需要登录

```bash
$ docker tag test:latest user/test:latest
$ docker push user/test:latest

Please login prior to push
Username:
Password:
Email:
```

### 三、Docker容器（Container）
容器，是镜像的一个运行实例。

> 创建容器 

1、新建容器

```bash
$ docker create -it ubuntu:latest
```

列出容器

```bash
$ docker ps -a
```

2、启动容器  
create命令新建的容器处于停止状态，status=Created，可使用docker start命令启动容器

``` bash
$ docker start af #可以是容器id的前两位
```

3、新建并启动容器

```bash
$ docker run ubuntu /bin/echo 'Hello world'
```

后台运行的标准操作如下：  
（1）检查本地镜像，如不存在去公有仓库下载
（2）利用镜像创建一个容器、启动该容器  
（3）分配一个文件系统给容器，并在只读的镜像层外挂在一层可读写层  
（4）宿主主机配置的网桥接口中桥接一个虚拟接口到容器中  
（5）从网桥的地址池配置一个ip地址给容器  
（6）执行用户指定的应用程序  
（7）执行完毕后容器被自动终止

下面启动一个bash终端，允许用户进行交互：  

``` bash
$ docker run -it ubuntu:14.04 /bin/bash
```

-t让Docker分配一个伪终端并绑定到容器的标准输入上，-i则让容器的标准输入保持打开。当用户使用ctrl+D或者exit命令时会退出容器，容器也会自动处于退出状态了。

4、守护态运行  
可使用-d参数来实现Docker容器以守护态的形式运行。


> 终止容器  

```bash
$ docker stop ce5 #可以是容器id的前几位
$ docker kill ce5 #强行终止容器
```

对于终止状态的容器，可重新启动

```bash
$ docker start ce5 #可以是容器id的前几位
```

也可使用restart命令先终止再重新启动  
```bash
$ docker restart ce5 #可以是容器id的前几位
```

> 进入容器

使用-d参数，容器启动后会进入后台，用户无法看到容器中的信息，也无法进行操作。如需要进入容器操作，可使用官方的attach和exec，以及第三方的nsenter工具。  
1、 使用attach不方便的一点，如多个窗口用attach命令练到同一个容器时，窗口会同步显示。

``` bash
$ docker attach CONTAINER
```

2、exec命令，从1.3.0版本起，对容器才做的推荐方式

``` bash
$ docker exec -it 243c32535da7 /bin/bash
```

> 删除容器

``` bash
$ docker rm 243c32535da7
```

默认情况下，只能删除处于终止或退出状态的容器，不能删除运行状态的容器。如果需要强制删除，可添加-f参数。

> 导入和导出容器

1、导出容器，两种方式

``` bash
$ docker export -o test_for_run.tar ce5
$ docker export e81 >test_for_stop.tar
```

2、导入容器，导出的文件又可以使用docker import命令导入变成镜像。和load命令类似，区别在于容器快照文件将丢失历史记录和元数据信息（仅保存容器当时的快照），而镜像存储文件将保存完整记录。

``` bash
$ docker import ubuntu_14.04.tar - test/ubtuntu:1.0
```

## 四、Docker仓库（Repository）
仓库是集中存放镜像的地方，分公共仓库和私有仓库。还有个混淆的概念是注册服务器（Registry），是存放仓库的具体服务器，一个注册服务器上可以有多个仓库，每个仓库下可以有多个镜像。对于仓库地址private-docker.com/ubuntu来说，private-docker.com是注册服务器地址，ubuntu是仓库名。

> 公共镜像市场

[『官方镜像市场传送门』](https://store.docker.com)
  
1、登录，使用docker login命令  
2、基本操作docker search命令搜索，docker pull命令下载到本地  

3、由于国内你懂的原因，如果官方镜像访问较慢，可以使用加速器。可在preference里的Registry mirrors为使用镜像站点进行加速，推荐[阿里云](https://www.aliyun.com)或[DaoCloud](https://www.daocloud.io)提供的免费容器镜像服务，都需要注册。
 
具体配置方法：
右键点击桌面顶栏的docker图标，选择Preferences，在Daemon标签下的Registry mirrors列表中加入获取的加速器地址。

> 云镜像市场

1、时速云市场Docker镜像市场，地址https://hub.tenxcloud.com。  
拉取命令为：

``` bash
$ docker pull index.tenxcloud.com/tenxcloud/centos
```

2、阿里云同样提供容器镜像服务，如：

``` bash
$ docker pull registry.cn-hangzhou.aliyuncs.com/ghoulich-centos/centos
```

> 搭建本地私有仓库



为节约带宽，保证安全，便于内部镜像的统一管理，可以通过docker搭建本地私有仓库：

``` bash
$ docker run --name registry1 -d -p 5000:5000 -v ~/docker/registry:/tmp/registry registry
```

访问地址http://localhost:5000/v2/_catalog 查看服务器镜像

然后使用docker push上传标记的镜像

``` bash
$ docker push localhost:5000/test
```

## 五、Docker数据管理
容器中的管理数据有两种方式：  
1、数据卷（Data Volumes）：容器内数据直接映射到本地主机环境  
2、数据卷容器（Data Volumes Containers）：使用特定容器维护数据卷。

> 数据卷

1、在容器内创建一个数据卷，使用training/webapp镜像创建一个web容器，并创建一个数据卷挂在到容器的/webapp目录下。（不推荐）
  
``` bash
$ docker run -d -p --name web -v /webapp training/webapp python app.py
```

2、挂在一个主机目录作为数据卷，使用-v标记加载主机的/src/webapp目录到容器的/opt/webapp目录。（推荐）

``` bash
$ docker run -d -p --name web -v /src/webapp:/opt/webapp training/webapp python app.py
```

默认为读写rw，也可以只读ro，容器内就无法对数据进行修改。

``` bash
$ docker run -d -p --name web -v /src/webapp:/opt/webapp:ro training/webapp python app.py
```
3、挂在一个本地主机文件作为数据卷（使用文本编辑该文件，会导致报错，不推荐）

``` bash
$ docker run -rm -it -v ~/.bash_history:~/.bash_history ubuntu /bin/bash
```
> 数据卷容器

``` bash
$ docker run -it -v /dbdata --name dbdata ubuntu
```

在此容器可以查看到/dbdata目录，并可以在其他容器中使用--volumes-from来挂在dbdata容器中的数据卷。

``` bash
$ docker run -it --volumes-from dbdata --name db1 ubuntu
```

利用数据卷可以实现数据卷的备份、恢复和数据迁移。

## 六、端口映射与容器互联
> 允许映射容器内应用的服务器端口到本地宿主主机

从外部访问容器应用，启动容器时，如不指定对应的参数，是无法从外部访问容器内的网络应用和服务器的。可以通过-P或-p参数来指定端口映射。

1、当使用-P时，会随机映射一个49000~49900的端口到内部容器开放的网络端口。
2、映射所有接口地址

``` bash
$ docker run -d -p 5000:5000 training/webapp python app.py
```

3、映射到指定地址的指定端口，例如localhost地址

``` bash
$ docker run -d -p 127.0.0.1:5000:5000 training/webapp python app.py
```

4、映射到指定地址的任意端口，例如localhost的任意端口到容器的5000端口地址

``` bash
$ docker run -d -p 127.0.0.1::5000 training/webapp python app.py
```

5、查看映射端口配置，查看绑定的地址。

``` bash
$ docker port CONTAINER 80
0.0.0.0:80
```

> 互联机制实现多个容器间通过容器名来快速访问

1、自定义容器名，使用--name标记，容器名称唯一。  
2、容器互联，使用--link name:alias参数让容器之间安全地进行交互，避免使用-p标记暴露数据库等服务端口到外部网络。

``` bash
$ docker run -d --name db training/postgres
$ docker run -d -P --name web --link db:db training/webapp python app.py
```

> 变更容器的端口映射和数据卷

一般情况下是不可以改变容器的端口映射的，只有通过run命令指定。如果想要不改变容器内容和配置的情况下更改端口映射只有先停止，然后将容器打包成镜像，然后在运行新的镜像的时候指定新的端口映射。

``` bash
#先停止容器
$ docker stop containerA
#将容器commit成为一个镜像
$ docker commit containerA  newImageB
#运行容器
$ docker run -d -p 8080:8080 -p 8081:8081 -v /home/data/:/home/data/  newImageB
```

## 七、操作系统
常用的Linux发行版主要包括Debian/Ubuntu系列和CentOS/Fedora系列，前者以自带软件包版本较新而出名，后者宣称运行更稳定。

> BusyBox

BusyBox 称为 Linux 工具里的瑞士军刀。简单的说BusyBox就好像是个大工具箱，它集成压缩了 Linux 的许多工具和命令，也包含了 Android 系统的自带的shell。

``` bash
$ docker run -it busybox
```
> Alpine

轻型Linux发型版，可对比官方镜像大小的比较。

| REPOSITORY | TAG | IAMGE ID | VIRTUAL SIZE |
| -------  |:---: 	|:---:		|:---:	|
|	alpine	|	latest	|	** 	|  4.799MB 	| 
|	debian |	latest |	**  |  84.98MB 	|
|	ubuntu |	latest	|	**  |  188.3MB 	|
|	centos	|  latest	|	** 	|  210MB 	|

> CentOS

目前linux有两个派别，Debian/Ubuntu和CentOS/Fedora。下面以centos为例，并为之添加SSH服务（为安全考虑，官方制作的镜像都没有安装SSH）。

1、启动centos并提权

``` bash
$ docker run --privileged -d --name centos7 centos:7.3.1611 /sbin/init
```
以下为直接启动bash

``` bash
$ docker run -it centos:7.3.1611 bash
```

2、连接bash

``` bash
$ docker exec -it centos7 /bin/bash
```

3、安装ssh

``` bash
$ yum install openssh-server
```

4、启动sshd

``` bash
$ systemctl start sshd
```
5、检查sshd

``` bash
$ ps -e | grep sshd
```
6、安装net-tools，并查看端口

``` bash
$ yum install net-tools
$ netstat -an | grep 22
```

7、如果需要更改密码

``` bash
$ yum install passwd
$ passwd
```

8、保存安装了sshd的centos镜像

``` bash
$ docker commit 65d sshd:centos
```

9、用新镜像创建容器

``` bash
$ docker run --privileged -d -p 10022:22 --name centos7ssh sshd:centos /sbin/init
```

10、使用10022端口连接ssh

## 八、Dockerfile使用实例

我们以在Debian:stretch-slim的基础镜像上安装nginx环境为例，查看Dockerfile。

```bash
#FROM指定镜像的基础信息，在第一行
FROM debian:stretch-slim
#通过LABEL指定镜像的元数据标签信息，包括维护者信息
LABEL maintainer="NGINX Docker Maintainers <docker-maint@nginx.com>"

#通过ENV指定环境变量
ENV NGINX_VERSION 1.13.10-1~stretch
ENV NJS_VERSION   1.13.10.0.1.15-1~stretch

#通过RUN运行指定命令，在shell终端运行，即/bin/sh -c;当命令行较长时使用\换行。每运行一条RUN指令，镜像就添加新的一层，并提交。
RUN set -x \
	&& apt-get update \
	&& apt-get install --no-install-recommends --no-install-suggests -y gnupg1 apt-transport-https ca-certificates \
	&& \
	NGINX_GPGKEY=573BFD6B3D8FBC641079A6ABABF5BD827BD9BF62; \
	found=''; \
	for server in \
		ha.pool.sks-keyservers.net \
		hkp://keyserver.ubuntu.com:80 \
		hkp://p80.pool.sks-keyservers.net:80 \
		pgp.mit.edu \
	; do \
		echo "Fetching GPG key $NGINX_GPGKEY from $server"; \
		apt-key adv --keyserver "$server" --keyserver-options timeout=10 --recv-keys "$NGINX_GPGKEY" && found=yes && break; \
	done; \
	test -z "$found" && echo >&2 "error: failed to fetch GPG key $NGINX_GPGKEY" && exit 1; \
	apt-get remove --purge --auto-remove -y gnupg1 && rm -rf /var/lib/apt/lists/* \
	&& dpkgArch="$(dpkg --print-architecture)" \
	&& nginxPackages=" \
		nginx=${NGINX_VERSION} \
		nginx-module-xslt=${NGINX_VERSION} \
		nginx-module-geoip=${NGINX_VERSION} \
		nginx-module-image-filter=${NGINX_VERSION} \
		nginx-module-njs=${NJS_VERSION} \
	" 
	#未完，详细可参考[官方文件github链接](https://github.com/nginxinc/docker-nginx)

# 添加access.log和error.log的软链接
RUN ln -sf /dev/stdout /var/log/nginx/access.log \
	&& ln -sf /dev/stderr /var/log/nginx/error.log

#使用EXPOSE声明镜像内服务监听的端口
EXPOSE 80

#使用STOPSIGNAL标识容器退出的信号值
STOPSIGNAL SIGTERM

#使用CMD指定启动容器时默认执行的命令，格式为：CMD ["excutable","param1", "param2"]，使用exec执行。最后指定，且只能有一条CMD。
CMD ["nginx", "-g", "daemon off;"]
```

Dockerfile常用指令

| 指令  | 说明 |
| :-----: |-----|
|ADD|	复制文件|
|ARG|	设置构建时的参数|
|CMD|	容器启动时执行的命令|
|COPY|	与ADD类似，但不支持URL和压缩包|
|ENTRYPOINT|	与CMD类似，可多次设置，但最后一次有效|
|ENV|	设置运行时的环境变量|
|EXPOSE|	声明暴露的端口|
|FROM|	指定基础镜像|
|LABEL|为镜像添加元数据|
|MAINTAINER|指定维护者的信息|
|RUN|执行命令|
|VOLUME|指定挂载点，使目录具有持久化存储的功能|

## 九、常见服务搭建
### 1、Web服务和应用

> apache

使用自定义方式进行创建，和。

创建Dockerfile文件

```bash
FROM httpd:2.4
COPY ./html /usr/local/apache2/htdocs/
```
创建html/index.html文件

```bash
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<p>hello,herr</p>
</body>
</html>
```
构建自定义镜像，并启动。

```bash
$ docker build -t apache2-image .
$ docker run -d --name apache1 -p 8060:80 apache2-image
```

> nginx

创建，做html和conf的映射，该latest镜像默认使用debian，可指定其他版本。

```bash
$ docker run --name nginx1 -d -p 8070:80 -v ~/docker/nginx/html:/usr/share/nginx/html -v ~/docker/nginx/conf:/etc/nginx/conf.d nginx

$ docker exec -it CONTAINERID /bin/bash
```

> tomcat

创建2个tomcat容器，分别对应8081和8082，并且tomcat2能访问tomcat1容器，可用于一些分布式调用。

```bash
$ docker run --name tomcat1 -d -p 8081:8080 -p 20880:20880 -v ~/docker/tomcat/webapps:/usr/local/tomcat/webapps -v ~/docker/tomcat/conf:/usr/local/tomcat/conf tomcat:8.5

$ docker run --name tomcat2 -d -p 8082:8080 --link tomcat1:tomcat1 -v /Users/iherr/docker/tomcat2/webapps:/usr/local/tomcat/webapps -v /Users/iherr/docker/tomcat2/conf:/usr/local/tomcat/conf tomcat:8.5
```

> openresty

```bash
$ docker run -d --name openresty1 -p 8090:8090 -v ~/docker/openresty/conf/nginx.conf:/usr/local/openresty/nginx/conf/nginx.conf -v /~/docker/openresty/logs:/usr/local/openresty/nginx/logs openresty/openresty:alpine
```

> jetty

```bash
$ docker run -d --name jetty1 -p 8100:80 jetty
```

> LAMP

```bash
$ docker run --name lnmp1 -p 80:80 -t -i linode/lamp /bin/bash

$ docker run -d --name lnmp2 -p 80:80 -p 3306:3306 tutum/lamp
```

> Jenkins

```bash
$ docker run -d --name jenkins1 -p 8110:8080 -p 50000:50000 jenkins
```

> Gitlab

``` bash
$ docker pull gitlab/gitlab-ce
```

> zookeeper和dubbo-admin

```bash 
#--restart always 
$ docker run --name zookeeper1 -d  -p 2181:2181 zookeeper

#Run dubbo-admin: 

$ docker run -d --name dubbo-admin -p 8088:8080 --link zookeeper1:zk -e DUBBO_REGISTRY="zookeeper:\/\/zk:2181" riveryang/dubbo-admin
```

### 2、数据库
> MySQL

```bash

$ docker run --name mysql1 -d -p 3306:3306 -e MYSQL_ROOT_PASSWORD=123 mysql:5.7

#5.7不需要额外处理，8.0需要重新设置密码

$ docker run --name mysql1 -d -p 3306:3306 -e MYSQL_ROOT_PASSWORD=123 mysql:8.0

$ docker exec -it mysql1 /bin/bash
root@4c41ed5cd39f:/# mysql -u root -p
mysql> ALTER USER 'root'@'%' IDENTIFIED WITH mysql_native_password BY '123456';
```

> MongoDB

```bash
$ docker run --name mongo1 -d -p 27017:27017 mongo:latest
```

> Redis

```bash
$ docker run --name redis1 -d -p 6379:6379 redis:latest

$ docker run --name redis1 -d -p 6379:6379 redis:latest -v $PWD/redis.conf:/etc/redis/redis.conf

-v /myredis/conf/redis.conf:/usr/local/etc/redis/redis.conf

$ docker run -d -p 6379:6379 -v ~/docker/redis/redis.conf:/usr/local/etc/redis/redis.conf --name myredis redis redis-server /usr/local/etc/redis/redis.conf

$ docker run -it redis /bin/bash

$ redis-cli -h 172.17.0.3 -a 123
```

> Memcached

```bash
$ docker run --name memcached1 -d -p 11211:11211 memcached:latest
```

> CouchDB

```bash
$ docker run --name couchdb1 -d -p 5984:5984 couchdb:latest
```

> Cassandra

```bash
$ docker run --name cassandra1 -d -p 9160:9160 -p 5984:5984 cassandra:latest
```

### 3、分布式处理与大数据
包含消息队列中间件RabbitMQ，分布式任务处理平台Celery，大数据分布式处理的三大重量级武器：Hadoop、Spark、Strom，以及数据采集和分析引擎Elasticsearch。

> RabbitMQ

```bash
$ docker run --name rabbitmq1 -d -p 5672:5672 rabbitmq:3
```

> Celery

```bash
#启动一个RabbitMQ Broker
$ docker run --name celery1 --link some-rabbit:rabbit -d celery

#启动一个Redis Broker
$ docker run --name celery1 --link some-redis:redis -e CELERY_BROKER_URL=redis://redis -d celery
```

> Hadoop

```bash
$ docker run --name hadoop1 -it sequenceiq/hadoop-docker:2.7.0 /etc/bootstrap.sh -bash
```

> Spark

```bash
$ docker run --name spark1 -it -p 8088:8088 -p 8042:8042 -h sandbox sequenceiq/spark:1.6.0 bash
```

> Strom

```bash
#本地的，集群较为复杂，可参考docker store
$ docker run --name storm1 -it -v $(pwd)/topology.jar:/topology.jar storm storm jar /topology.jar org.apache.storm.starter.ExclamationTopology
```

> Elasticsearch

```bash
$ docker run --name elasticsearch1 -d -p 9200:9200 -p 9300:9300 -v "$PWD/config":/usr/share/elasticsearch/config elasticsearch
```


### 4、编程语言
常见编程语言以及其框架都可以在Docker创建运行，包括C、C++、Java、Python、JavaScript、Go、PHP、Ruby、Perl、R、Erlang等，都可创建。但还是习惯开发时使用IDE在本机进行。就不一一列举了。

## 十、Docker进阶
### 1、核心实现
> 基本架构

采用C/S架构，通常在一台机器上，也可运行在不同机器上通过socket或api来通信。
Docker Daemon一般作为服务端来接收并处理客户的请求。默认监听unix:///var/run/docker.sock套接字，客户端通过该套接字向服务端发送命令。但需要解耦Docker Daemon，减少对它的依赖，以提高容器启动速度。

> 命名空间

需要通过linux内核的这一特性，实现对内存、cpu、网络io、硬盘io、存储空间，尤其是文件系统、网络、PID、UID、IPC等的相互隔离。
包括进程命名空间（同一进程在不同命名空间的PID不同），网络命名空间（使用虚拟网络设备将不同命名空间的网络设备连接到一起），IPC命名空间（同一个Interprocess Communication命名空间内的进程彼此可见可交互，不同空间的进程无法交互），挂载命名空间（允许不同命名空间的进程看到的文件结构不同，每个命名空间中的进程看到的文件目录彼此隔离），UTS命名空间（允许每个容器拥有独立的主机名Container ID和域名），用户命名空间（每个容器都自己的root账号，和宿主主机不在一个命名空间）

> 控制组

用来对共享资源进行隔离、限制、审计等。提供资源限制、优先级、资源审计、隔离、控制等功能。

> 联合文件系统（UnionFS）

轻量级的高性能分层文件系统，支持将文件系统中的修改信息作为一次提交，并层层叠加，同时可以将不同目录挂在到同一个虚拟文件系统下。使得基于基础镜像来职高不同的应用镜像时，可以共享同一个基础镜像层，提高了存储效率。

> Linux网络虚拟化

Docker本地网络利用了Linux的网络命名空间和虚拟网络设备（veth pair）。Docker创建容器时，会创建一对虚拟接口（veth）分别放到本机和新容器的命名空间中。本机端veth123连接默认的docker0网桥，容器端eth0放到新创建的容器中。从网桥可用地址段分配一个空闲地址给eth0，并配置默认路由网关为docker0的IP地址。

![](Docker技术入门与实战/docker_veth.jpg)

### 2、配置私有仓库
本地有大量的自定义镜像文件需要内部分享，才需要使用Docker Registry来管理。如基于容器运行，可使用

```bash
$ docker run -d -p 5000:5000 --restart=always --name registry -v ~/docker/registry/conf/config.yml:/etc/docker/registry/config.yml registry
```

如需要本地安装，需先安装Golang环境，然后安装Docker Distribution工具集。私有仓库默认启用TLS认证，因此可通过openssl或第三方来启用证书。

私有仓库提供认证和用户管理服务，认证基本是Oauth的模式，从Authorization Service获取Bearer token，然后在Registry v2中进行请求。

配置Registry使用yaml文件，大概包含log、storage、http、redis、notifications、health等模块。

另外可以使用sh脚本，实现本地批量上传镜像的操作。可以通过Notification实现镜像push、pull的通知，发送到用户自定义的服务器接口，实现镜像统计、自动化集成测试和部署。

### 3、安全防护与配置

> 命名空间隔离的安全

通过命名空间隔离并不是绝对的，容器中的应用可访问系统内核和部分系统文件，因此需要保证容器应用的安全可信，即镜像的来源和自身可靠。本身镜像管理有签名，保证完整和正确，但仍然需要保证安全。

> 控制组资源控制的安全

当个别容器出现异常时，保证本地系统和其他容器不受影响，避免引发雪崩灾难。

> 内核能力机制

Linux内核可将权限划分为更加细粒度的操作能力（以前只有根权限和非根权限），既可作用在进程上，也可作用在文件上。Docker容器被严格限制只允许使用内核的一部分功能。

> Docker服务端的防护

使用root启动服务，使用Unix套接字替代原先127.0.0.1上的TCP套接字等。

最后，可使用第三方检测工具Docker Bench来进行互联网安全中心（CIS）的安全规范检查。


### 4、高级网络功能

> 配置容器DNS和主机名

容器中的主机名和DNS配置信息时通过三个系统配置文件来维护的。/etc/resolv.conf、/etc/hostname、/etc/hosts。resolv.conf和宿主机保持一致。hostname记录了容器的主机名。hosts记录了容器的地址和名称。直接编辑修改这些文件会临时生效，重启后不会保存。可通过参数指定， -h HOSTNAME设定容器的主机名。 --link=CONTAINER_NAME:ALIAS添加一个连接的主机名到etc/hosts文件中，才可直接使用主机名通信。 --dns=IP_ADDRESS，会添加到/etc/resolv.conf中，容器会指定服务器来解析不在/etc/hosts中的主机名。

```bash
进入容器使用mount命令查看挂载信息时，可以找到这3个信息。
root@c420ddbf1945:/# mount
/dev/sda1 on /etc/resolv.conf type ext4 (rw,relatime,data=ordered)
/dev/sda1 on /etc/hostname type ext4 (rw,relatime,data=ordered)
/dev/sda1 on /etc/hosts type ext4 (rw,relatime,data=ordered)

root@c420ddbf1945:/# cat /etc/resolv.conf 
# Generated by dhcpcd from eth0.dhcp
# /etc/resolv.conf.head can replace this line
nameserver 192.168.65.1
# /etc/resolv.conf.tail can replace this line

root@c420ddbf1945:/# cat /etc/hosts       
127.0.0.1	localhost
::1	localhost ip6-localhost ip6-loopback
fe00::0	ip6-localnet
ff00::0	ip6-mcastprefix
ff02::1	ip6-allnodes
ff02::2	ip6-allrouters
172.17.0.2	c420ddbf1945

root@c420ddbf1945:/# cat /etc/hostname 
c420ddbf1945
```

> 容器访问控制  

1、容器访问外部网络  
主要是通过linux自带的iptables防火墙软件来进行管理。容器默认指定了网管为docker0网桥上的docker0内部接口（就是宿主机的本地接口），因此容器可直接访问宿主本地，并且通过宿主机转发来访问外部网络。

2、容器之间的访问  
相互访问需要两方面支持：一是网络拓扑是否联通（所有容器默认连到docker0网桥），二是iptables是否允许通过。

启动docker服务时，默认通过配置 -icc=false来默认进制容器之间的相互访问。但可以通过--link=CONTAINER_NAME:ALIAS来修改iptables规则，允许访问指定容器的开放端口。

> 映射容器端口到宿主主机的实现  

1、容器访问外部实现  
容器使用源地址映射（SNAT）实现，映射通过iptables的源地址伪装操作实现。上述规则将容器中出来的流量动态伪装成从系统网卡发出。
2、外部访问容器实现  
使用-p参数启用。其实是在本地iptable的nat表中添加了规则，将访问外部IP地址的网址修改为容器的IP地址。

> 其他网络配置

1、容器默认配置docker0网桥，还可以在启动docker时通过-b BRIDGE来自定义网桥，或者使用OpenvSwich网桥来替代。

2、如需要两个容器间可以直连通信，不通过主机网桥进行桥接，也可以创建一对peer接口放到两个容器，配置成点到点链路类型。

3、可使用libnetwork插件化网络功能，通过CNM（Container Networking Model容器网络模型），抽象成三种基本元素：Sandbox容器、Endpoint接入点、Network连通多个接入点的子网。CNM支持的驱动类型有：Null（无网络）、Bridge（Docker默认用网桥和iptables实现的单机网络）、Overlay（跨主机容器网络）、Remote。
![](Docker技术入门与实战/docker_CNM.jpg)

CNM相关命令如下，包含列出网络、创建网络、删除网络、接入容器、卸载容器和查看网络。可通过这些命令搭建隧道，让容器间可互相访问。

```bash 
$ docker network ls
$ docker network create NETWORK
$ docker network rm NETWORK
$ docker network connect NETWORK CONTAINER
$ docker network disconnect NETWORK CONTAINER
$ docker network rm NETWORK
$ docker network inspect NETWORK
```

### 5、docker集群平台
三剑客，Docker推出的Machine、Compose和Swarm，用于支持集群平台，提供更大的灵活性。
