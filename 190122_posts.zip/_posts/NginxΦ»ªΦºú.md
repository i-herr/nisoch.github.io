---
title: Nginx详解
date: 2017-03-29 15:57:37
tags: [Nginx,RTMP]
---

## 一、安装部署相关
> 使用docker安装

docker地址： https://store.docker.com/images/nginx

安装命令：
本地新建 nginx/html文件夹和nginx/conf/xxx.conf文件，xxx.conf文件参考下方第3小结-基础配置


``` bash
docker run --name nginx1 -d -p 8070:80 -v ~/docker/nginx/html:/usr/share/nginx/html -v ~/docker/nginx/conf:/etc/nginx/conf.d nginx
```

默认编译参数如下（可使用nginx -V查看）：

--prefix=/etc/nginx --sbin-path=/usr/sbin/nginx --modules-path=/usr/lib/nginx/modules --conf-path=/etc/nginx/nginx.conf --error-log-path=/var/log/nginx/error.log --http-log-path=/var/log/nginx/access.log --pid-path=/var/run/nginx.pid --lock-path=/var/run/nginx.lock

> linux编译安装

```bash
$ cd usr/local/src/
$ tar -xvf nginx-1.11.6.tar 
https://github.com/arut/nginx-rtmp-module
git clone https://github.com/arut/nginx-rtmp-module.git

$ ./configure --prefix=/usr/local/nginx  --add-module=/usr/local/src/nginx-rtmp-module  --with-http_ssl_module --with-http_stub_status_module

$ yum -y install pcre-devel
$ yum -y install openssl--devel

$ make && make install
```

<!--more-->

如果需要修改编译参数

```bash
# 原来的参数：
# --prefix=/app/nginx

# 添加的参数: 
# --with-http_stub_status_module --with-http_ssl_module --with-http_realip_module
# 步骤如下：
# 1. 使用参数重新配置:
$ ./configure --prefix=/app/nginx -user=nobody -group=nobody --with-http_stub_status_module \
--with-http_ssl_module --with-http_realip_module \
--add-module=../nginx_upstream_hash-0.3.1/ \
--add-module=../gnosek-nginx-upstream-fair-2131c73/
# 2. 编译:
$ make
# 一定不要make install，否则就是覆盖安装
```

> 服务启停控制

``` bashnginx -h 查看命令
$ nginx -t #测试配置文件
$ nginx -c /tmp/nginx.conf #指定conf文件启动
$ nginx -s reload|reopen|stop|quit #nginx -s signal 发送命令，
```
也可通过kill命令，kill SIGNAL PID，例如

``` bash
kill TERM | INT | QUIT | HUP '/var/run/nginx.pid'
```

 TERM和INT信号为快速停止，QUIT为平缓停止，HUP为平滑重启。如需要升级，可使用

``` bash
$ kill USER2 '/var/run/nginx.pid'
$ kill WINCH '/var/run/nginx.pid'
```

常用命令：

``` bash
$ ps -elf|grep nginx
$ netstat -antp
$ service iptables stop
$ nginx -V #可以查看原来编译时都带了哪些参数
```

> 基础配置

包含5个块：全局块、events块、http块、server块、location块

``` bash 
#如需全部可用，为user nobody nobody
user  nginx nginx;  

#可使用ps -ef | grep nginx查看worker process，与之对应
worker_processes  1; 

#错误日志存放路径，参数可使用debug、warn、error等，需要用户有写权限
error_log  /var/log/nginx/error.log warn;

#配置进程PID存放路径
pid        /var/run/nginx.pid;

#worker_connections等，用于服务器与用户的网络连接，包括连接数、对请求的事件驱动模型处理、序列化等
events {
	#每一个worker process同时开启的最大连接数
    worker_connections  1024;
    #默认为on，用于设置网络连接的序列化
    #accept_mutex off;
    #默认为off，是否允许worker process接收多个网络连接
    #multi_accept on;
    #事件驱动模型的选择，method可为select、poll、epoll等
    #use method;
}


http {
	#引用types结构的文件，包含浏览器能够识别的MIME类型和后缀。
    include       /etc/nginx/mime.types;
    default_type  application/octet-stream;
	
	#自定义日志服务
    log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
                      '$status $body_bytes_sent "$http_referer" '
                      '"$http_user_agent" "$http_x_forwarded_for"';
	
	#日志存放路径，main为log_format名称
    access_log  /var/log/nginx/access.log  main;

	#默认为off，用于配置允许sendfile方式传输文件
    sendfile        on;
    #tcp_nopush     on;

	#配置连接超时时间，与用户建立会话后，nginx服务器可保持连接打开一段时间
    keepalive_timeout  65;
    #单连接请求数上限，建立会话后，通过此连接发送请求的数量，默认为100
    #keepalive_requests 100;
	
	#是否使用gzip压缩
    #gzip  on;
	 
	#配置文件的引入
    include /etc/nginx/conf.d/*.conf;
}
```

/etc/nginx/conf.d/xxx.conf文件如下（只需要server块）：

``` bash
server {
	#可监听ip地址、端口和UNIX Domain Socket等，此处为端口
    listen       80;
    #基于名称的虚拟主机配置，支持正则表达式
    #server_name ~^www\d+\.iherr\.com$;
    #基于ip的虚拟主机配置，ifconfig命令可添加网卡的ip别名
    #server_name 172.17.0.2;
    server_name  localhost;
	
	#语法为location [= | ~ | ~* | ^~] uri { ... }，=为严格匹配，~为正则区分大小写，~*为正则不区分大小写。
    location / {
    	#用于配置请求的根目录
        root   /usr/share/nginx/html;
        #设置网站默认首页
        index  index.html index.htm;
    }

    #error_page  404              /404.html;

    # redirect server error pages to the static page /50x.html
    #HTTP的错误代码，5XX代表服务端错误
    error_page   500 502 503 504  /50x.html;
    #重新配置50x.html的根目录
    location = /50x.html {
        root   /usr/share/nginx/html;
    }
    
    #.+为支持字符串捕获功能，可在alias里按顺序使用$1,$2等
    #location ~ ^/data/(.+\.(htm|html))$
    #{
    #可更改location的URL
    #	alias /location/other/$1;
    #}
    
    #基于ip配置Nginx的访问权限，支持ip、CIDR和all。除ip外，还提供基于密码配置访问权限
    #location /herr {
    #	deny 192.168.1.1;
    #	allow 192.168.1.0/24;
    #	deny all;
    #}
}
```

## 二、Nginx架构

> 模块化结构
高内聚、低耦合，设计模式理论中的迪米特原则，支持分布式、支持团队协同合作、支持应用拓展和升级。

分为核心模块，标准http模块、可选http模块、邮件服务模块和第三方模块等五大类。标准http模块默认编译到nginx中，除非使用--without-XXX参数。可选http模块默认不编译，除非使用--with-XXX参数。第三方模块中，比如agentzh的echo-nginx-module，memc-nginx-module、rds-json-nginx-module，lua-nginx-module等，都经常使用。

> web请求处理机制，使用多进程和异步非阻塞方式。

* 1、多进程方式，服务器主进程生成子进程来交互，相对独立，但资源消耗大，导致性能下降，如早期的Apache服务器。
* 2、多线程方式，服务器主进程派生一个线程来交互，线程的开销远小于进程，减轻web服务器对系统资源的消耗。但多线程位于同一进程，可以访问同样的内存空间，相互影响，需要自己对内存进行管理，引起死锁同步等问题，可能还需定期重启服务器。
* 3、异步方式，网络通信中的同步和异步是描述通信模式的概念，发送方发送请求后需等待收到接收方响应后，才发送下一个请求。异步中所有请求形成一个队列，接收方处理完成后通知发送方。

阻塞和非阻塞是用来描述进程处理调用的方式，主要指Socket的阻塞，本质是IO操作。阻塞方式为，调用结果返回之前，当前线程从运动状态被挂起，一直等到调用结果返回之后，才进入就绪，获取cpu继续执行。而非阻塞如果结果不能马上返回，当前线程也不会被挂起，而是立即返回执行下一个调用。

会形成同步阻塞方式、异步阻塞方式、同步非阻塞方式、异步非阻塞方式。

有一个主进程和多个工作进程，所有工作进程都可用于接收和处理客户端请求。每个工作进程都使用异步非阻塞方式处理。那么，nginx工作进程调用IO后，就去进行其他工作了，当IO调用返回后，IO怎么把状态通知工作进程？有两种方式，一是工作进程主动检查，二是IO完成后主动通知。基于第二种方式，形成了事件驱动模型，放弃创建进程和线程方法，采用如下实现办法，“事件发送器”每传递过来一个请求，“目标对象”就将其放入一个待处理事件的列表，使用非阻塞I/O方式调用。select/poll/epoll等事件驱动处理库（即多路IO复用方法）就是来支持这种方案的。

select有1024链接数限制，非线程安全，事件描述符集合有3组需要分别轮询。poll去除链接数限制，非线程安全，可同时检查3组事件。epoll线程安全，是高效的。

> nginx服务器架构

![](Nginx详解/nginx_process.jpg)

> nginx服务器的进程
 
* 1、主进程，配置文件、Socket管理、管理工作进程、平滑升级重启等  
* 2、工作进程，接收客户端请求、请求过滤处理、IO调用获取响应数据、与后端服务器通信、响应客户端请求，接收主进程指令  
* 3、缓存索引重建及管理进程  
 
进程交互，Master-Worker交互是单向管道，Worker-Worker相互隔离的，如需要交互，可从单向管道获取其他Worker信息。

## 三、Nginx的rtmp模块


https://github.com/arut/nginx-rtmp-module