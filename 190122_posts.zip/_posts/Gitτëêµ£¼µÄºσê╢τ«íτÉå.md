---
title: Git版本控制管理
date: 2017-01-07 17:51:09
tags: [Git]
---

## 一、Git概述

> 版本控制系统（VCS）

目的：是为了持续性的对代码或文档进行备份和存档，对变更进行追踪管理。

发展进程：SCCS源码控制系统-->RCS修订控制系统（本地）-->CVS并行版本系统-->Subversion（SVN）（集中化）-->Git（分布式）

> Git简史

Git，[『网站传送门』](https://git-scm.com/)，由大神Linus Torvalds发明，git本意是无用的人、饭桶，令人舒服的解释是Global Information Tracker。

之前Linux开源社区用的BitKeeper，05年开始收费后，迫使开发自己的版本系统。起初用来管理Linux内核的开发工作。于05年4月托管，Linux内核提交git，包含670万行代码。


Git的目标是需要以下特性：  

* 完全分布式
* 能胜任上千开发人员的规模，允许独立且同时开发，离线开发
* 支持并鼓励基于分支的开发，非线性分支管理
* 免费自由
* 性能优异，解决网络传输瓶颈，近乎所有操作都是本地执行，保证执行速度
* 保持完整性和可靠性，数据存储前使用SHA-1散列来计算校验和，会发现丢失或损坏的文件。

> Git三个工作区域

* Git仓库，用来保存项目元数据和对象数据的地方
* 工作目录，用来使用或修改
* 暂存区域，保存了下次提交的文件列表信息，是一个index文件，有时被叫做索引。

![](Git版本控制管理/git_area.png)


## 二、Git起步

> 客户端安装配置

* Windows使用cygwin版本的Git，或原生版本的msysGit。或者直接安装GitHub for Windows。
* Mac系统使用Xcode Command Line Tools。在Terminal运行git命令即可。或者直接安装GitHub for Mac。
* Linux可使用yum或apt-get安装。

git支持不同层级的配置文件

``` bash
.git/config  #版本库配置
~/.gitconfig #用户配置
/etc/gitconfig #系统配置
```

配置提交作者，根据上述层级分别对应，默认为global

``` bash
$ git config user.name "iherr"  #在当前版本库目录执行
$ git config user.email "herongrong-123@163.com"

$ git config --global user.name "iherr"
$ git config --global user.email "herongrong-123@163.com"

$ git config --system user.name "iherr"
$ git config --system user.email "herongrong-123@163.com"

$ git config --list #检查配置信息
$ git config --global alias.ci commit #可设置别名，使用命令git ci代替git commit
```

> 服务器端安装配置

* Gitlab
* Github
* Gitee

git传输协议有以下4种

* 本地协议
* HTTP协议
* SSH协议
* GIT协议

> 通用命令

``` bash
$ git  
usage: git [--version] [--help] [-C <path>] [-c name=value] [--exec-path[=<path>]] [--html-path] [--man-path] [--info-path] [-p | --paginate | --no-pager] [--no-replace-objects] [--bare] [--git-dir=<path>] [--work-tree=<path>] [--namespace=<name>] <command> [<args>]
```

理解短和长选项命令

``` bash
$ git commit -m "fixed bug"
$ git commit --message "fixed bug"
```

常用命令如下：

![](Git版本控制管理/git_command.jpg)


> 初始版本库命令

``` bash
$ mkdir test
$ cd test
$ git init  #创建隐藏目录.git
$ touch README.md
$ git add README.md  #将md文件添加到版本库
$ git add .  #或者将目录中所有文件都添加到版本库
$ git commit -m "first commit"

# 可创建版本库副本
$ git clone test test2 #在test上级目录执行，根据test创建test2。
Cloning into 'test2'...
done.
```

>  修改和提交的基础命令

add暂存，然后commit提交

```bash 
$ git add .  #将文件放入暂存区，从Untracked状态到Staged状态，或者从Modified状态到Staged状态
$ git commit -m "first commit" #只将暂存区文件提交到版本库，将文件从Staged状态到Unmodified状态
```

## 三、Git原理

> 版本库（repository）

版本库位于.git文件夹下，维护了两个主要的数据结构，对象库object store和索引index。

> 对象库

1、对象库，包含以下4种类型：

* 块blob，存放任意文件的数据
* 目录树tree，代表一层目录信息。
* 提交commit、一个提交对象保存版本库中每一次变化的元数据，每一个提交对象指向一个目录树对象。
* 标签tag，给提交对象取的tag。 

以下的图示，名为master分支和名为V1.0的标签都指向id为1492的提交对象，提交对象指向任何指定的树对象（可根据此树对象找到索引），树对象指向若干blob对象或其他树对象。 
 
<img src="Git版本控制管理/gitobject.jpeg" width="200" align=center/>
<!--![](Git版本控制管理/gitobject.jpeg)-->

> 索引

1、索引，是一个动态的二进制文件，描述版本库的目录结构。 

2、Git的工作原理，在工作目录和版本库之间加设了一层索引（index），用来暂存（stage）。一次提交的过程：暂存变更和提交变更。

<!--more-->

3、Git的索引，不包含任何文件内容，它仅仅追踪你想要提交的那些内容。当执行git commit命令的时候，会去检查索引，而不是工作目录来找到提交的内容。任何时候都可以通过git status查询索引的状态。

> 可寻址内容、追踪内容、打包文件等概念

* 可寻址内容名称，对象库的每一个对象，都有一个唯一的名称，SHA1散列值，160位的2进制=40位的16进制数。对同样的内容始终产生同样的id。因此任何变化都会导致SHA1改变，从而被编入索引。散列函数，提供了一种有效的方法来比较两个对象，甚至是非常大而复杂的数据结构，而不需要完全传输。  
* Git追踪内容，Git追踪的是内容，如两个文件内容一样，则对象库只保存一份blob副本，并将blob放入对象库，并以SHA1值作为索引。当文件版本变更时，git会存储每个文件的每个版本，而不是他们的差异。 
* Git使用打包文件（pack file）来高效的存储每个文件的每个版本，并实现版本库的高效数据传输。  

> 实例探究

```bash
$ mkdir hello
$ cd hello/
$ git init
$ find .
$ echo "hello world" >hello.txt
$ git add hello.txt 
$ find .git/objects/

.git/objects/
.git/objects//3b
.git/objects//3b/18e512dba79e4c8300dd08aeb37f8e728b8dad #前两位会编入目录，形成256路分区，避免有些文件系统变慢
.git/objects//info
.git/objects//pack

$ git cat-file -p  3b18e512dba79e4c8300dd08aeb37f8e728b8dad #根据散列值提取
hello world
$ git rev-parse 3b18 #通过前缀查询散列值
3b18e512dba79e4c8300dd08aeb37f8e728b8dad
$ git hash-object hello.txt #可通过命令计算hash值
3b18e512dba79e4c8300dd08aeb37f8e728b8dad

$ git ls-files -s  #查看索引文件
100644 3b18e512dba79e4c8300dd08aeb37f8e728b8dad 0	hello.txt

$ git write-tree #捕获索引并保存到树对象
68aba62e560c0ebc3396e8ae9335232cd93a3f60

$ git cat-file -p 68aba62 #可以像blob一样，查看树对象，里面保存的是索引信息
100644 3b18e512dba79e4c8300dd08aeb37f8e728b8dad 0	hello.txt

$ git commit-tree 68aba62e560c0ebc3396e8ae9335232cd93a3f60 -m "init" #生成提交树
fb71432eba1cae91b5cb8a2596b952da4dd8a535 #生成的hash可能会不一致，因为包含名字、时间、说明等。

$ git cat-file -p fb7143
tree 68aba62e560c0ebc3396e8ae9335232cd93a3f60 #对应的索引的树对象
parent *** #如果有父提交，则会显示
author iherr <herongrong-123@163.com> 1483203661 +0800
committer iherr <herongrong-123@163.com> 1483203661 +0800
```

原理总结：

* git通过目录树（tree）的对象来跟踪文件的路径名，当使用git add、git rm、git mv等命令时，会用新的路径名和blob信息来更新索引（位于.git/index）。
* 任何时候，都可以使用git write-tree从当前索引创建一个树对象，来捕获索引当前信息的快照。且每次对相同的索引计算一个树对象，SHA1散列值都是一样的。
* 使用git commit-tree可以生成提交对象，包含上一步的索引生成的树对象，作者、时间、提交信息等。
* 实际应用时，可以直接使用git commit命令，代替git write-tree和git commit-tree步骤。

> Git对象模型和文件的详细视图

模拟修改文件内容后的视图演变，有以下4步。

（1）初始文件和对象

![](Git版本控制管理/git_objects_initial.jpg)

（2）编辑file1之后

![](Git版本控制管理/git_objects_change.jpg)

（3）在git add之后

![](Git版本控制管理/git_objects_add.jpg)

（4）在git commit之后，更新的ref分支在refs/heads/master文件中，为最后一次commit的提交树对象。

![](Git版本控制管理/git_objects_commit.jpg)

## 四、文件管理和索引

> Git中的文件状态

![](Git版本控制管理/file_lifecycle.png)

``` bash
$ git status  #查看状态
$ git status -s  #查看状态，紧凑格式
********************没有任何修改时*******************
On branch master
Your branch is up-to-date with 'origin/master'.

nothing to commit, working tree clean

*********新增文件，没有git add时，该文件处于Untracked状态**************
On branch master
Your branch is up-to-date with 'origin/master'.

Untracked files:
  (use "git add <file>..." to include in what will be committed)

	OTHER.md

nothing added to commit but untracked files present (use "git add" to track)

************修改已有文件后，该文件从Unmodified变成Modified状态*************
On branch master
Your branch is up-to-date with 'origin/master'.

Changes not staged for commit:
  (use "git add <file>..." to update what will be committed)
  (use "git checkout -- <file>..." to discard changes in working directory)

	modified:   README.md
	
Untracked files:
  (use "git add <file>..." to include in what will be committed)

	OTHER.md

no changes added to commit (use "git add" and/or "git commit -a")

************git add 命令后，新增文件从Untracked状态变更为Staged状态，修改文件从Modified状态变更为Staged状态***************
On branch master
Your branch is up-to-date with 'origin/master'.

Changes to be committed:
  (use "git reset HEAD <file>..." to unstage)

	new file:   OTHER.md
	modified:   README.md
	
************git commit 命令后，文件都回到Unmodified状态**************
On branch master
Your branch is ahead of 'origin/master' by 1 commit.
  (use "git push" to publish your local commits)

nothing to commit, working tree clean
```

> 子目录以tree存储

新增一个完全相同的副本，发现子目录是tree。

``` bash 
$ mkdir subdir
$ cp hello.txt subdir/
$ git add subdir/hello.txt 
$ git write-tree
492413269336d21fac079d4a4672e55d5d2147ac

$ git cat-file -p 492413 #查看索引树的对象
100644 blob 3b18e512dba79e4c8300dd08aeb37f8e728b8dad	hello.txt
040000 tree 68aba62e560c0ebc3396e8ae9335232cd93a3f60	subdir

$ git cat-file -p 68ab #查看目录树的对象
100644 blob 3b18e512dba79e4c8300dd08aeb37f8e728b8dad	hello.txt

$ git ls-files --stage #等同于git ls-files -s，查看索引文件
100644 3b18e512dba79e4c8300dd08aeb37f8e728b8dad 0	hello.txt
100644 3b18e512dba79e4c8300dd08aeb37f8e728b8dad 0	subdir/hello.txt
```

> git rm

```bash
$ git rm OTHER.md #会将文件从索引和工作目录都删除。使用该命令删除暂存区的文件，并删除工作区文件。后面需要提交，来移除Git仓库的文件。
$ git rm -f OTHER.md #加-f是针对文件已经修改过，不论暂存与否，都还未提交。必须增加-f强制，由于删除了工作区文件，且未提交，会导致该文件数据丢失。
$ git rm --cached OTHER.md #会删除索引中的文件并保留工作目录。文件状态从其他状态变到Untracked。适用情形：针对无法普通移除的文件，通过该方式移除，保留工作区文件。例如gitignore文件。
```

> git mv

如需要移动或重命名文件，可直接使用git mv。相当于先rm再add。

```bash 
$ git mv README.md README #更名，相当于以下3条命令：

$ mv README.md README$ git rm README.md$ git add README
```

VCS当重命名后回丢失追踪，SVN需要使用svn mv命令显式的追踪每一次重命名。
而Git可以保留，当Git碰到重命名时，只会影响树对象，不会影响blob内容对象。查看两棵树差异就可发现blob被移动到新的地方。

```bash
# 两个树对象指向的blob一样，名称不一样，是两个不同的树。
$ git cat-file -p d37e
100644 blob d800886d9c86731ae5c4a62b0b77c437015e00d2	README.md
$ git cat-file -p b7d8
100644 blob d800886d9c86731ae5c4a62b0b77c437015e00d2	README
```

> .gitignore文件

文件格式：
空行会被忽略，#开头的行用于注释。
目录名由反斜线/标记。
可使用shell通配符，如*。
起始的感叹号用于取反。

示例：

```txt
*.a       # 忽略所有 .a 结尾的文件
!lib.a    # 但 lib.a 除外
/TODO     # 仅仅忽略项目根目录下的 TODO 文件，不包括 subdir/TODO
build/    # 忽略 build/ 目录下的所有文件
doc/*.txt # 会忽略 doc/notes.txt 但不包括 doc/server/arch.txt
```

GitHub 有一个十分详细的针对数十种项目及语言的 .gitignore 文件列表，你可以在 [『Github gitignore项目』](https://github.com/github/gitignore) 找到它。

层次优先级：

* 1、命令行上指定的模式。
* 2、相同目录的.gitignore文件
* 3、上层目录
* 4、.git/info/exclude文件
* 5、配置变量core.excludedfile指定的文件

但是有时候在项目开发过程中，突然心血来潮想把某些目录或文件加入忽略规则，按照上述方法定义后发现并未生效，原因是.gitignore只能忽略那些原来没有被track的文件，如果某些文件已经被纳入了版本管理中，则修改.gitignore是无效的。那么解决方法就是先把本地缓存删除（改变成未track状态），然后再提交：

```
git rm -r --cached .
git add .
git commit -m 'update'
```

## 五、提交

> 提交（commit）流程

提交是用来记录版本库的变更的。会记录索引的快照并把快照放进对象库。Git会将当前索引的状态与之前的快照做一个比较，并派生出一个受影响的文件和目录列表。对不同的对象和状态，git的动作如下：

| 对象 | 是否修改 | git动作 | 
| -------  |:---: 	|:---:		|
|	文件	|	是	|	创建新的blob对象 	|  
|	文件 |	否 |	沿用原有blob对象  |
|	目录 |	是	|	创建新的树对象  | 
|	目录	|  否	|	沿用原有树对象 	|

提交的快照是串联在一起的，需要和之前某个状态的索引进行比较，git也可以通过修剪有相同内容的子树来避免大量递归比较。提交是将变更引入版本库的唯一方法，且任何变更都必须由一个提交引入。Git非常适合频繁的提交。

原子集变更。一个提交，无论有哪些改变，要么全部应用，要么全部拒绝。

> 常用commit命令

```bash
#当添加或更改文件时，允许合成一步
$ git commit index.html 

#如果移动或删除文件时，必须分成两步
$ git rm index.html
$ git commit

$ git commit -a -m "first commit" #-a或--all选项可将已跟踪过的文件暂存并提交，将文件从Modified状态到Staged状态，并到Unmodified状态。对于Untracked状态的文件无效。
$ git commit --amend" #--amend选项，用于提交几个遗漏的文件，第二次提交将代替第一次提交。
```

> 识别提交，显示引用（散列ID）和隐式引用（HEAD就是一种）。

1、绝对提交名，散列ID表示唯一确定的一个提交。Git允许使用唯一的前缀来缩短这个数字。
2、引用（ref）和符号引用（symbolic reference）。ref通常指向提交对象。symref间接指向Git对象。

.git/refs/中，refs/heads/REFNAME代表本地分支，refs/remotes/REFNAME代表远程跟踪分支，refs/tags/REFNAME代表标签。他们都是引用。

Git自动维护几个用于特定目的的特殊符号引用。可用在提交的任何地方使用。

| 符号引用 | 作用 |
| -------  |:---: 	|
|	HEAD	|	始终指向分支的最近提交	|	
|	ORIG_HEAD |	使用它恢复或回滚到之前的状态 |
|	FETCH_HEAD |	最近抓取的分支HEAD的简写	|
|	MERGE_HEAD	|  正在合并进行中HEAD的提交 |

通过符号^和~来确定相对提交名。

```bash 
$ git show-branch --more=35| tail -10
[master] tes1
[master^] test
[master~2] test3
[master~3] test2
[master~4] herr3
[master~5] herr1
[master~6] commit -herr
```

> 查看提交历史

查看提交日志

```bash
$ git log
commit 7b74121f2a293645bbfc6833bfcb040a3d4cf848 (HEAD -> master)
Author: iherr <herongrong-123@163.com>
Date:  Jan 7 18:39:58 2017 +0800

    second

commit d9b1305573c70e8c1111b038311f4d8eff7cc79d
Author: iherr <herongrong-123@163.com>
Date:  Jan 7 18:34:00 2017 +0800

    init
    
$ git log hellonew.txt # 查看某个文件的提交历史
$ git log --follow hellonew.txt #添加follow会找到整个历史记录
```

查看某次提交的详细信息

```bash 
$ git show d9b1305573c70e8c1111b038311f4d8eff7cc79d

commit d9b1305573c70e8c1111b038311f4d8eff7cc79d
Author: iherr <herongrong-123@163.com>
Date:  Jan 7 18:34:00 2017 +0800

    init

diff --git a/index.html b/index.html
new file mode 100644
index 0000000..5f540ea
--- /dev/null
+++ b/index.html
@@ -0,0 +1 @@
+herr
```

查看两次提交之间的差异。git diff本身只显示尚未暂存的改动，不加参数，比较的是工作区与暂存区的差异。如只有一个参数，比较的工作区与指定commit-id的差异。如有两个参数，比较的是两个commit-id之间的差异。

```bash 
$ git diff #查看工作区与暂存区的差异，即未暂存的改动
$ git diff --staged #查看已暂存和版本库的差异

$ git diff d9b1305573c70e8c1111b038311f4d8eff7cc79d 7b74121f2a293645bbfc6833bfcb040a3d4cf848 #查看两个提交的差异

diff --git a/index.html b/index.html
index 5f540ea..a36d2c5 100644
--- a/index.html
+++ b/index.html
@@ -1 +1,9 @@
-herr
+<!DOCTYPE html>
+<html>
+<head>
+       <title>test</title>
+</head>
+<body>
+
+</body>
+</html>
```

> 远程仓库

```bash
$ git clone https://gitee.com/iherr/test.git #远程库克隆
$ git remote #远程服务器的名称
origin
$ git remote -v #查看远程仓库的读写设置，分为fetch获取和push推送权限
origin	https://gitee.com/iherr/test.git (fetch)
origin	https://gitee.com/iherr/test.git (push)
$ git remote show origin #查看远程仓库的更多信息，例如自动推送、自动拉取的设置。
* remote origin
  Fetch URL: https://gitee.com/iherr/test
  Push  URL: https://gitee.com/iherr/test
  HEAD branch: master
  Remote branch:
    master tracked
  Local branch configured for 'git pull':
    master merges with remote master
  Local ref configured for 'git push':
    master pushes to master (fast-forwardable)
$ git remote rm origin #远程仓库的移除
$ git remote add origin https://gitee.com/iherr/test.git #关联到远程库
$ git fetch origin master
$ git merge origin/master --allow-unrelated-histories #如报错fatal: refusing to merge unrelated histories，需要增加参数allow-unrelated-histories
#$ git pull origin master  --allow-unrelated-histories #fetch和merge两步，可使用pull替代
$ git push -u origin master #本地库内容推送到远程，-u参数可使得以后只用git push即可
```

> 打标签

Git 使用两种主要类型的标签：轻量标签（lightweight）与附注标签（annotated）。

* 一个轻量标签很像一个不会改变的分支 - 它只是一个特定提交的引用。
* 附注标签是存储在 Git 数据库中的一个完整对象。 它们是可以被校验的；其中包含打标签者的名字、电子邮件地址、日期时间；还有一个标签信息；并且可以使用签名与验证。

```bash
$ git tag -a v1.0 -m 'version 0.1'#对当前提交打标签
$ git tag -a v1.1 9a0a #对某个commit打标签
$ git tag
v1.0
v1.1
$ git show v1.1
tag v1.1
Tagger: iherr <herongrong-123@163.com>

version 1.1

commit 23a2f9c60aa6537823d83428bf2e046b57aedd66 (HEAD -> master, tag: v1.1, origin/master, origin/HEAD)
Merge: 30108a0 76d0ae6
Author: iherr <herongrong-123@163.com>
```

使用git push不会传送标签到远程仓库服务器上，在创建完标签后你必须显式地推送。

```bash
$ git push origin v0.1 #推送特定标签到远程仓库
$ git push origin --tags #推送所有标签到远程仓库
```

> DAG

Git通过有向无环图（DAG）实现版本库的提交历史记录，时间轴从左到右，不关心提交时间，只关心指向。
主分支从提交A、B、C、D开始，pr-17分支从A、B、E、F、G，并且提交H是一个合并提交，将pr-17合并到master分支。

![](Git版本控制管理/git_dag.jpg)

一般的提交有且只有一个父提交。
初始提交没有父提交。
合并提交拥有多个父提交。

``` bash
$ git push <远程主机名> <本地分支名>:<远程分支名>
```

## 六、分支

> 定义

分支，是启动一条单独的开发线的基本方法。

分支的本质，就是一个可以移动的指向最新commit的指针。由于 Git 的分支实质上仅是包含所指对象校验和（长度为 40 的 SHA-1 值字符串）的文件，所以它的创建和销毁都异常高效。创建一个新分支就相当于往一个文件中写入 41 个字节（40 个字符和 1 个换行符）。

* 一个分支通常代表一个单独的客户发布版。
* 可以封装一个开发阶段
* 可以隔离一个特性的开发或者复杂的bug
* 可以代表某个贡献者的工作

标签和分支都是引用，那么它们存储的内容也是类似的。都存储在refs/tags和refs/heads里。分支指向一个commit对象，标签指向一个标签对象，该标签对象的object属性也指向一个commit对象。

使用分支和标签的区别，tag的位置是固定的，在给指定提交打好标签以后，它就固定于此位置。分支的位置会不断变动的，随着分支的向前推移或者向后回滚，都在不断变化。

> 图解分支的新建与合并

1、在master默认分支上工作，有C0，C1，C2共3个提交

![](Git版本控制管理/git_branch1.png)

2、创建分支，解决#53问题。

```bash
$ git checkout -b iss53 #新建并切换至新分支
Switched to a new branch "iss53"

#它是下面两条命令的简写：
$ git branch iss53 #只创建分支，不切换工作目录
$ git checkout iss53 #切换到新分支
```
![](Git版本控制管理/git_branch2.png)

3、在分支上提交C3。

![](Git版本控制管理/git_branch3.png)

4、有个着急的fix。

```bash
$ git checkout master #切换回master分支
Switched to branch 'master'

$ git checkout -b hotfix #新建hotfix分支
Switched to a new branch 'hotfix'
$ git commit *** #在该分支提交C4
```

![](Git版本控制管理/git_branch4.png)

5、合并hotfix分支，启用Fast-forward，由于当前 master 分支所指向的提交是你当前提交（有关 hotfix 的提交）的直接上游，所以Git只是简单的将指针向前移动。master 被快进到 hotfix。

```bash
$ git checkout master
$ git merge hotfix
Updating f42c576..3a0874c
Fast-forward
 index.html | 2 ++
 1 file changed, 2 insertions(+)
```

![](Git版本控制管理/git_branch5.png)

6、删除hotfix分支，并切换回iss53分支，继续修复bug并提交C5。

```bash 
#由于hotfix和master指向一个commit，可删除hotfix分支
$ git branch -d hotfix
Deleted branch hotfix (3a0874c).

#现在你可以切换回你正在工作的分支继续你的工作，也就是针对 #53 问题的那个分支（iss53 分支）。

$ git checkout iss53
Switched to branch "iss53"
$ git commit *** #提交C5
```

![](Git版本控制管理/git_branch6.png)

7、将iss53合并回master， 因为master 分支所在提交并不是 iss53 分支所在提交的直接祖先，Git 不得不做一些额外的工作。 出现这种情况的时候，Git 会使用两个分支的末端所指的快照（C4 和 C5）以及这两个分支的工作祖先（C2），做一个简单的三方合并。

```bash
$ git checkout master
Switched to branch 'master'
$ git merge iss53
Merge made by the 'recursive' strategy.
index.html |    1 +
1 file changed, 1 insertion(+)
```

![](Git版本控制管理/git_branch7.png)

8、一次典型合并中所用到的三个快照
和之前将分支指针向前推进所不同的是，Git 将此次三方合并的结果做了一个新的快照并且自动创建一个新的提交指向它。 这个被称作一次合并提交，它的特别之处在于他有不止一个父提交。

![](Git版本控制管理/git_branch8.png)

9、后续可删除iss53

```bash
$ git branch -d iss53
```

> 遇到冲突的解决方案

1、查看有冲突的文件

```bash
$ git merge iss53
Auto-merging index.html
CONFLICT (content): Merge conflict in index.html
Automatic merge failed; fix conflicts and then commit the result.

$ git status
On branch master
You have unmerged paths.
  (fix conflicts and run "git commit")

Unmerged paths:
  (use "git add <file>..." to mark resolution)

    both modified:      index.html

no changes added to commit (use "git add" and/or "git commit -a")
```

2、修改冲突的文件

```bash
<<<<<<< HEAD:index.html
<div id="footer">contact : email.support@github.com</div>
=======
<div id="footer">
 please contact us at support@github.com
</div>
>>>>>>> iss53:index.html
```

这表示 HEAD 所指示的版本（也就是你的 master 分支所在的位置，因为你在运行 merge 命令的时候已经检出到了这个分支）在这个区段的上半部分（======= 的上半部分），而 iss53 分支所指示的版本在 ======= 的下半部分。 为了解决冲突，你必须选择使用由 ======= 分割的两部分中的一个，或者你也可以自行合并这些内容。 例如，你可以通过把这段内容换成下面的样子来解决冲突：

```bash
<div id="footer">
please contact us at email.support@github.com
</div>
```

3、可再次查看status，冲突解决后可commit进行提交

```bash
$ git status
On branch master
All conflicts fixed but you are still merging.
  (use "git commit" to conclude merge)

Changes to be committed:

    modified:   index.html
```
    
> 分支管理

```bash
$ git branch #查看本地分支列表
* master  #已经检出到你的工作目录中的分支用*标记
testing
$ git branch -v #查看分支的最后一次提交
$ git branch --no-merged #未合并到当前分支的分支。不可删除。
$ git branch --merged #已合并到当前分支的分支。可删除。

$ git branch -d testing #删除本地分支
$ git branch -D testing #如分支未被合并，如需要删除，则需要强制删除本地分支

$ git show-branch  #查看分支
* [master] tes1
 ! [testing] tes1
--
*+ [master] tes1

$ git checkout testing #切换到某个分支
$ git checkout -f testing  #忽略变更，强制检出
$ git checkout -m master #本地修改和目标分支进行一次合并操作

```

> 远程分支

clone后本地分支和远程分支的关系

![](Git版本控制管理/remote_branch1.png)

```bash
$ git branch -r #查看远程分支
$ git branch -a #查看本地和远程分支
$ git push origin :testing  #删除远程分支，参考格式：git push <远程主机名> <本地分支名>:<远程分支名>，origin 后面有空格
$ git push origin testing  #将本地testing分支推送到主机的testing分支，省略了远程分支名，如果testing远程分支不存在，则会新建
```

> 变基-rebase

在 Git 中整合来自不同分支的修改主要有两种方法：merge 以及 rebase。

* merge对应的观点是，仓库的提交历史即是“记录实际发生过什么”。它是针对历史的文档，本身就有价值，不能乱改。如果由合并产生的提交历史是一团糟怎么办？ 既然事实就是如此，那么这些痕迹就应该被保留下来，让后人能够查阅。
* rebase对应的观点则正好相反，他们认为提交历史是“项目过程中发生的事”。

总的原则是，只对尚未推送或分享给别人的本地修改执行变基操作清理历史，从不对已推送至别处的提交执行变基操作。变基的风险，要用它得遵守一条准则：不要对在你的仓库外有副本的分支执行变基。

说的白话一点，对只自己用，且有代码提交洁癖的，用rebase。对团队协作的，那就不要用了，否则人民群众会仇恨你，嘲笑你，唾弃你。

1、有两个分支

![](Git版本控制管理/git_rebase1.png)

2、可采用merge进行分支合并

![](Git版本控制管理/git_rebase2.png)

3、当然也可以使用rebase，将 C4 中的修改变基到 C3 上。将提交到某一分支上的所有修改都移至另一分支上，就好像“重新播放”一样。它的原理是首先找到这两个分支（即当前分支 experiment、变基操作的目标基底分支 master）的最近共同祖先 C2，然后对比当前分支相对于该祖先的历次提交，提取相应的修改并存为临时文件，然后将当前分支指向目标基底 C3, 最后以此将之前另存为临时文件的修改依序应用。

```bash
$ git checkout experiment
$ git rebase master
First, rewinding head to replay your work on top of it...
Applying: added staged command
```
![](Git版本控制管理/git_rebase3.png)

4、现在回到 master 分支，进行一次快进合并。

```bash
$ git checkout master
$ git merge experiment
```
![](Git版本控制管理/git_rebase4.png)


## 七、撤销

> 储藏-stash

经常有这样的事情发生，当你正在进行项目中某一部分的工作，您无法直接提交该工作，而你想转到其他分支上进行一些工作，或者需要git pull更新时，可以使用stash。会有以下提示：

```bash
$ git pull origin master
remote: Enumerating objects: 5, done.
remote: Counting objects: 100% (5/5), done.
...
error: Your local changes to the following files would be overwritten by merge:
	aa.md
Please commit your changes or stash them before you merge.
```

常用命令：

```bash
$ git stash #实施stash，这样工作目录就干净了
Saved working directory and index state WIP on master: 9fc96ca init9
$ git stash list # 查看stash列表
stash@{0}: WIP on master: 9fc96ca init9
$ git stash apply #应用stash，如有多个，可使用git stash apply stash@{0}
Auto-merging aa.md
CONFLICT (content): Merge conflict in aa.md
$ git stash drop stash@{0} #移除stash
$ git stash branch testchanges # 使用stash创建分支
```


> 文件修改后未执行git add操作，撤消对未暂存的文件的修改

```bash
$ git checkout -- hello.txt #未被add之前，恢复某个文件
$ git checkout . #未被add之前，恢复全部文件
```

> 已执行git add操作，需要撤销暂存区的某个文件提交

```bash
$ git add .
$ git reset HEAD hello.txt  #恢复到git add前的状态
```

> 已执行git add操作，但想撤销修改

```bash
$ git reset HEAD hello.txt # 先撤销暂存区
$ git checkout -- hello.txt # 再撤销文件修改
```

> 多次commit操作，想撤销到其中的某次commit

```bash
$ git reset 499b95 #默认采用--mix参数，代表就将头恢复掉，已经add的缓存也会丢失掉，需要重新add，工作空间的文件不变。
Unstaged changes after reset:
M	README.md
M	aa.md
$ git status
On branch master
Your branch is up-to-date with 'origin/master'.

Changes not staged for commit:
  (use "git add <file>..." to update what will be committed)
  (use "git checkout -- <file>..." to discard changes in working directory)

	modified:   README.md
	modified:   aa.md

no changes added to commit (use "git add" and/or "git commit -a")

------------------------------------------------------------------- 
$ git reset --soft 499b95 #采用--soft参数，就仅仅将头指针恢复，已经add的缓存以及工作空间的文件都不变。
$ git status
On branch master
Your branch is up-to-date with 'origin/master'.

#与mix不一样的地方在于，已add过的aa.md缓存，不会变。而mix会丢失，需要重新add
Changes to be committed:
  (use "git reset HEAD <file>..." to unstage)

	modified:   aa.md

Changes not staged for commit:
  (use "git add <file>..." to update what will be committed)
  (use "git checkout -- <file>..." to discard changes in working directory)

	modified:   README.md

$ git reset --hard 499b95 #使用hard模式，那么一切就全都恢复了，头指针恢复，aad的缓存消失，工作空间的文件也恢复到以前状态。慎用，可能会导致数据丢失。

#如果使用了hard导致数据丢失想回到最新的commit，需要在日志里找到相关commitid才行。
$ git reflog #从日志中查找commitid
或者可在./git/logs/refs/heads/master文件中，查找最新的commitid，然后用reset恢复到最新。
```

> 已经git push，需要撤销指定文件到指定版本

```bash
# 查看指定文件的历史版本
$ git log <filename>
# 回滚到指定commitID
$ git checkout 499b95 hello.txt
```

> 已经git push，删除最后一次远程提交

```bash 
$ git revert HEAD  #使用revert，revert是放弃指定提交的修改，但是会生成一次新的提交，需要填写提交注释，以前的历史记录都在
$ git push origin master
```

revert可能会出现失败，如下：

```bash
$ git revert d6130 #revert 某个commitid，是恢复到parent节点，因为该commitid是merge，有两个parent，系统无法判定是哪个。
error: commit d61306767425147c5d7c197ce1ab9cf2441d53a1 is a merge but no -m option was given.
fatal: revert failed
$ git revert d6130 -m 1 #通过-m参数指定，1代表当前branch。
[master 040d054] Revert "init7"
 2 files changed, 1 insertion(+), 3 deletions(-)
 delete mode 100644 ISS2.md
```

如和他人协作，建议使用如上的revert，这样可保留提交记录。但如果只是自己使用，且不想保留提交记录，可以使用reset。不推荐。

```
$ git reset --hard HEAD^  #HEAD^等价于HEAD~1，reset是指将HEAD指针指到指定提交，历史记录中不会出现放弃的提交记录。
$ git reset HEAD~X //需要回退多少个版本，X代表你要回退的版本数量，当然也可直接指定commitid
$ git push origin master -f
```

> 暂存保存

```bash 
$ git stash #git stash操作适用于，当你的工作进行到一半，此时还不想要提交，但是又必须切换到其他分支工作的时候

$ git stash apply #stash 命令就会将你此时工作区的代码存起来，待你想继续工作时，执行
```

> rebase变基，进行git提交的压缩

```bash
$ git rebase -i HEAD~4 #对最近的4个commit进行rebase 操作；
#具体的操作下面的 Commands 说明得很清楚了，对于 commit 合并可以使用 squash、fixup 指令，区别是 squash 会将该 commit 的注释添加到上一个 commit 注释中，fixup 是放弃当前 commit 的注释；
#编辑后保存退出，git 会自动压缩提交历史，如果有冲突，记得解决冲突后，使用 git rebase --continue 重新回到当前的 git 压缩过程
$ git push -f #推送到远程仓库,重新查看提交提交历史，会发现这些 commit 已经合并了，整个提交历史简洁了很多

```