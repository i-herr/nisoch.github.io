---
title: JavaScript高级程序设计（1）基础语法
date: 2016-03-03 12:36:53
tags: [JavaScript]
---

## 一、JavaScript简介
![JS](JavaScript高级程序设计（1）基础语法/js.png)

1、产生：1995年由Netscape提出，从简单的输入验证器发展成强大的变成语言。随着微软和JScipt加入竞争，形成了ECMAScipt的标准。JS版本号不一，一般都以ECMAScript兼容性和对DOM支持情况为准。  

2、JavaScript组成：ECMAScript（核心，包含语言的语法、类型、语句、关键字、保留字、操作符、对象）、DOM(文档对象模型)、BOM（浏览器对象模型）   

3、在HTML中，通过&lt;script&gt;元素来使用JS，且标签尽量放到&lt;/body&gt;前来加快解析。通过&lt;noscript&gt;平稳退化不支持JS的浏览器，使用[CData[JSCode]]来平稳退化XHTML。

## 二、JavaScript基础  
> 语法


> JS语法

* 动态类型，定义变量用var操作符
* undefined：变量未赋值，null：变量为空值  
* 区分大小写  
* 标识符（变量、函数、参数、属性等）驼峰 
* 基本类型：数字、布尔、串  
* 单行多行注释
* 语句分号结尾

> 数据类型  

Undefined、Null、Boolean、Number、String、Object  

* typeof操作符，返回多一个function  
* undefined派生自null值的，相等性测试返回true。  
* undefined、null、0/NaN、空字符串，转换成布尔为false。
* 0代表八进制、0x代表十六进制，浮点计算会产生舍入误差。Number.MIN_VALUE和Number.MAX_VALUE为ECMAScript能保存的最大和最小值，超出了会转换成Infinity。isNaN用来判断是否是“非数值”。  
* 数值转换，Number()用于任何类型、parseInt(string,int)和parseFloat()用于字符串转换，int默认为10进制。  
* string，可使用双引号或单引号表示，有些特殊字符字面量需要使用'\'转义。可使用 .toString(int)将其他类型转换为字符串，int默认为10进制。  
* object，定义：var o =new Object();

> 操作符

1、一元操作符（递增和递减、加和减表示正负）

2、位操作符，涉及补码，负数的补码=正数的二进制的反码加1。
按位非 NOT（~）  
按位与 AND（&）  
按位或 OR（|）  
按位异或 XOR（^）  
左移(<<)，不影响符号位  
有符号的右移（>>），不影响符号位  
无符号的右移（>>>），如果是负数，会变成正数  

3、布尔操作符  
逻辑非（!）
逻辑与（&&）
逻辑或（||）


> 流控制语句

> 函数：

* 定义函数时指定形参，调用函数时提供实参。  
* 基本类型，按值传递。数组或对象时，按指针传递。  
* 函数外声明为全局变量，只要页面存在就活着。函数内声明为局部变量，函数结束就消失。
* 构造函数，是创建对象的函数。首字母大写。
* 赋给一个对象属性的函数成为方法。方法可以使用this来引用调用这个方法的对象。
* window对象、document对象，以及document.getElementById方法会返回一个元素对象。