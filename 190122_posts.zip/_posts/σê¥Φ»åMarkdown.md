---
title: 初识Markdown
date: 2014-10-19 18:22:03
tags: Markdown
---

## 一、Markdown使用场景

以前只在github上接触了下md文件，遇到倒是简单，也通用。如今自己搭建博客，便得系统的了解下Markdown了。

说到使用场景，基本有以下几种：

* 需维护型文档：文档需要在多平台使用，如邮件、wiki平台、同事传阅、网站发布等。一般文档常用Word来写，但是如果文档一需要在网上发布就麻烦了，格式没有跟过来。如果一开始就是markdown语法，可以通用解决。
* 项目文档：项目文档一般都是用md来写的，github的项目的Readme.md就是markdown文档。
* 创意简历、博客：还有一种装逼手段就是用markdown来编写博客和简历，那绝对是创意来着的，适合程序员。


## 二、Markdown语法

语法这玩意，我也是现学，找到一篇Markdown的文章，可以参考[『Markdown 语法说明』](https://www.appinn.com/markdown/)

<!--more-->

> 表格

| 大项  | 说明 |
| :-----: |-----|
|1|	111|
|2|	222|
|3|	333|

- [x]张三 
- [x]李四
- [ ]王五

## 三、Markdown工具
提到Markdown工具，作为一名简书控，平常写文章时，便使用的简书在线的Markdown编辑器了。想到这玩意还要联网就觉得写博客的场景不太适用。Mac下推荐[『MacDown』](http://macdown.uranusjr.com)，试了下对照预览、插入链接(Command+Shift+K)、图片(Command+Shift+I)，都还算方便。我在写这篇博文时的使用截图，如下图所示。

![](初识Markdown/macdown.jpg)

好啦，这玩意够用就好。不需要太精通。

