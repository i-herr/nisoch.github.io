---
title: SpringCloud实战（2）-服务发现
date: 2018-07-04 16:59:22
tags: [SpringCloud,Java]
---

## 一、服务发现（注册中心、服务注册）
微服务系列，而它必不可缺少的组件就是服务发现组件。提到的目前市面上组件有eureka,consul,zooKeeper,etcd，那该如何选型？

| 特性       | Consul    |  ZooKeeper  | etcd | eureka
| ------ | :-----:   | :----: | :----: |:----: |
| 编写语言 |	go	|	Java	|	go		|	java|
| 客户端支持|http,dns|跨语言弱，Curator组件|http，Etcd3支持grpc|http,非java(sidecar) |
|  多数据中心 |支持||||
| KV存储 |支持|支持|支持||
|健康检查|服务状态、内存、硬盘等|(弱)长连接，keepalive|连接心跳|可配支持|
|watch支持|全量/支持长轮询|支持|支持长轮询|支持长轮询, Eureka 2.0(正在开发中)也计划支持|
|自身监控|metrics||metrics|metrics|
|安全|acl /https|acl|https支持（弱）||
|一致性算法|raft|paxos|raft||
|CAP理论|CA|CP(牺牲可用性)|CP(牺牲可用性)|AP(一致性弱)|
|spring cloud|已支持|已支持|已支持|已支持|

## 二、Eureka配置
[『Eureka』](https://github.com/Netflix/Eureka)是Netflix开源的服务发现组件。

Eureka通过集群同步、心跳检查、客户端缓存等机制，提高系统的灵活性、可收缩性和可用性。

我们根据第一个项目spring-cloud-trip-config作为基础，增加eureka作为服务注册中心，分为3个module

* eureka-server，作为eureka的server服务注册中心
* eureka-config-server，注册为config-server和eureka-client端，连接到eureka-server成为服务提供者。
* eureka-config-client，作为config-client和eureka-client端，连接到eureka-server成为服务消费者。

> eureka服务端搭建（module：eureka-server）

1、pom.xml依赖

``` java
<dependency>
    <groupId>org.springframework.cloud</groupId>
    <artifactId>spring-cloud-starter-netflix-eureka-server</artifactId>
</dependency>

<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-security</artifactId>
</dependency>
```

2、application入口类添加注解@EnableEurekaServer

3、application.yml配置

``` xml
spring:
  security:
    user:
      # 配置登录的账号是user
      name: user
      # 配置登录的密码是pwd
      password: pwd
server:
  # 指定该Eureka实例的端口
  port: 8761
eureka:
  # 用于连接发送心跳包，以及集群互联
  client:
    # 是否要将自己注册到Eureka Server
    registerWithEureka: false
    # 是否从Eureka Server获取注册信息
    fetchRegistry: false
    serviceUrl:
      # 设置与Eureka Server交互的地址，多个地址间用逗号分隔
      defaultZone: http://user:pwd@localhost:8761/eureka/
```

<!--more-->

4、如果使用的spring cloud是Finchley版，且需要鉴权的话，需要增加类，部分关闭掉Spring Security的CSRF保护功能。可查看官方文档说明。

``` java
@EnableWebSecurity
class WebSecurityConfig extends WebSecurityConfigurerAdapter {
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.csrf().ignoringAntMatchers("/eureka/**");
        super.configure(http);
    }
}
```

5、 运行并测试

* 使用浏览器访问http://localhost:8761 可查看eureka管理页面。
* 如访问http://localhost:8761/eureka/apps/EUREKA-CONFIG-SERVER 可查看某个微服务的所有实例。

6、 集群

可做集群来保证高可用性，相互注册即可。

```yml
spring:
  security:
    user:
      # 配置登录的账号是user
      name: user
      # 配置登录的密码是pwd
      password: pwd
eureka:
  #用于连接发送心跳包，以及集群互联
  client:
    serviceUrl:
      #设置与Eureka Server交互的地址，多个地址间用,分隔
      defaultZone: http://user:pwd@peer1:8761/eureka/,http://user:pwd@peer2:8762/eureka/
---
spring:
  profiles: peer1
server:
  # 指定该Eureka实例的端口
  port: 8761
eureka:
  instance:
    hostname: peer1
---
spring:
  profiles: peer2
server:
  # 指定该Eureka实例的端口
  port: 8762
eureka:
  instance:
    hostname: peer2
```

> eureka客户端搭建

1、包含两个module：eureka-config-server，eureka-config-client。

2、微服务如果需要注册到eureka上，需要启用注解@EnableEurekaClient，并在yml上配置如下

```bash
eureka:
  client:
    serviceUrl:
      defaultZone: http://user:pwd@localhost:8761/eureka/
```

3、成功注册后可在页面上查看注册方信息。分别是两个客户端module的注册内容，名称通过yml文件的spring.application.name设置。

![](SpringCloud实战（2）服务发现/eureka.png)

## 三、其他事项

> REST端点

Eureka Server提供了一些REST端点，用于非JVM的微服务调用，来实现注册与发现。

> 自我保护模式

Server首页可能会输出EMERGENCY告警，代表进入自我保护模式。当Eureka Server在一定时间内没有收到某个微服务实例的心跳时，会注销该实例（默认90s）。但当由于网络问题导致Eureka Server节点在短时间内丢失过多客户端时，（比如因网络故障）等，会进入该模式。

可通过eureka.server.enable-self-preservation = false禁用。

> 多网卡环境下的IP选择

1、忽略指定名称的网卡

```yml
spring:
  cloud:
    inetutils:
      ignored-interfaces:
        - docker0
        - veth.*
eureka:
  instance:
    prefer-ip-address: true
```

2、使用正则表达式，指定使用的网络地址

```yml
spring:
  cloud:
    inetutils:
      preferredNetworks:
        - 192.168
        - 10.0
eureka:
  instance:
    prefer-ip-address: true
```

3、手动指定ip

```yml
eureka:
  instance:
    prefer-ip-address: true
    ip-address: 127.0.0.1
```

## 四、相关代码

[『代码传送门』](https://gitee.com/iherr/spring-cloud-trip-eureka)