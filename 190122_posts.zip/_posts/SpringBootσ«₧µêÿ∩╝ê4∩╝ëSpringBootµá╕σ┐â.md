---
title: SpringBoot实战（4）SpringBoot核心
date: 2017-04-11 14:15:46
tags: [SpringBoot,Java,源码]
---

## 一、核心功能

> 核心功能（优点）

1、快速构建项目（提供starter简化Maven配置）
2、主流开发框架的无配置集成（自动配置Spring）
3、可以jar包方式独立运行，无须依赖Servlet容器，内嵌Servlet容器（Tomcat、Jetty、Undertow）
4、提供运行时的应用监控
5、极大提高了开发和部署效率（无代码生成和xml配置，通过注解配置和java配置，自动化配置）
6、与云计算的天然集成，提供生产级特性actuator

> 快速集成

1、可到https://start.spring.io 快速配置下载demo  
2、idea自带的Spring Initializr或eclipse的Spring Tool Suite  
3、Spring Boot CLI命令行生成  
4、Maven手工创建

* 添加Spring Boo通的父级依赖
* 添加web支持的starter pom（spring-boot-starter-web）
* 添加编译插件

## 二、基本配置
> 入口类和@SpringBootApplication

有名为*Application的入口类，包含一个main方法，用来启动SpringBoot应用项目。

@SpringBootApplication是核心的组合注解，组合了@Configuration、@EnableAutoConfiguration、@ComponentScan这3个注解。

> banner默认启动图案

可通过在src/main/resources新建banner.txt覆盖。也可在main里禁用。


![](SpringBoot实战（4）SpringBoot核心/banner.png)

>配置文件

SpringBoot使用资源目录下的全局的配置文件application.properties（常规properties配置文件）或application.yml（yaml语言）。

SpringBoot提倡零xml配置，如特殊情况需要使用，可使用@ImportResource来加载。

如tomcat端口和访问路径：

``` bash
#properties版本
server.port=9090
server.servlet.context-path=/iherr

#yml版本
server:
	port: 9090
	server.servlet.context-path: /iherr
```

> starter pom

提供了大多数场景的starter pom，包括官方和第三方，列举部分：


| 名称 | 描述 |
| -------  |:---: 	|
|	spring-boot-starter	|	核心starter，包含自动配置、日志、yaml配置文件等支持	|
|	spring-boot-starter-amqp |	使用spring-rabbit支持AMQP |	
|	spring-boot-starter-aop |	使用spring-aop和AspectJ支持切面	|
|	spring-boot-starter-jpa	|  对JPA支持，包含spring-data-jpa、spring-orm和Hibernate	|
|	spring-boot-starter-freemarker	|  对freemarker模板引擎支持	|
|	spring-boot-starter-thymeleaf	|  对thymeleaf模板引擎支持	|
|	spring-boot-starter-volocity	|  对volocity模板引擎支持	|
|	spring-boot-starter-jdbc	|  对JDBC数据库的支持	|
|	spring-boot-starter-test	|  对常用测试框架JUnit、Hamcrest等支持，包含spring-test模块	|
|	spring-boot-starter-web	|  对Web项目开发的支持，包含Tomcat和spring-webmvc	|
|	spring-boot-starter-Tomcat	|  默认的Servlet容器Tomcat	|
|	spring-boot-starter-Jetty	|  使用Jetty作为Servlet容器替换Tomcat	|
|	spring-boot-starter-Undertow	|  使用Undertow作为Servlet容器替换Tomcat	|
|	spring-boot-starter-logging	|  默认的日志框架Logback	|
|	spring-boot-starter-log4j	|  支持使用Log4J日志框架	|


<!--more-->

> 外部配置

SpringBoot允许使用properties文件、yaml文件或者命令行参数作为外部配置。

``` bash
$ java -jar xx.jar
$ java -jar xx.jar --server.port=9090 #修改端口启动
```

可使用@Value获取properties文件属性
``` java
	@Value("${book.author}")
	private String bookAuthor;
```

也可以通过@ConfigurationProperties将properties属性和一个bean及其属性关联，实现类型安全的配置。prefix属性指定前缀，locations指定properties文件位置。

``` java
	@ConfigurationProperties(prefix = "book",locations="{classpath:config/book.properties}")
```

> 日志配置

SpringBoot默认使用Logback作为日志框架，输出到控制台。如需要输出到文件，可在properties文件配置。

``` bash
logging.level.org.springframework.web = INFO
logging.file= iherr.log
```

> Profile配置

Profile是Spring用来针对不同的环境对不同的配置提供支持的。全局Profile配置使用application-{profile}.properties  

通过在application.properties中设置spring.profiles.active=prod来指定生产环境的Profile。

###三、运行原理

自动配置的源码，在org.springframework.boot.spring-boot-autoconfigure-2.x.x.x.jar中。


开启debug后，可看到如下日志。开启方法：  
1、java -jar xxx.jar --debug

2、application.properties添加debug=true

3、运行设置中增加debug为true的参数

``` bash 

============================
CONDITIONS EVALUATION REPORT
============================


Positive matches: #启用的自动配置
-----------------
.
.
.
Negative matches: #未启用的自动配置
-----------------
.
.
.
```

自动配置的核心注解是@EnableAutoConfiguration这个组合注解，核心功能是@EnableAutoConfiguration注解提供。

EnableAutoConfiguration里面import一个类@Import({AutoConfigurationImportSelector.class})，

AutoConfigurationImportSelector使用方法SpringFactoriesLoader.loadFactoryNames扫描了包含META-INF/spring.factories的jar包，而我们的spring-boot-autoconfigure-2.x.x.x.jar中有META-INF/spring.factories此文件。

spring.factories文件包含了可自动配置的类。

``` bash
# Initializers
org.springframework.context.ApplicationContextInitializer=\
org.springframework.boot.autoconfigure.SharedMetadataReaderFactoryContextInitializer,\
org.springframework.boot.autoconfigure.logging.ConditionEvaluationReportLoggingListener

# Application Listeners
org.springframework.context.ApplicationListener=\
org.springframework.boot.autoconfigure.BackgroundPreinitializer

# Auto Configuration Import Listeners
org.springframework.boot.autoconfigure.AutoConfigurationImportListener=\
org.springframework.boot.autoconfigure.condition.ConditionEvaluationReportAutoConfigurationImportListener

# Auto Configuration Import Filters
org.springframework.boot.autoconfigure.AutoConfigurationImportFilter=\
org.springframework.boot.autoconfigure.condition.OnClassCondition

# Auto Configure
org.springframework.boot.autoconfigure.EnableAutoConfiguration=\
org.springframework.boot.autoconfigure.admin.SpringApplicationAdminJmxAutoConfiguration,\
org.springframework.boot.autoconfigure.aop.AopAutoConfiguration,\
org.springframework.boot.autoconfigure.amqp.RabbitAutoConfiguration,\
org.springframework.boot.autoconfigure.batch.BatchAutoConfiguration,\
org.springframework.boot.autoconfigure.cache.CacheAutoConfiguration,\
.
.
.
```

例如之前在web.xml文件中配置http编码的filter，如下：

```bash
    <!--配置编码-->
    <filter>
        <filter-name>CharacterEncodingFilter</filter-name>
        <filter-class>org.springframework.web.filter.CharacterEncodingFilter</filter-class>
        <init-param>
            <param-name>encoding</param-name>
            <param-value>utf-8</param-value>
        </init-param>
    </filter>
    <filter-mapping>
        <filter-name>CharacterEncodingFilter</filter-name>
        <url-pattern>*.iherr</url-pattern>
    </filter-mapping>
```
现在使用自动配置，通过HttpEncodingAutoConfiguration实现。(路径如下：org.springframework.boot.autoconfigure.web.servlet.HttpEncodingAutoConfiguration)，包含@ConditionalOnClass和@ConditionalOnProperty等，都是组合了@Condition元注解，使用了不同的条件。

``` java
@Configuration
@EnableConfigurationProperties({HttpEncodingProperties.class})#1、开启属性注入
@ConditionalOnWebApplication(
    type = Type.SERVLET
)
@ConditionalOnClass({CharacterEncodingFilter.class})#2、当CharacterEncodingFilter在类路径的条件下
@ConditionalOnProperty(
    prefix = "spring.http.encoding",
    value = {"enabled"},
    matchIfMissing = true
)#3、当在properties文件中设置spring.http.encoding=enabled情况下
public class HttpEncodingAutoConfiguration {
    private final HttpEncodingProperties properties;

    public HttpEncodingAutoConfiguration(HttpEncodingProperties properties) {
        this.properties = properties;
    }

    @Bean #4、使用java配置CharacterEncodingFilter这个Bean
    @ConditionalOnMissingBean #5、没有时新建这个Bean
    public CharacterEncodingFilter characterEncodingFilter() {
        CharacterEncodingFilter filter = new OrderedCharacterEncodingFilter();
        filter.setEncoding(this.properties.getCharset().name());
        filter.setForceRequestEncoding(this.properties.shouldForce(org.springframework.boot.autoconfigure.http.HttpEncodingProperties.Type.REQUEST));
        filter.setForceResponseEncoding(this.properties.shouldForce(org.springframework.boot.autoconfigure.http.HttpEncodingProperties.Type.RESPONSE));
        return filter;
    }
}
```