---
title: FFmpeg入门
date: 2016-12-15 11:36:25
tags: [FFmpeg]
---

## 一、FFmpeg简介

FFmpeg是一个自由软件，可以运行音频和视频多种格式的录影、转换、流功能，包含了 libavcodec 用于多个项目中音频和视频的解码器库，以及 libavformat 音频与视频格式转换库。

[『FFmpeg官网传送门』](https://ffmpeg.org/)，目前支持Linux,Mac OS,Windows三个主流的平台，可以直接下载使用。

## 二、FFmpeg安装

当然也可以自己编译到Android或者iOS平台。

> 如果是Mac用户，可以通过brew安装

有之前有安装过，版本或模块有问题，可先brew uninstall卸载。

``` bash
$ brew install ffmpeg --with-libvpx --with-libvorbis --with-ffplay
```
 
> linux 安装

详细资料可参考官方文档，[『文档传送门』](https://trac.ffmpeg.org/wiki/CompilationGuide/Centos)

<!--more-->

``` bash 
# 安装依赖包
$ yum install -y autoconf automake cmake freetype-devel gcc gcc-c++ git libtool make mercurial nasm pkgconfig zlib-devel

$ mkdir ~/ffmpeg_sources
$ cd ~/ffmpeg_sources
$ git clone https://github.com/FFmpeg/FFmpeg.git
$ cd FFmpeg
$ export PKG_CONFIG_PATH="$HOME/ffmpeg_build/lib/pkgconfig"

$ ./configure --prefix="$HOME/ffmpeg_build" --extra-cflags="-I$HOME/ffmpeg_build/include" --extra-ldflags="-L$HOME/ffmpeg_build/lib" --bindir="$HOME/bin" --pkg-config-flags="--static" --enable-gpl --enable-nonfree --enable-libfdk-aac --enable-libfreetype --enable-libmp3lame --enable-libopus --enable-libvorbis --enable-libvpx --enable-libx264 --enable-libx265

$ make
$ make install

$ make distclean
$ hash -r

```

## 三、FFmpeg使用

> 常用参数说明

1、主要参数

| 参数  | 说明 |
| :-----: |-----|
|-i|	设定输入流|
|-f|	设定输出格式|
|-ss|	开始时间|
|-re|	按照帧率发送|

2、视频参数

| 参数  | 说明 |
| :-----: |-----|
|-b|	设定视频流量，默认为200Kbit/s|
|-r|	设定帧速率，默认为25|
|-s|	设定画面的宽与高|
|-aspect|	设定画面的比例|
|-vn|	不处理视频|
|-vcodec|	设定视频编解码器，默认与输入流相同|

3、音频参数

| 参数  | 说明 |
| :-----: |-----|
|-ar|	设定采样率|
|-ac|	设定声音的Channel数|
|-acodec|	设定声音编解码器，默认与输入流相同|
|-an|	不处理音频|

> 在Mac下面使用FFmpeg进行录屏

``` bash 
$ ffmpeg -f avfoundation -list_devices true -i ""
# 查看可输入设备id
$ ffmpeg -y -loglevel warning -f avfoundation -i 1 -r 30 -s 480x320 -threads 2 -vcodec libx264  -f flv rtmp://127.0.0.1/live/test
```

> 推音频+视频

``` bash 
$ ffmpeg -re -i "输入源" -acodec copy -vcodec copy -f flv -y  "输出源"

$ ffmpeg -re -i "http://127.0.0.1/live/1.mp4" -acodec copy -vcodec copy -f flv -y  "rtmp://127.0.0.1/live/test"
```

> 推纯音频流或纯视频流，通过-an分离视频流，-vn分离音频流

``` bash 
$ ffmpeg -re -i "输入源" -acodec copy -vcodec copy -vn -f flv -y "输出源"

$ ffmpeg -re -i "http://127.0.0.1/live/1.mp4" -acodec copy -vcodec copy -vn -f flv -y "rtmp://127.0.0.1/live/test"
```

> 摄影机rtsp转rtmp推流

```bash
$ ffmpeg -i "rtsp://admin:123456@123.0.0.1:554/h264/stream1" -vcodec libx264 -acodec aac -f flv -r 25 -b 2097152 -s 1280x720 -an "rtmp://127.0.0.1/live/test"
```


> rtmp拉流并推流

```bash
$ ffmpeg -re -i "rtmp://127.0.0.1/live/test1" -acodec copy -vcodec copy -f flv "rtmp://video-center.alivecdn.com/device/osmo1?vhost=tv.cctbn.com&auth_key=1708959988-0-0-bb37263305651e25efd94c7335cd68b4"
```

> 本地视频文件推流

```bash
$ ffmpeg -re -i /usr/local/ffmpeg/1.mp4 -vcodec libx264 -acodec aac -f flv "rtmp://127.0.0.1/live/test"

$ ffmpeg -re -i /usr/local/ffmpeg/1.mp4 -c copy -f flv "rtmp://127.0.0.1/live/test"
```

> 将m3u8回放保存到本地

```bash
$ ffmpeg -i "rtmp://127.0.0.1/live/test1.m3u8" -bsf:a aac_adtstoasc -acodec copy -vcodec copy -f mp4 output.mp4
```

> 合并多个flv

```bash
$ ffmpeg -f concat -i **all.txt** -c copy output.mp4

#all.txt内容如下：
file '/usr/local/video/1.flv'
file '/usr/local/video/2.flv'
file '/usr/local/video/3.flv'
file '/usr/local/video/4.flv'
```

## 四、FFplay

ffplay是ffmpeg的一个子工具，它具有强大的音视频解码播放能力，目前它广泛被各种流行播放器（QQ影音、暴风影音等）集成应用。作为一款开源软件，ffplay囊括Linux、Windows、iOS、Android等众多主流系统平台，十分适合进行二次开发。

```bash
$ ffplay http://127.0.0.1/live/test.m3u8
$ ffplay rtmp://127.0.0.1/live/test
$ ffplay -vfscale=1920:1080 /usr/local/ffmpeg/1.mp4

```