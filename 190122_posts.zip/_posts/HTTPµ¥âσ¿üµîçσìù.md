---
title: HTTP权威指南
date: 2017-05-30 14:51:57
tags: [HTTP]
---

## 一、HTTP简介

> 通用格式URL

``` html
<scheme>://<user>:<password>@<host>:<port>/<path>;<params>?<query>#<frag>
```

> 请求报文

``` html
<method> <request-URL> <version>
<headers>

<entity-body>
```
> 响应报文

``` html
<version> <status> <reason-phrase>
<headers>

<entity-body>
```
> 状态码分类

整体范围 | 已定义范围  |分类
---|---|---
100-199|100-101|信息提示
200-299|200-206|成功
300-399|300-305|重定向
400-499|400-415|客户端错误
500-599|500-505|服务器错误

<!--more-->

> 首部

首部分为：通用首部、请求首部（accept首部、条件请求首部、安全请求首部和代理首部）、响应首部（协商首部和安全响应首部）、实体首部（内容首部和实体缓存首部）和拓展首部。

![](HTTP权威指南/tcp_delay.jpg)
![](HTTP权威指南/tcp_connect.jpg)
![](HTTP权威指南/tcp_close.jpg)

strace神器

TCP_NODELAY参数禁用Nagle算法

针对串行事务处理的HTTP连接性能提升：（Connection首部）
1、并行连接（缺点：每个事务都会打开/关闭一条新连接；TCP慢启动；并行数量上限引起的性能问题）
2、持久连接（HTTP/1.0+的"keep-ailve"和HTTP/1.1的"persistent"），为避免哑代理问题，引入Proxy-Connection字段，但只解决了单个哑代理带来的问题，无法解决多层次代理的情况。
于是HTTP/1.1默认所有连接是持久的，如果需要在事务结束后关闭，需要显式添加Connection:close首部。
3、管道化连接，只在HTTP/1.1上，允许在持久连接上可选地使用“请求管道”，但该连接同样会产生限制（例如不能发送非幂等的事务，如POST请求等）。
![](HTTP权威指南/tcp_persistent.jpg)

> 关闭连接的奥秘

1、“任意”解除链接
2、TCP连接是双向的，因此输入和输出信道有存在是否关闭。

四次挥手：
第一阶段 客户机发送完数据之后，向服务器发送一个FIN数据段，序列号为i；
    1.服务器收到FIN(i)后，返回确认段ACK，序列号为i+1，关闭服务器读通道；  
    2.客户机收到ACK(i+1)后，关闭客户机写通道；  
第二阶段 服务器发送完数据之后，向客户机发送一个FIN数据段，序列号为j；  
    3.客户机收到FIN(j)后，返回确认段ACK，序列号为j+1，关闭客户机读通道；  
    4.服务器收到ACK(j+1)后，关闭服务器写通道。
这是标准的TCP关闭两个阶段，服务器和客户机都可以发起关闭，完全对称。

> 代理的运用
  
1、Web缓存  
2、反向代理  
3、内容路由器  
4、转码器

> 缓存

If-Modified-Since和Last-Modified的配合使用
If-None-Match和ETag的配合使用

> 压缩

Content-Encoding和Accept-Encoding

> 内容协商

Vary首部


